# T09 same-event admission — static review

**APPROVED, conditional execution of the exact two-child T09 ticket, once.** No mandatory correction is identified. This is prospective fixture/executable approval; it neither establishes admission before results exist nor accepts C1 for adoption.

Review was limited to static files/diffs, manifest/hash checks, and the relevant production commit/drain implementation. No submitted modules were imported, workloads or tests run, GPU queried, packages installed, or source files changed.

## Exact identity

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T09_REQUEST.md | `266975784e157e5ffb67ccf744c0d4354a4588ef14358f523196865e68b937f5` |
| T09.json | `c2913bbbca59ab27111daa0dcaf079115a1d0bb8c9ca8d7d8aaa13fefb6e3a74` |
| t09_entry.py | `747c6ee6c1bf786499c5a09664653873b8a085e251056c111dfe923204aaa949` |
| async-same-event-harness/probe.py | `67b74eeb430673b5fef4924568d833b03d6a5b38ae2777b1e913cf058e1de54f` |

Every file listed in T09.json matched its hash. Shared runner remains `14d60a8f9e30a09891cf2d0b08e1e8346ecc4f8879c28c9bee901267a474efe1`; common fixture remains `3ba8856548e462a4fa11424bb3eac8a8f1984fbef5454b8f5f6fe137f97bda56`. Candidate HEAD is pinned to A `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`; the actual current binary diff matched `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3`.

## Fixture and independent oracle

Both original helper calls receive E2, the event recorded after both producer reads; E1 is only the intermediate observation. The normal case therefore exercises two batches aggregated under one shared completion event. Four helper warmups restore mappings before the observed interval; reader/event and concatenation/pinned-copy warmups also finish beforehand. The original fixed 2-billion/1-billion-cycle delays are unchanged. Prebuilt index substitution remains disclosed; no helper line trace or production-source change is involved.

The negative dictionary overrides only `get` for E2. In the inspected `_commit_move_batch`, that lookup retrieves the preceding batch for aggregation, so suppressing it makes the second assignment replace the first batch's event entry. The original drain iterates entries and deletes them without using that overridden lookup. This is a bounded injection of lost aggregation, rather than a replacement drain or a fabricated free-list result.

Detection is appropriately independent: after urgent E2 ordering and the completed pinned snapshot, the actual free list must contain source two and lack exactly source one. Detection also requires the earlier nonvacuous overlap prerequisites and E2 completion. The signature `COMPLETED_READER_SOURCE_NOT_RECLAIMED` supports a reclamation-loss claim, not early reuse or corruption. CPU pending metadata is supplementary evidence, not the detection oracle.

The normal path retains checks that both sources remain protected before E2, that urgent reuse has the E2 stream dependency, that neither completed source is missing afterward, and that both source pages are actually reused. Retained/new payload, old-reader payload, mapping/accounting and final pending-leak checks remain mandatory.

## D2H ordering and partial cleanup

The pinned buffer is preallocated and capacity-checked for at most two int64 values. The actual free-list copy runs on the restored consumer stream; recording and synchronizing `copy_done` before reading the host buffer makes that snapshot safe. After urgent drain, the copy follows the consumer's E2 wait, so a nonempty completed snapshot is downstream of reader completion. E2 completion is also queried explicitly for negative detection. The empty snapshot path is not assumed to prove completion.

Already-fired helper release tensors are merged before the reclamation snapshot. This handles missed-overlap paths without losing legitimate releases. Negative repair happens only after explicit E2 synchronization, requires precisely source one missing with source two present and no remaining pending event entry, removes only source one's CPU pending marker, and restores only that known page. The pre-repair observation/signature is retained. Unexpected loss shapes or residual state fail; they are not broadly repaired.

Repair is allowed even if overlap was missed so that the controlled injection does not manufacture a later accounting failure. It does not promote that run: absent detection prerequisites still yield PARTIAL. Both-source reuse and all final payload/accounting checks remain required after repair. The normal arm never repairs a missing completed source. No deliberate racing overwrite is used in either arm.

On assertion/exception, the child fails and the unchanged outer runner enforces bounded process-group termination and survivor checking. Fixture reset alone is not treated as proof of completed GPU work; successful paths explicitly reach their payload synchronization, and failure paths remain subject to the process guard.

## Conditional execution and admission

Authorize exactly C/M2/FULL/page-1/lazy, pinned observation, repeat 0: normal then negative, each at most 90 seconds and the ticket at most 240 seconds. These consume two of the original 24 confirmation cells. Use the hashed `t09_entry.py`; it preserves parent CUDA-context checks, with child checks of flags/backend/device/streams and source/environment identity.

Before launch, the executor must retain and verify the exact T07 manifest/status/result binding: T07 COMPLETE without faults, cleanup PASS, and **pinned-A worker PASS with its actual overlap/reuse prerequisites**. A runner PASS allowing PARTIAL is insufficient. This prerequisite is procedural; the entry wrapper does not validate T07 results automatically.

T04V2 and any preceding workload must first complete or receive disposition and finish cleanup. No overlap. Existing C1 correctness, unchanged source/environment and disposition of any functional/provenance/resource failure remain required. If T08 or another intervening ticket has an unresolved failure, it is not bypassed by T09's independent pattern. A distinct-pattern PARTIAL alone is not same-pattern admission or a reason to alter T09.

Same-event admission requires T09 normal PASS plus negative EXPECTED_FAULT_DETECTED with valid runner/source/cleanup records. Both planned children may run if normal is merely PARTIAL; an unexpected FAIL stops the ticket. Either PARTIAL leaves admission incomplete and prohibits expansion or automatic retry. Any later layout/owner/production-flush confirmation still needs its own concrete review. No universal async-safety, performance, or source-adoption conclusion follows here.

Retain the 8 GiB RSS, 32 MiB per-child log, 3 GiB whole-device/headroom guard and bounded cleanup. The absolute execution cutoff is **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST), and final cleanup/reporting deadline **22:17:44 UTC** (07:17:44 KST). No budget/deadline reset, extra delays, serving, push or merge is authorized.
