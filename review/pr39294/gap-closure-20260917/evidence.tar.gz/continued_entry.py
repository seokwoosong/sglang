import json,os,runpy,sys
from pathlib import Path
r=Path(__file__).resolve().parent
c=json.loads((r/'CUDA_CONTEXT.json').read_text())
assert {k:os.environ.get(k) for k in c['flags']}==c['flags'],'PARENT_CUDA_CONTEXT_DRIFT'
sys.argv=[str(r/'continuation_runner.py'),sys.argv[1]]
runpy.run_path(str(r/'continuation_runner.py'),run_name='__main__')
