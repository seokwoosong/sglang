# T12 v2 focused correction review

**APPROVED — conditional execution of the exact single-child CUDA profiling diagnostic, once.** The required trace-validity correction from `/tmp/PR39294_T11_T12_REVIEW.md` is satisfied. No further mandatory change is identified.

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T12_V2_REQUEST.md | `2900703d753441e49b2d72d04b430064bbd3738133463f299cd1d47c82d3cd1d` |
| T12.json | `e9142ad220326decc9fcab2f48af1df5be8d3415a53c6d724539533f1dd24efe` |
| async-profile-harness/probe.py | `c6fea28fb8bf1d57848735674fdee9d30998cd3e3a3f234a510c70cd3978593b` |

All manifest file hashes matched. Preserved `T12.v1.json` and `probe.py.v1` match the prior reviewed hashes. The manifest changes only the probe hash; command, source, environment, limits and output binding remain unchanged.

The worker now requires supported CUDA profiler activity before starting. After export it checks the 32 MiB acceptance limit before reading/parsing, records the trace SHA256, and requires positive-duration device kernels with stream IDs, at least two kernel streams, runtime/driver-correlated kernel activity, runtime/driver-correlated DtoH GPU-copy activity, and synchronization/wait runtime events. CPU operator names or successful export alone no longer satisfy the gate. These checks establish usable device-trace evidence; identifying the precise snapshot dependency still requires inspecting the actual trace and correlations.

Missing evidence or trace stop/export/parsing errors now cause a distinct FAIL unless an earlier fixture FAIL already exists. In that case, the earlier failure remains and `trace_error` records the secondary error. Unsupported CUDA profiling also fails before capture. The instrumented-diagnostic label is explicit. A valid trace with fixture PARTIAL remains useful diagnosis but does not count as async admission.

Authorize only the existing A/M2/FULL/page-1/lazy pinned normal child, repeat 0, through hashed `t12_entry.py`: **120-second child limit, 180-second ticket ceiling**. The inherited comment mentioning 90 seconds does not override the manifest. Preserve fixed delays, existing warmups, original helper/copy/remap/drain calls and disclosed prebuilt indices. No extra child, retry, installation, environment workaround or production edit is authorized.

Wait for T11 and any other active workload to complete or receive disposition and finish owned-process cleanup. Retain unchanged source/environment/context checks, 8 GiB RSS, 32 MiB child-log and 3 GiB whole-device/headroom guards. Profiler buffers and parsing count toward the existing process/RSS deadline. The trace limit remains a post-export acceptance check, not a hard write cap. A profiling failure blocks further dependent execution pending disposition.

Absolute execution cutoff remains **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST), final cleanup/reporting **22:17:44 UTC** (07:17:44 KST). No budget reset.

This does not change the T04V2 performance miss, adopt C1, release T06, or satisfy the failed T07 pinned admission prerequisite. T08/T09/T10 remain blocked by their existing gates. Profiled observations cannot replace unprofiled admission or establish performance. No serving, push or merge is authorized.

Review was static only: request, exact diffs, manifest and file hashes. No submitted imports, workloads, GPU queries or source changes were performed.
