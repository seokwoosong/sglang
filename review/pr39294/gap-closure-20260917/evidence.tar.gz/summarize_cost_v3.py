"""Read-only, predeclared cost analysis for frozen 12-block B/A/C validation."""
import json,math,random,statistics,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;D=R/'t04v2-c1-cost'
def q(xs,p):
 s=sorted(xs);x=(len(s)-1)*p;i=int(x);return s[i]+(s[min(i+1,len(s)-1)]-s[i])*(x-i)
manifest_path=R/'T04V2.json';manifest=json.loads(manifest_path.read_text())
status=json.loads((D/'STATUS.json').read_text());blocks=[];excluded=[]
assert status['ticket']==manifest['id'] and status['manifest_sha256']==hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'TICKET_IDENTITY'
registry={case['id']:case for case in manifest['cases']};rows=status['cases']
assert len({row['id'] for row in rows})==len(rows),'DUPLICATE_RUNNER_ROWS'
assert all(row['id'] in registry for row in rows),'UNKNOWN_RUNNER_ROW'
runner={row['id']:row for row in rows};environment=json.loads((R/'ENVIRONMENT.json').read_text());config=json.loads((R/'cpu-harness-v2/registry.json').read_text())
assert status.get('environment')==environment,'PARENT_ENVIRONMENT'
accepted={}
for label,case in registry.items():
 reason=None;row=runner.get(label)
 try:
  assert not status.get('failure'),'UNRESOLVED_TICKET_PROVENANCE_OR_SUPERVISION_FAILURE'
  assert row is not None,'NOT_RUN'
  assert row['command']==case['command'],'COMMAND_BINDING'
  assert row['status']=='PASS' and row.get('exit_code')==0 and row.get('cleanup')=='PASS' and row.get('result_status')=='PASS','RUNNER_REJECTED'
  assert status['status']=='COMPLETE' or row is not rows[-1],'FINAL_SOURCE_POSTCHECK_UNCONFIRMED'
  assert case['command'][case['command'].index('--out')+1]==case['result'],'RESULT_BINDING'
  data=json.loads(Path(case['result']).read_text());assert data['status']=='PASS','RESULT_NOT_PASS'
  version=case['command'][case['command'].index('--version')+1];source=data['source']
  assert source['version']==version and source['head']==case['head'] and source['cwd']==case['cwd'],'SOURCE_BINDING'
  assert Path(source['allocator_module']).resolve().is_relative_to(Path(case['cwd'])/'python'),'IMPORT_BINDING'
  expected_diff=source['candidate_diff_sha256'] if version=='C' else hashlib.sha256(b'').hexdigest()
  assert expected_diff==case['diff_sha256'],'DIFF_BINDING'
  assert data['environment']==environment,'CHILD_ENVIRONMENT'
  assert len(data['scenarios'])==len(config)==5,'SCENARIO_COUNT'
  for scenario,cfg in zip(data['scenarios'],config):
   assert scenario['config']==cfg and scenario['status']=='PASS' and scenario['warmup_count']==2,'SCENARIO_IDENTITY'
   assert len(scenario['samples'])==5,'SAMPLE_COUNT'
   assert all(isinstance(x['host_ns'],(int,float)) and math.isfinite(x['host_ns']) and x['host_ns']>0 for x in scenario['samples']),'INVALID_SAMPLE'
  accepted[label]=data
 except (AssertionError,KeyError,ValueError,OSError) as error:reason=str(error);excluded.append(dict(case=label,reason=reason))
for i in range(12):
 if all(f'{i}-{v}' in accepted for v in 'BAC'):
  block={v:accepted[f'{i}-{v}'] for v in 'BAC'}
  assert all(block[v]['cpu_context']==block['B']['cpu_context'] and [(x['config'],x['initial']) for x in block[v]['scenarios']]==[(x['config'],x['initial']) for x in block['B']['scenarios']] for v in 'AC'),'BLOCK_IDENTITY_MISMATCH'
  blocks.append((i,block))
complete_valid=status['status']=='COMPLETE' and len(rows)==len(accepted)==36 and len(blocks)==12 and not excluded
result={'complete_blocks':[i for i,_ in blocks],'status':status['status'],'complete_valid_run':complete_valid,'excluded_cases':excluded,'scenarios':{},'statistical_note':'Adaptive candidate development is not selection-adjusted; intervals are supplementary fixture-bounded descriptions, not general equivalence guarantees.'}
for j,name in enumerate(['M2-ready','S2-ready','T3-ready','S2-pressure','T3-pressure']):
 if not blocks:break
 med={v:[statistics.median(s['host_ns']/1000 for s in b[v]['scenarios'][j]['samples']) for _,b in blocks] for v in 'BAC'}
 entry={'medians_us':med,'comparisons':{}}
 for baseline in 'AB':
  ratios=[c/b for c,b in zip(med['C'],med[baseline])];deltas=[c-b for c,b in zip(med['C'],med[baseline])]
  values={'ratios':ratios,'deltas_us':deltas,'median_ratio':statistics.median(ratios),'median_delta_us':statistics.median(deltas)}
  if complete_valid:
   rng=random.Random(39294);lr=[math.log(x) for x in ratios];rb=[];db=[]
   for _ in range(10000):
    ix=[rng.randrange(12) for _ in range(12)];rb.append(statistics.median(lr[k] for k in ix));db.append(statistics.median(deltas[k] for k in ix))
   values['ratio_ci95']=[math.exp(q(rb,.025)),math.exp(q(rb,.975))];values['delta_us_ci95']=[q(db,.025),q(db,.975)]
  entry['comparisons']['C/'+baseline]=values
 entry['material_deterioration_vs_A']=entry['comparisons']['C/A']['median_ratio']>1.10 and entry['comparisons']['C/A']['median_delta_us']>5
 result['scenarios'][name]=entry
if complete_valid:
 primary=result['scenarios']['T3-ready']['comparisons']
 result['primary_margin_met']=primary['C/A']['ratio_ci95'][1]<1 and primary['C/B']['ratio_ci95'][1]<1.10 and primary['C/B']['delta_us_ci95'][1]<5
else:result['primary_margin_met']=None;result['verdict']='INCONCLUSIVE'
result['control_investigation_required']=[n for n,x in result['scenarios'].items() if n!='T3-ready' and x['material_deterioration_vs_A']]
(R/'COST_ANALYSIS_V3.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
