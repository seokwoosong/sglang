# User-authorized continuation: focused static review

Decision: **APPROVED WITH THE LAUNCH CONDITION BELOW** for exact T17C, T22C and optional T23C, sequentially. The user's explicit removal of the original time limit supersedes both the old workload cutoff and final cleanup/report cutoff prospectively. Historical executions and stop records must remain unchanged. Individual ticket/child limits and stop gates remain mandatory.

## Exact reviewed bindings

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
| --- | --- |
| CONTINUATION_REQUEST.md | `a2546ea8d626aba58a505191e61cc69c3d0b6139e122c41d5d95872f81099821` |
| continuation_runner.py | `c169ccf1b8ce6b4902a288ee5d64a17b83d5bb9ce9d109bcc9ebd7270c02632b` |
| continued_entry.py | `d971a8551efca55f2ee4a6317bd9b64439f92c7377299cdbcc9559933eba4856` |
| T17C.json | `559296c9a1583695d236623bc03c9ecc99c08fd8fe3962ffff5512966243b188` |
| T22C.json | `5e6653d28aaea1ea6311013bb4806fef142cd342923b9eca1519d204b3ac66de` |
| T23C.json | `90fdecd9d02ee742423b4b84942bf18de9c7f1629d6ea6ee9bedb68319f608a3` |

All declared file hashes matched. Each complete case registry is identical to its previously reviewed counterpart after changing only the output-directory identifier. Probes, source pins, commands apart from output paths, environment settings, allowed result labels and case order remain unchanged. C2's current binary diff remains `4451ee8cc9ddb025f13a8ea954370c7d20ebac6310c454cd438379ff9433e5e0`.

The runner diff is one assignment: the expired absolute clipping is replaced by the ticket's duration. Startup is still charged from before imports, execution still reserves 15 seconds for cleanup, and child deadlines, polling/completion checks, failure precedence, hash/environment/source checks, process-group termination and resource guards are unchanged. The `global_remaining_seconds` field now describes a ticket-duration value; reports must not interpret it as a renewed eight-hour allowance or an absolute global deadline.

**Required launch condition:** T17C's manifest does not include `CUDA_CONTEXT.json`, although continued_entry.py reads it. Before invoking the entry wrapper, explicitly verify and record that file's SHA256 as `7ae0dbb850870d33c0a68012fcf77f533f1fb72c8289637acbb2783484b24e6e`, alongside the exact manifest and wrapper hashes above. Stop on mismatch. T22C/T23C already bind this file in their manifests. This concrete external hash gate is sufficient for the submitted T17C; no production or harness edit is required. Use the context-checking continued_entry.py with only these exact manifest paths. Its generic argument is not approval of arbitrary tickets, and it does not enforce predecessor-result admission.

## Prerequisite disposition

Original T17 is correctly classified as **NOT_RUN due to expired execution cutoff**: its preserved STOPPED record contains zero cases and `TimeoutError('EXECUTION_CUTOFF')`. It is neither a CUDA/allocator failure nor a completed regression pass. T17C is a newly authorized finite launch, not a retroactive alteration or repeated child experiment.

T16's record binds the approved manifest and contains 36 PASS / result-PASS / exit-zero / cleanup-PASS rows, COMPLETE with no top-level failure. C2_COST_ANALYSIS.json reports all 12 valid blocks, no exclusions and the original primary criteria passing: upper C/A ratio 0.8897923, upper C/B ratio 1.0408161, upper C/B delta 2.8505 microseconds. No predeclared material-control flag is set. This satisfies the previously specified performance gate for T17C, subject to unchanged source/environment.

Preserve the pressure tradeoff: T3-pressure median paired cost is +4.42% / +23.6355 microseconds versus A and +7.28% / +38.1565 microseconds versus B. Lack of a joint median control flag is not evidence of zero regression or general equivalence. C1's performance miss, adaptive-selection caveat, fixture scope and all historic coverage limitations remain disclosed. This review inspected existing analysis and records; it did not execute the analyzer or rerun the bootstrap.

Evidence hashes: T16 STATUS `8556c01a4d54efc711fef2334ab76010ca0fde60579100bae0e4263c84c35d42`; C2_COST_ANALYSIS.json `625ec587351e8afc9e90ccf30938cbe3c95e8319d9db5e3bebdc3be4d385acf8`.

## Approved sequence

1. **T17C:** ten A/C2 synchronized CUDA regression children, 60 seconds each / 900 seconds total. Retain exact retention, payload, closed-gate copy and required actual relocation oracles. Inspect and disposition results before proceeding. A runner PASS with a PARTIAL result remains incomplete coverage. Unexpected failures hold dependent expansion.
2. **T22C:** four A late-operation diagnostic children, 60 seconds each / 300 seconds total, after T17C disposition and cleanup. All limits from the T22 review persist: one sample per operation is diagnostic, not statistical performance or driver-cause proof. No distinct admission follows.
3. **T23C, if still needed:** one A/M2 instrumented original-helper diagnostic, 90 seconds / 180 seconds total, after T22C disposition and cleanup. Normal diagnostic PARTIAL may permit continuation; unresolved unexpected failure may not. Marker queries are observations over time, not an atomic completion boundary. Preserve instrumentation/timing caveats and label the inherited `untraced` scope text as stale. No automatic retry or confirmation cells.

These caps total 1380 seconds if all three tickets are needed; they do not create an overall readiness deadline. Resource limits remain 8 GiB RSS, 32 MiB child log, the existing GPU headroom checks and 3 GiB whole-device cap. Keep execution sequential, new output directories, complete logs, actual cleanup verification and per-ticket failure dispositions. Fresh source/environment checks are required at launch despite earlier successful results. No new packages, altered context, larger sleeps, source mutation or weakened oracle is covered by these manifests.

## Broader authorization and stopping point

The user's authorization to continue toward readiness, push the review branch and finally shut down the computer is acknowledged and does not expire with the former cutoff. This review approves the concrete continuation submitted here; it does not itself certify readiness, adopt C2, establish CI/merge readiness, or certify a future push target. Subsequent evidence-driven source/fixture changes retain the requested focused-review checkpoint. Keep published PR state and review-branch state distinct in reporting.

Final shutdown belongs after the authorized work has actually concluded, artifacts and outcome are saved, any intended review-branch push is verified, and owned workloads are stopped. It must not be triggered merely by reaching an old cutoff or finishing these three tickets. No shutdown, push or workload was performed by this reviewer.

Static review only: text/JSON/hash/read-only Git inspection. Only this review artifact was written.
