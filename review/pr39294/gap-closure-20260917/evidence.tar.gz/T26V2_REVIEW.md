# T26V2 targeted correction review

**APPROVED:** exact two C2/M2 children, normal then negative, 90 seconds each / 240 seconds total, under unchanged v2 guards and default frozen CUDA context. No remaining correction in the requested revision.

Verified SHA256:

- T26V2_REQUEST.md: `1721b36db9c98032b1994ba105d6b0ee0de6c5e65b53dd0126b47a94b00c6774`
- T26V2.json: `9bb687d311178ee89f9df5cf667d0a166f73046161550c64c2cdb526a469b50c`
- async-immutable-decision-v2-harness/probe.py: `00d790105424c3874bf05b3e86ea571a605aff8e80d4ae0c78811a26b3175379`

All manifest files match their hashes. Directory comparison shows only the two requested probe changes: the premature outstanding-wait assertion is removed, and the final wait prerequisite matches E2, the consumer stream and an outstanding event. The safety dependency assertion remains intact. A safely completed E2 without an outstanding wait now yields PARTIAL instead of an erroneous FAIL.

Normal allows only PASS/PARTIAL; negative allows only EXPECTED_FAULT_DETECTED/PARTIAL. All other case fields, source/environment pins, ordering and limits match v1 after the declared path/output rebinding. Original artifacts remain preserved.

Approval retains the T26 design review's scope: independent historical selection oracle, actual pending-event urgent dependency and payload-preserving physical reuse in the controlled FULL-owner/page1/lazy helper fixture. It does not prove snapshot completion or writes concurrent with E2, natural production-flush reachability or universal async safety. Earlier PARTIALs remain unchanged.

Launch sequentially through the bound context wrapper after cleanup and with no unresolved failure. Normal PASS plus negative EXPECTED_FAULT_DETECTED, complete source/result bindings and cleanup PASS are required before proposing a new confirmation registry. PARTIAL does not admit expansion; unexpected failures stop dependent work. No automatic retry or further cells are authorized.

Static diff/hash/manifest inspection only; no imports, workloads, GPU queries or source changes were performed.
