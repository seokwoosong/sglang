# T25 focused static review

**APPROVED for the three exact diagnostic children only**, sequentially, 60 seconds each / 240 seconds total. No executable correction is required for this exploratory scope; the reporting limitation below is mandatory. No default-context validation or allocator admission is granted.

Reviewed SHA256:

- T25_REQUEST.md: `00a8554955df831b036b35a8dfbc85a56afd040e4e2d2f9d3ac68044dcb4943b`
- T25.json: `9c3a3328d46c4f5ba8571765ed1ac7527585a481acbce29b82d725e3204829e2`
- async-queue-context-harness/probe.py: `c8c720ed3e75381c0802a03d5c9e8f3e1de7283348f37d52b14ef4d6ed176ad9`

All manifest file hashes matched. Commands select clean A, late_cat, and precisely (connections, requested consumer priority) = (32, 0), (default, -1), (32, -1).

**T24 disposition:** authoritative STATUS is COMPLETE with three PARTIAL results, exit zero and cleanup PASS. Raw results have E2 pending before late submission and complete after sentinel waits of approximately 349.7–359.9 ms. These clean diagnostic prerequisite misses do not block T25 and do not establish a functional defect. Preserve them unchanged. STATUS SHA256: `b5755e0d81dab40cd453de109a7a81996a841a823b93b9a9d1da181541dcaf10`.

The runner supplies child environment overrides to Popen, before the fresh interpreter imports torch/common/SGLang. Thus the connections setting is not being changed after those imports. Parent context remains baseline through continued_entry_v2.py; the default child inherits the unset flag, and the two altered children receive exactly `CUDA_DEVICE_MAX_CONNECTIONS=32`. The probe allows only that declared flag exception and verifies all other frozen flags and native allocator backend. Packages and production sources remain unchanged.

The source diff otherwise changes only CLI/result metadata and consumer stream construction. Original fixed sleeps, operation warmup, independent reader/consumer payloads, event ordering and overlap oracle are retained. Final host payload reads follow event completion. PASS still requires initially pending readers and E2 outstanding both before late submission and after consumer completion; missing overlap is PARTIAL, while exceptions and payload mismatches remain FAIL.

**Reporting condition:** `consumer_priority` records the requested CLI value, not a queried effective stream priority; the recorded environment flag likewise does not measure actual hardware queue assignment. Label them as requested settings. Do not claim that effective priority or queue count was verified, or infer a queue/driver root cause from these three observations. Any later helper admission relying on effective priority must record that runtime property in its separately reviewed fixture. Results under altered settings cannot replace default-context PARTIAL results or justify a production configuration change. One process per combination is diagnostic, not a statistical comparison.

Launch only through the bound context wrapper after prior cleanup and with no concurrent workload. Retain v2's 2560 MiB prelaunch and sampled >3072 MiB whole-device stop conditions, 8 GiB RSS, 32 MiB log, finite deadlines, source/environment checks and owned-process cleanup. No automatic rerun, additional setting, larger delay or source edit. Future original-helper normal/negative confirmation requires an exact context-bound review.

Static text/JSON/hash review only; no imports, workloads, GPU queries or source changes were performed.
