# T02 original-helper operation trace

Exact six-case registry T02.json, sequential after any earlier ticket is ended/disposed and cleaned. No production changes; source B/A remain pinned. All previous async15children were PARTIAL before first observation; this localizes where queued readers complete. Not an acceptance or sensitivity result.

Native: exact original torch.tensor construction; Prebuilt: previously approved index substitution; Warmed: prebuilt plus4 original-helper calls with eventNone, moving2pages to holes then back, restoring source/destination ownership and free holes. Warmup allocation/copy/remap is real and occurs before queued reader sleeps; actual payload and mapping checks retained. Finite 2e9/1e9 cycles unchanged.

sys.settrace observes original `_commit_move_batch` call/line/return boundaries, with host perf timestamps and nonblocking event.query calls; no CUDA data snapshots inside interval. Confirmation later must be untraced. Function source is never rewritten, all semantics retained. Original stale-address readers, postevent payload/reallocation and cleanup still run. Only M2 FULL-owner page1 lazy, repeat0; no negative control in diagnosis. Original after-E1 free-list tolist remains and is recognized as potentially synchronizing. Transition shows location, not conclusive causal synchronization.

8GiB RSS,3GiB absolute device,32MiB log,90s/child,900s shared and global deadline. Review `async-diagnosis-harness/probe.py`, common/env and reused ticket_runner.py hashes. Proposed outputPASS/PARTIAL describes inherited checks only; result status must not be interpreted as uninstrumented concurrency closure.
