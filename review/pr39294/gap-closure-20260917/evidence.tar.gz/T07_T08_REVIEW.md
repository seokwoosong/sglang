# T07 / T08 focused static review

**T07: APPROVED, conditional finite diagnosis.**

**T08: APPROVED, conditional two-child distinct-event admission test.** No mandatory executable correction is identified. Approval is limited to the exact manifests and gates below; it does not admit a pattern before its results exist or authorize further confirmation cells.

Review was static: source/diff/manifest/hash inspection and existing T05 JSON evidence only. No submitted module imports, workloads, GPU queries, installations or source edits were performed.

## Identity

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T07_T08_REQUEST.md | `dace2d93d45d73b0532c6272e9d8c9f4eb248d31cd58a78c66e721ad22a48769` |
| T07.json | `c10e13eb15fc4c81882ff56317e594ec5653d18e2cefd9eb31e4d84a055a1d83` |
| T08.json | `39d62e0297d0e6cb1689345c156b0c43aa48f95761b4eecd130f395848928736` |
| async-observation-harness/probe.py | `fa72b06d23f031cf5822338b0f1bb604760325297825ad2b71c450eca7716e86` |
| t07_entry.py | `7bdd54c5932953bc6e27795bbdbdf6220d1ec529e30426a5216f864d1f7c5edc` |
| t08_entry.py | `55e2d76d018ad87427563d6b6f798930b26f802619e0a58b692fe27f6b75e45d` |

All manifest file hashes matched. Shared common fixture hash is `3ba8856548e462a4fa11424bb3eac8a8f1984fbef5454b8f5f6fe137f97bda56`; shared runner remains `14d60a8f9e30a09891cf2d0b08e1e8346ecc4f8879c28c9bee901267a474efe1`. A is pinned to `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`; C is that HEAD plus the exact reviewed diff `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3`.

## Existing evidence and diagnostic scope

T05's authoritative record is COMPLETE, with two PARTIAL children and both cleanup results PASS. Its schedule case records a roughly 770.63 ms first reader call. The warmed-reader case records both events outstanding after commit, E2 outstanding before the nonurgent drain/snapshot interval, and E2 complete afterward; the actual free-list snapshot is `[142]` with CPU pending source `143`. This justifies separating drain and snapshot observations. It does not identify a particular CUDA synchronization mechanism or retroactively establish a producer-only cause.

T07 removes helper line tracing and scheduling hooks, retains original helper/copy/remap/drain calls with the disclosed prebuilt-index substitution, and compares three fixed A/M2/FULL/page-1/lazy variants: blocking, warm_blocking and pinned. Exactly three children, 90 seconds each, 360 seconds total, once. The extra warmup combines CUDA concatenation and pinned copies, so any improvement localizes a combined warmup effect; it does not independently identify which warmup operation caused it. Single diagnostic observations are not timing estimates or causal proof.

## D2H and oracle assessment

The pinned path reads the actual allocator free-list tensor, not reconstructed pending metadata. The pinned host buffer is allocated and verified before the target interval; its capacity is two int64 entries, with a checked bound and an empty-list fast path. In this single-threaded worker, leaving the producer stream context restores the recorded consumer stream. The copy and subsequent `copy_done.record(consumer)` therefore have the correct stream order. Waiting for that event before CPU `.tolist()` makes the host read safe; the tensor and host buffer remain live through completion. Reusing the event after completed warmups is valid.

The observer waits for consumer-copy completion, not intentionally for producer E2. Implicit serialization may still occur in this environment; the post-snapshot E2 query prevents that from being misclassified as preserved overlap. E2 is not re-recorded during the observed interval. Requiring it still outstanding after the snapshot, as well as both events outstanding after commit and E2 outstanding before drain, preserves the nonvacuous prerequisite. Missing overlap remains PARTIAL.

The normal oracle checks actual free-list membership and pending protection independently of the injected association, then checks urgent stream dependency, actual source-two reuse, old reader payload, retained/new payload and accounting. The negative child deliberately associates batch two with E1 while the real reader remains ordered before E2. Its expected signature requires source two to appear in the actual reusable list while E2 is outstanding; merely detecting changed metadata is insufficient. It explicitly waits E2 on the consumer before new writes. Thus sensitivity can be demonstrated without deliberately racing an overwrite. Other payload/accounting failures remain FAIL, not expected faults.

## T08 gates and interpretation

Authorize exactly pinned C normal, then pinned C negative: 90 seconds each, 240 seconds total, once, through `t08_entry.py`. These consume two cells of the existing 24-cell confirmation allowance.

Before launch, retain the exact T07 manifest/status/result binding and verify T07 COMPLETE without faults, all cleanup PASS, and **pinned-A worker PASS** with its overlap/reuse prerequisites. Runner PASS alone is insufficient because it also permits PARTIAL. The entry wrapper checks CUDA context, not this result gate; the executor must enforce the gate explicitly.

Both T08 children may run if the normal child is merely PARTIAL, as requested; an unexpected FAIL still stops the runner. Distinct-event admission requires C normal PASS **and** negative EXPECTED_FAULT_DETECTED, with valid runner/provenance/cleanup records. Either PARTIAL leaves admission incomplete and prevents expansion or retries. No same-event, additional owner/layout, full production-flush reachability or universal async-safety claim is authorized.

## Execution limits

Use the hashed entry wrappers so parent and child CUDA-context checks remain active. Preserve the original fixed 2-billion/1-billion-cycle observed delays, pre-interval one-cycle warmups, 3 GiB whole-device/headroom guard, 8 GiB RSS, 32 MiB per-child log and bounded owned-process-group cleanup. No delay increase, production modification or additional attempt is approved.

Wait for T04V2 and any preceding workload to finish or receive disposition and complete cleanup; never overlap tickets. A performance-only miss may leave independent T07 A diagnosis eligible as requested, without adopting C1. It does not silently release other C1-dependent gates; retain their applicable disposition requirements. Any new functional/provenance/resource failure holds dependent work. Existing C1 correctness/source/environment requirements remain in force for T08.

The absolute execution cutoff remains **2026-09-16 22:07:44 UTC** and final cleanup/reporting deadline **22:17:44 UTC**. No budget reset, serving, source adoption, push or merge is authorized by this review.
