import json,os,runpy,sys
from pathlib import Path
r=Path(__file__).resolve().parent
context=json.loads((r/'CUDA_CONTEXT.json').read_text())
assert {k:os.environ.get(k) for k in context['flags']}==context['flags'],'PARENT_CUDA_CONTEXT_DRIFT'
sys.argv=[str(r/'ticket_runner.py'),str(r/'T07.json')]
runpy.run_path(str(r/'ticket_runner.py'),run_name='__main__')
