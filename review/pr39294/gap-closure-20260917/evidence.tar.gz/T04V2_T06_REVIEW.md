# T04 stop disposition, T04 v2 and T06 static review

**T04 stop: DISPOSED as a measurement-harness serialization comparison error.** Preserve the original FAIL.

**T05: RELEASED under its existing exact approval and sequential cleanup conditions.**

**T04V2 and summarize_cost_v3.py: APPROVED for the requested finite fresh measurement and analysis.**

**T06: CHANGES_REQUESTED. Do not execute the submitted 12-child ticket.** The eager gate fixture violates the public gate API contract; correct that fixture scope and strengthen the closed-gate copy oracle as specified below.

This review used static source/diff/manifest/hash inspection and existing JSON/log evidence. No submitted modules were imported, workloads or tests executed, GPU queried, packages installed, or source/harness files modified.

## Reviewed identities

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T04V2_T06_REQUEST.md | `f209b11492b2d810b086d5a5cf692cda5205ab20e225084906f69d7b126aee4b` |
| T04V2.json | `8fcf171122f28a25577abbe86e198005ef9d90269c1619f27f359d58363c5269` |
| cpu-harness-v2/cost.py | `074e9a6b3e2055cff24781cd7eea9e11d688cfb0c88cff745e7cc13f71e43d8c` |
| summarize_cost_v3.py | `a2bc6d91680ae7a409037062fbc6be0ce97491a15847059f69422706ddfe77e5` |
| T06.json | `5ac5fc01c308b66e7338c62b467331b2d5e1f73f11c089cf1026bedb53ac79df` |
| cuda-regression-harness/probe.py | `c4c456a74acefd59b4a5691b058da3d7a9a117b2581de84982dd6bdca32afa76` |
| cuda-regression-harness/p1-registry.json | `ee706bcc270d2e7e206a32b8113567a7cff9cbace759ec1bef0144afa062dc38` |
| original T04 STATUS.json | `4b5bfbf7849737846cc5720540796c4fe73d8968923982e9f22a6332384dccd3` |
| original T04 0-A.json | `99fc1b3d77b35283652a3d027108e36b7fd647cb65fcf2df7d450209b9f034fb` |
| original T04 0-B.json | `5324e18c4eb2fe617fde3880070182dc0dd39aba862470566b0231f7b413bff4` |

Every file hash listed in T04V2/T06 matched. The candidate's actual binary diff remains `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3` against A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`.

## T04 stop and independent T05 release

The authoritative runner stopped after 0-B PASS and 0-A exit 1; both cleanup results are PASS. The A traceback points to the post-measurement `INITIAL_STATE_MISMATCH` comparison. Independently comparing the saved JSON confirms identical scenario configurations/initial states, package environments and CPU contexts. `Fixture.geometry()` retains the live `(1, 1)` tuple, whereas reading the prior arm's JSON produces `[1, 1]`. The old direct comparison therefore rejects equal serialized geometry.

This supports classification as a harness comparison defect, not an allocator invariant, payload or capacity failure. A completed its local measurements before the comparison failed; those raw measurements remain failed-run evidence, not an accepted paired result. No C child ran and there is no complete B/A/C validation block. Preserve all original artifacts and exclude the entire old run from the fresh validation set.

The recorded run lasted about 62.04 seconds from runner start to end, so the requested 70-second debit is conservative. This known, cleaned-up harness stop does not hold the independent, already-approved T05 diagnostic ticket. T05 may execute its exact two children once under `/tmp/PR39294_T05_ANALYSIS_REVIEW.md`, after any currently active workload has completed and been cleaned up. This release does not authorize overlap or another T05 attempt.

## T04V2 — APPROVED

The cost-worker diff is confined to serializing both state-comparison operands with sorted JSON keys outside the timed region. It preserves ordered arrays and all state values while normalizing tuple/list representation. Reset checks within the same process, fixture construction, scenarios, source, timed evict+alloc interval and payload/accounting checks are unchanged.

The 36 case records differ from T04 only in worker/output paths. Approve one fresh set of twelve balanced B/A/C blocks, five scenarios, two warmups and five measurements per scenario: 360 warmups and 900 measured operations. Use the new output directory, 90-second child limits and **2330-second total ceiling**, not a renewed 2400-second allowance. As before, the total ceiling can truncate the sum of child maxima; unfinished work remains incomplete without automatic reruns.

The analysis v3 diff changes only the execution manifest, input registry/results directory and output filename. The accepted v2 runner/result/source/scenario validation and complete-valid-run CI gate are preserved. Use v3 only after the new run is finalized; do not mix original T04 arms into it. Keep the adaptive-selection caveat and unresolved-control-deterioration hold. A failed identity assertion is an analysis failure, not a reason to bypass validation.

Existing T01 correctness/source/environment prerequisites remain required. This approval does not independently accept the reported T03 results or C1 for adoption.

## T06 — mandatory corrections

1. **Remove the invalid eager gate recovery case, or explicitly separate it as an API-rejection test.** Registry `gate-0` sets `lazy=false`. The worker calls `a.set_disagg_move_gate(...)` at line 99. That public setter passes the composite flag to `install_move_gate`; `unified_sub_pool.py:258` asserts `lazy_compaction`, explaining that eager free-path movement is incompatible with in-flight transfers. Both gate-0 A/C children will therefore fail before the claimed close/reopen recovery observation. Prefer omitting these two children and honestly reporting lazy-only gate recovery coverage (ten total children, no replacement or budget increase). An explicit expected-rejection fixture is another possible submission, but is not recovery coverage. Do not bypass the contract by assigning gates directly or changing production behavior.
2. **Assert zero closed-gate copies using the existing observer.** Snapshot per-owner copy counters immediately before the closed `ensure_capacity(6,6)` and require zero copy-call/physical-page deltas before opening the gate. Keep the false return, unchanged allocator snapshot and protected payload checks. Current lines 101–102 only compare allocator metadata and payload; these do not exclude a copy that preserves the final mapping/content. The existing counters already provide the necessary evidence without new instrumentation or resource cost. A no-op preparation call is distinct from actual copying and need not be prohibited.

The other reviewed checks are appropriate for the stated synchronous functional scope: ready-path allocation with all 96 cached tokens retained; reclaim retaining exactly 95 of 96, retired-owner-aware payload checks, and actual retained SWA/Mamba mapping changes plus nonzero real-copy counters. Page size 1 makes the virtual-page retirement mask consistent. The gate fixture protects request-owned nonempty Mamba state and all allocated KV, and requires actual retained SWA movement after reopening. Missing reclaim movement remains PARTIAL, never case validation. The unused modeled-event/kernel branches are outside the six-case registry and receive no execution authorization.

Resubmit only the corrected T06 registry/manifest/worker for focused review. Retain the proposed prerequisite of T04V2 complete-valid performance with no unresolved material deterioration and unchanged C1 correctness/source identity. This request does not authorize running a manually sliced version of the rejected manifest.

## Unchanged limits

All authorized execution is sequential, with the shared runner's 8 GiB RSS, 32 MiB per-child log, bounded process-group cleanup and GPU 3 GiB whole-device/headroom guards where applicable. Failures require disposition; no automatic retries or favorable-result replacement. The absolute execution cutoff remains **2026-09-16 22:07:44 UTC**, with final cleanup/reporting by **22:17:44 UTC**. No source adoption, serving, push or merge is authorized here.
