# PR39294 T01 / C1 focused executable review

**Decision: CHANGES_REQUESTED — correct the paged test fixture and deadline enforcement before running T01.**

Static review of `C1.diff`, `T01.json`, `ticket_runner.py`, `correctness_entry.py`, and relevant candidate source/tests. The isolated worktree is at A `15ccf48036bf5de0ec0aa886dedaa74bbdea8123` with exactly the two reported tracked modifications. Its binary HEAD diff matches `C1.diff` and the ticket's diff hash. Ticket file hashes match. No workloads, imports, GPU queries or source modifications were performed.

## C1 production change: acceptable for correctness testing

The added condition follows the existing deferred-FULL-free boundary and demand rounding. `_token_id_capacity(num_tokens)` checks FULL logical IDs and SWA page headroom, and joint `available_size()` models immediate allocation geometry on the physical page grids. The same conjunction is already the immediate-success branch of tri `ensure_capacity()`. It does not use independent availability minima, nominal conservation limits or pending/recoverable byte credit.

Null/chunk-cache and nonpositive-demand behavior, rank-consensus decoration, impossible-demand protection on the fallback, recovery sequencing and quota logic are unchanged. On a valid immediately feasible state, reclaim-count and optimistic-bound queries are unnecessary. On a false check, the old path still executes. No production-code correction is identified for this narrow change at static review. This is not correctness, performance or adoption acceptance before tests.

## Required corrections

1. **The new page-size 4 cache fixture violates an existing constructor contract.** `test_unified_tri_joint_reclaim.py:402–406` calls `self.build(page_size=4, ...)` with its default `state_cache=True`. That build includes `ComponentType.MAMBA`, while `CacheInitParams.enable_mamba_extra_buffer` defaults to false. `unified_cache/components/mamba.py:68–71` explicitly requires page size 1 in that configuration. Thus the Python test fails at cache construction before exercising C1; this is a statically identified fixture defect, not an observed allocator failure.

   Keep genuine cache-owned Mamba coverage at page size 1. For page size 4, use the supported FULL+SWA cache with request-owned Mamba states, and insert KV entries without claiming Mamba checkpoint-cache participation. Continue stamping/checking those live states, retained KV, allocation and accounting for eager and lazy arms. Do not disable the assertion, invent an extra-buffer configuration solely to pass, or silently discard paged coverage. The test currently uses an empty temporal shape, so describe its new state-payload coverage as conv coverage; existing nonempty-temporal regressions remain separate.

2. **The new general ticket runner does not yet enforce its finite deadline on all paths.** In `ticket_runner.py`, the ticket clock starts after imports/setup (line 8), `source_check()` performs three Git subprocesses with no timeout (lines 13–15), and the only prelaunch time check precedes that unbounded work. `Popen` at line 45 has no fresh cutoff check. Inside monitoring, `NoSuchProcess` immediately continues at line 49 before the time check, and a child observed exited after the deadline can bypass the loop and be accepted at lines 58–62.

   Start ticket timing before third-party imports/setup, retain the fixed global mapping, and give each Git/environment subprocess a finite timeout clipped to remaining execution time. Recheck the deadline immediately before launch. Check time on every polling path, including disappearing-process paths; do not busy-loop past it. Before accepting success, require completion to have been observed within the allowed deadline and retain final log-limit checking. Preserve a recorded/nonzero child failure ahead of a coincident timeout classification. Keep TERM/KILL, survivor checks and final status/ledger writes within a finite cleanup allowance. No child may start or remain intentionally running beyond the reviewed execution cutoff.

   For this ticket, `min(ticket start + 1200s, 2026-09-16 22:07:44 UTC)` and its existing 15-second reserve may remain unchanged. Two top-level suite processes at up to 300s each do not require more budget. No GPU preflight is needed or authorized for these CPU cases.

Refresh the candidate diff/source/test hashes and ticket/runner hashes after these corrections and submit a targeted static revision. **T01 is not execution-approved yet.** Do not use this rejection to reset the global eight-hour clock.

## Otherwise accepted execution design

The Python command selects 17 explicit test files; the Rust command selects three explicit files and excludes names containing `session`. `-x`, no pytest cache provider, fixed CPU engine/backend settings and sequential execution are appropriate. Required timeouts/skips/exclusions must remain visible and do not constitute a full pass. Tests may spawn their own bounded helpers (for example rank-consensus); those are descendants within the same suite budget/resource supervision, not additional uncharged tickets.

`correctness_entry.py` validates the imported hybrid allocator path and frozen environment before pytest. The Rust branch imports the actual extension and records/checks its binary SHA256 `1709a59dc2fb15a0f27e6bbce0dcb0d4906e39c0ec5e42a50bac19b886b6d42d`, with build mode `never`. Keep that provenance; an unavailable or different extension requires disposition, not automatic rebuild or Python fallback. The Rust lane is the specified supported subset, not blanket parity for every Python test.

The dirty isolated candidate is adequately identified for this proposed test by pinned HEAD plus exact binary diff, individual changed-file hashes, no untracked files, and pre/post source checks. Preserve this identity after the fixture correction. No commit/adoption is required to run an accepted correctness ticket, but timing, CUDA confirmation and adoption remain separate reviews.

Retain 8GiB aggregate RSS, 32MiB log cap, owned-process-group cleanup and survivor failure handling. An unexpected test/resource/provenance/cleanup failure stops subsequent cases and dependent tickets. No package changes, GPU workload, source workaround or remote action is included.

## Reviewed identities

Artifact root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.
Candidate root: `/home/sukwoo24/sglang-eval-worktrees/pr39294-gap-c1`.

| Artifact | SHA256 |
|---|---|
| T01.json | `d9da2a9228f78e926ea06008e0b3d90983cb830974b44317abc119ef8dddd0a9` |
| C1.diff / actual binary HEAD diff | `d864178289942b954c688aa3773e7f70d0641b8d10828b7982dc352b1031cf70` |
| ticket_runner.py | `7d4d3f6488ef1338bd4193ec7abc05ff126c062ec05b7d019b42b39b654dc9f3` |
| correctness_entry.py | `9520e2b218fc82ddaef60ffd2598273fddb7de6f58b15b940e8e7b9cf09591fd` |
| candidate unified_hybrid_swa.py | `7dd9f6754326dcc2b61afe250cab971ac03d490a1fff327c6ebcaf9945d6ac59` |
| candidate test_unified_tri_joint_reclaim.py | `f51c468e736d087a07afc4a5bb82bc5183fbe470e38c446845c7f216418e1a15` |
| ENVIRONMENT.json | `d215513feca6e8c28b2c654268a464435ff00dbed7a187297cb9f7d2874cc472` |

Only this review artifact was written by the reviewer. The existing accepted production checkpoint is unchanged.
