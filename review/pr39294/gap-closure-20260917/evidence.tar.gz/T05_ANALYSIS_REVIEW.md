# T05 and T04 analysis v2 — focused static disposition

**T05: APPROVED, conditional finite diagnostic execution.**

**ANALYSIS_V2 / summarize_cost_v2.py: APPROVED for analysis of the exact approved T04 run.** The two mandatory summary corrections in `PR39294_T02V2_T03_T04_REVIEW.md` are satisfied. These are independent approvals; neither is candidate acceptance, a performance result, or a general async-safety conclusion.

Review used static file/diff/hash inspection and existing T02 JSON evidence only. No submitted module imports, workloads, GPU queries, installations or source edits were performed.

## Exact reviewed identities

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T05_REQUEST.md | `bd9617e40b40db3deb173bed45e559436349a87fb4a687087fd7d16562fd0efe` |
| T05.json | `dd417ae4ab567014119d755397191ce04229decc656924714202d083ffc37e47` |
| t05_entry.py | `9cd81384610995c11f661cc71c3864fea16199221ede9821133164cb454e52e3` |
| async-schedule-harness/probe.py | `33621cc59c984767a750bbf4303bc656dba29aec2dc1fb1715e57136e696dba3` |
| ANALYSIS_V2.json | `33928f6ed0be7f8ab5cb2450b452d87ebb5ddacf811ba44a0e157647d89c419e` |
| summarize_cost_v2.py | `732bc49af430a857ca4dd076c14e3c80efc90b530ecb5f57325df4674a245abe` |
| unchanged T04.json | `701b608916ba457978dcdf978ee12ad5a35f52d2de3ebc8525524b23806d5ffc` |

All T05 manifest file hashes matched, including the unchanged runner, environment checker, CUDA context and common fixture. The analysis manifest's script and execution-manifest hashes also match.

## T05 scope and conditions

Authorize exactly `schedule-A` and `warm_readers-A`, once, through `t05_entry.py`: frozen A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, M2 FULL owner, page size 1, lazy mode, repeat 0, no negative arm. Each child remains capped at 90 seconds, with a 300-second ticket ceiling. Retain the existing 8 GiB RSS, 32 MiB child-log, 3 GiB whole-device and prelaunch headroom guards, source/environment checks and owned-process-group cleanup.

Both variants restore mappings after the four original-helper warmups. The extra reader/event warmup writes only the reader output buffers, uses one-cycle sleeps, and synchronizes before the actual observation interval. Re-recording the same completed events is appropriate here; `recorded` is reset so warmup completion is not mistaken for completion of the current readers. The observed sequence retains the original 2-billion/1-billion-cycle delays. The six scheduling observations and subsequent helper line trace are diagnostic instrumentation, not production changes.

The existing T02 runner record is COMPLETE with all six child results PARTIAL and cleanup PASS. Warmed A/B show E2 outstanding around nonurgent drain, an outstanding E2 wait on the consumer, and source reuse, but fail the both-outstanding prerequisite. Preserve this partial status.

Interpretation condition: all inspected T02 arms record `before_commit_events_complete=[false,false]`, followed by the first helper trace `[true,false]`. Thus current evidence also leaves the interval between that observation and helper entry relevant. T05 may locate scheduling delays or show a warmup effect, but cannot by itself prove that producer scheduling caused the lost E1 overlap. Query/tracing and patch-context setup overhead remain possible contributors. Do not turn a lack of reproduction into a synchronization-cause claim or increase sleeps/repeat cases to obtain a pass.

PASS remains confined to this instrumented helper fixture with its existing pending-membership, urgent dependency, actual source reuse, payload and accounting checks. Missing prerequisites remain PARTIAL; unexpected failures stop dependent work. Uninstrumented confirmation, sensitivity controls, other layouts, and C1 GPU validation require separate concrete review.

Run only after preceding work has completed or received disposition and its owned processes are cleaned up; no overlap with T03/T04 or other workloads. Preserve the absolute execution cutoff **2026-09-16 22:07:44 UTC** and final cleanup/report deadline **22:17:44 UTC**. This approval does not reset budgets or authorize retries.

## Analysis v2 acceptance

The revised analyzer now binds ticket/manifest identity, unique known runner rows, exact commands/result paths, runner PASS, exit 0, cleanup PASS and result PASS. It checks source HEAD/cwd/import location and C1 diff identity, parent/child environment, scenario identities and status, two warmups, and five finite positive measurements. It also compares block CPU context and initial states. Ticket-level provenance/supervision failure is not silently salvaged; partial cases retain exclusion reasons. Conservatively excluding the final row on an incomplete ticket is acceptable.

Both confidence intervals and the primary margin criterion now share `complete_valid`: COMPLETE, all 36 accepted rows and twelve valid blocks, without exclusions. Otherwise only accepted complete blocks are described, the verdict is INCONCLUSIVE, and no confidence interval or primary margin conclusion is emitted. The predeclared seed, resampling unit, thresholds and adaptive-selection caveat remain unchanged.

Use this exact v2 analyzer after T04 is stopped/finalized and its process cleanup is settled; preserve the raw runner/results and bind the resulting analysis to `ANALYSIS_V2.json`. No measurement rerun or T04 manifest modification is required. The original summarizer remains superseded. An analyzer assertion/identity failure must be reported as an analysis failure, never bypassed or presented using a stale `COST_ANALYSIS.json`.

No further mandatory correction is identified for these exact submissions. Existing correctness prerequisites and the hold on adoption for unresolved material control deterioration remain in force. This review does not independently accept T01/T03/T04 execution results.
