# T03/T04 conditional measurement review

T03.json = A/C2 diagnostic pairs,4children60s,300s ticket. T04.json = balanced B/A/C12 independent blocks,36children90s,2400s ticket. Both use accepted generic ticket_runner.py and source C1=A+reviewed binary diff7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3 (dirty isolated worktree, no adoption). Run only after T01 BOTH required suites COMPLETE and unchanged source/env; no unresolved stop; sequential no workload overlap.

Workers copied from prior reviewed followup CPU harness. common.py change limited to C identity validation by exact HEAD+binary diff and no untracked files. Fixture mechanics unchanged. cost.py adds out-of-timing earlier-arm comparisons in same block: config+initial geometry/snapshot, CPU affinity/threads/env and package identity must match before child statusPASS. Every cost block uses order BAC,BCA,ABC,ACB,CBA,CAB repeated. Diagnostic registry filters3ready scenarios; cost preserves all5scenarios. Exact warmup/sample counts unchanged.

The diagnostic and cost output paths are separate. There is no benchmark here of serving or model accuracy. T3-ready is primary; summarize_cost.py freezes12completeblock supplementary bootstrap10kseed39294, correct block-associated comparisons C/A,C/B, margincriterion and controls vsA. Prior failed/incomplete blocks are preserved. Nominal intervals after adaptive development are not selection-adjusted.

T02 diagnosis may run before or after these CPU tickets but never overlap. If T01/T03/T04 fails, obtain concrete disposition before dependent work. If T02 completes diagnostically PARTIAL without faults, that does not block independent CPUcost; no asyncsafety claim follows. No automatic restarts or source change after candidate nomination.
