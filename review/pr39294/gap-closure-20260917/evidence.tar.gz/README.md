# PR39294 gap-closure execution

Current authorization: execute the plan and continue evidence-driven fixes/tests within **2026-09-16 14:17:44–22:17:44 UTC**. Workload cutoff22:07:44UTC; final10min cleanup/reporting. No push/PR mutation/package changes.

Read [eight-hour amendment](EIGHT_HOUR_AMENDMENT.md) and [approval](EIGHT_HOUR_REVIEW.md) first. They supersede PLAN.md's old plan-only/120min/candidate-count restrictions. [V1 review](PLAN_V1_REVIEW.md) supplies the six incorporated refinements. Source C1 is isolated from the accepted review branch; it is not adopted merely because a ticket is approved.

Tickets:
- T01: Python/Rust correctness of immediate T3-ready fast path. V1 rejected statically for fixture/deadline defects; no workload ran. V2 reviewed separately.
- T02: A/B native/prebuilt/warmed original move-helper operation tracing, diagnostic only.
- T03: A/C instrumented CPU call-path diagnosis (conditional on correctness).
- T04: fresh balanced B/A/C12block uninstrumented cost comparison (conditional on source/correctness/measurement review).

Execution statuses and append-only LEDGER.jsonl distinguish planned, approved and executed. Historical results remain under `pr39294-followup-20260916` and are not pooled into new validation.

Additional tickets (2026-09-16 execution):
- T04 original stopped for fixture tuple/list serialization mismatch; immutable failure and disposition retained. T04V2 is the fresh 12-block run with canonical JSON comparisons. Only `summarize_cost_v3.py` analyzes that run.
- T05 diagnosed first-use reader overhead and narrowed remaining lost overlap to drain/snapshot. Both cases PARTIAL.
- T06 v2: approved, conditional ten-case A/C synchronized CUDA ready/reclaim/gate regression.
- T07: approved three-case observation diagnosis; pinned D2H is compared with blocking and warmed blocking snapshots.
- T08: approved, conditional distinct-event M2 normal/negative admission.
- T09: approved, conditional same-event M2 normal/negative admission.
- T10D/T10S: proposed remaining ten cases per independently admitted pattern; exact review pending.

A COMPLETE runner status can contain PARTIAL workers. Admission and coverage always use the individual worker results and independent event/reuse prerequisites, never runner completion alone. No candidate has been adopted or pushed.

Later diagnoses and candidate C2:
- C1's full T04V2 measurement missed the unchanged absolute 5-us CI criterion; `COST_ANALYSIS_V3.json` retains the result. No adoption.
- T11 profiled B/C1 residual work. T12 CUDA tracing failed CUPTI initialization; the validity gate rejected its CPU-only trace, and T13's review disposed that tooling failure.
- T13 demonstrated stream-choice-sensitive behavior without an SGLang allocator. This is not a driver-root-cause proof.
- C2 preserves both ID checks and additionally skips no-op closed-group dispatch and the unused ready-path import. T14 Python/Rust correctness passed. Exact source diff is `C2.patch`.
- T15 C2 diagnostic passed and confirmed the no-op calls disappear. T16 is the separately approved fresh 12-block C2 cost validation; `summarize_c2_cost.py` is its only approved analyzer. T17 CUDA regressions are conditional on its acceptance.
- T18 explicit-consumer normal diagnosis: same-event PASS, distinct-event PARTIAL during nonempty D2H snapshot.
- T19S/T20S are approved C2 same-event admission/conditional confirmation. T21 is an approved A-only distinct diagnostic using an immutable GPU snapshot read back after E2. These do not release old T08/T09/T10.

Consult each ticket's STATUS and individual result files for current execution state; prospective approval alone is never a passing result.
