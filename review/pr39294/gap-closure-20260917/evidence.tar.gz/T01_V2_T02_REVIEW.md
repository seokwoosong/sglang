# PR39294 T01 revision and T02 diagnosis review

**T01 v2: APPROVED — exact correctness ticket only.**

**T02: CHANGES_REQUESTED — record and bind the CUDA execution context before the six-child diagnosis.**

Focused static review of the refreshed tickets, candidate diff, shared runner, entrypoint and diagnostic probe. File hashes match their tickets. The actual C1 binary HEAD diff matches the refreshed artifact. No workloads, submitted imports, GPU queries or source modifications were performed. The decisions are independent; T02's requested refinement does not hold an otherwise released T01.

## T01 corrections accepted

The page-size 4 case now constructs only FULL+SWA cache components, inserts KV without Mamba cache metadata and retains its Mamba states as request-owned data. Page-size 1 retains genuine Mamba checkpoint-cache participation. Eager/lazy allocation, unchanged helper snapshot, retained prefixes, live KV/conv payload and accounting remain checked. The three-line production delta is unchanged and retains the previously reviewed immediate-capacity proof. New temporal-payload coverage is not claimed.

The runner now starts timing before imports/setup, bounds Git/environment subprocesses by remaining execution time, checks immediately before launch and on every polling path, rejects late-observed successful exit, preserves nonzero exit precedence, checks the final log size and bounds cleanup waits/survivor inspection. The source pre/post checks and append-only ticket ledger remain. No further mandatory correction is identified for the exact CPU ticket.

Authorize `ticket_runner.py T01.json` once with the pinned virtual-environment interpreter and assertions enabled. It runs the unchanged Python 17-file suite followed by the Rust three-file subset, each at most 300s, within the 1200s ticket ceiling and 15s reserve. The effective deadline remains clipped to **2026-09-16 22:07:44 UTC**; preparation and this review count toward the global eight hours, whose hard report/cleanup end remains **22:17:44 UTC**.

Require prior owned-process cleanup, no concurrent workload and no unresolved preceding failure. Retain 8GiB aggregate RSS, 32MiB logs, CPU device settings and immutable environment. The entrypoint's real Rust binary provenance/hash check and build mode `never` remain mandatory. Preserve skips and `not session` exclusions; do not call this universal Rust parity. A timeout, failed test, source/environment mismatch or cleanup failure stops the second suite and dependent work for disposition. No retry, performance measurement, CUDA validation, installation or adoption is included.

## T02 required refinement

The package/environment digest does not capture inherited CUDA behavior flags. T02's case environments leave those flags inherited, and the probe does not record them or its actual producer/consumer stream identities. This matters directly to the question being diagnosed: a launch-blocking or allocator configuration difference can cause both queued events to complete before the first helper observation, indistinguishable in the present output from a fixture/operation effect. The approved plan explicitly requires freezing this context.

Before execution, bind and record the relevant inherited settings, including unset values: `CUDA_LAUNCH_BLOCKING`, allocator configuration (`PYTORCH_CUDA_ALLOC_CONF` / `PYTORCH_ALLOC_CONF`) and any explicitly configured default-stream behavior. Record actual producer and consumer stream/device identities and the selected allocator backend when exposed by the frozen runtime. Place all such inspection before scheduling the reader interval. Make the parent/child provenance reject drift across the six cases. Do not silently change those settings to obtain overlap; if a nondefault setting motivates a changed experiment, disclose it in the revised ticket.

Refresh the affected probe/ticket hashes and submit the minimal static revision. No additional cases, warmup iterations, longer sleeps or budget are needed. **T02 is not execution-approved by this artifact.**

## T02 design otherwise accepted

- The registry is exactly native, prebuilt and warmed × B/A, six normal M2/FULL/page-one/lazy children. No negative control or C workload is included. Clean B/A source and environment checks remain; C1 correctness is not being inferred from this diagnosis.
- Native retains original index construction. Prebuilt retains the previously reviewed scalar-index substitution. Warmed makes four original-helper calls with no event, moving the two pages into holes and back before scheduling readers, then checks retained payload/accounting. No production copy, remap or pending bookkeeping is replaced.
- `sys.settrace` observes the original helper rather than reconstructing it. Query timestamps and line transitions can bound the first observed completion interval, but tracing all Python calls itself perturbs scheduling. A completion transition is not proof that the preceding line synchronizes CUDA. A native-index **helper** invocation is still not natural full production `_flush` reachability evidence.
- No device snapshot is added inside the traced helper interval. The later free-list `tolist()` remains potentially synchronizing and must be reported as such. Keep the original physical reader indices, stream-ordering, reader-two reuse and payload/accounting checks.
- Preserve partial trace rows on exceptional exit where possible: currently `row['commit_trace']` is assigned only after both helper calls return. Moving trace attachment to an exception-safe output path would retain useful diagnostic evidence without changing the measured operations. This is a recommended evidence improvement, not an additional experimental lane.
- Child PASS/PARTIAL describes inherited checks under tracing, not uninstrumented concurrency closure or detector sensitivity. The runner's case PASS means allowed child completion; retain `result_status=PARTIAL` visibly rather than summarizing it as a coverage pass. There are no sensitivity controls in T02.

The proposed unchanged bounds are appropriate: 900s ticket, six children at 90s each, final 15s reserve, 8GiB RSS/32MiB log per child, sampled absolute whole-device 3GiB guard and used≤2GiB/free≥1GiB launch prerequisite. Telemetry is bounded and fails closed. No retries or workload overlap. Correct the stale 45s cleanup comment when updating documentation; the executable ticket supplies 90s. Execution, after revision acceptance, must await earlier ticket completion/disposition and cleanup. A recorded new failure still holds dependent work, while a cleanly completed diagnostic PARTIAL may inform a separately reviewed correction.

## Exact reviewed identities

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T01.json | `4048a07b4cb1abb8f99a9e64861eac364c1b2144fc4cc10ec5fae0ac8d28533e` |
| C1.diff / actual binary HEAD diff | `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3` |
| candidate tri reclaim test | `d25832d3ac398b553769f63c48c5b11f7a8cf2d8e17c694e856a75b66cc9745f` |
| ticket_runner.py | `14d60a8f9e30a09891cf2d0b08e1e8346ecc4f8879c28c9bee901267a474efe1` |
| correctness_entry.py | `9520e2b218fc82ddaef60ffd2598273fddb7de6f58b15b940e8e7b9cf09591fd` |
| T02_REQUEST.md | `d47dfd078b2986d0d53b12af7c1610d94deee8cc43b034350ce214dbbb1d9189` |
| T02.json | `1a217b3b4efa92e9ba5cdce703df7b8b38316d354abf195547790ac987eb1b46` |
| async-diagnosis-harness/probe.py | `73c747264eeb81a585ee2b36e0ed394ac7e4461b54ab4636d4acf25432d2ac45` |
| async-diagnosis-harness/common.py | `ca382edf139e856bf285594ac0bc156e00351fe7b8f29a9c9a19df126ad152c2` |
| ENVIRONMENT.json | `d215513feca6e8c28b2c654268a464435ff00dbed7a187297cb9f7d2874cc472` |

C1 remains dirty isolated A plus the exact reviewed diff, without commit/adoption. No remote action or broader execution is authorized. Only this review artifact was written.
