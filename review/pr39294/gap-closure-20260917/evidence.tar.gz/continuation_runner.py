"""Finite sequential ticket executor. Never retries or changes a registry."""
import time
TICKET_STARTED=time.monotonic();WALL_STARTED=time.time()
import argparse,datetime,hashlib,json,os,signal,subprocess
from pathlib import Path
import psutil
from env_check import verify_environment
p=argparse.ArgumentParser();p.add_argument('ticket');args=p.parse_args();root=Path(__file__).resolve().parent
manifest=Path(args.ticket).resolve();m=json.loads(manifest.read_text());out=root/m['id'];out.mkdir(exist_ok=False)
start=TICKET_STARTED;global_cutoff=start+m['seconds'];end=min(start+m['seconds'],global_cutoff);cutoff=end-15
status=dict(ticket=m['id'],manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),monotonic_start=start,deadline=cutoff,global_remaining_seconds=global_cutoff-start,status='RUNNING',cases=[])
def save():
 temp=out/'STATUS.tmp';temp.write_text(json.dumps(status,indent=2)+'\n');temp.replace(out/'STATUS.json')
def remaining_timeout(maximum=10):
 remaining=cutoff-time.monotonic()
 if remaining<=0:raise TimeoutError("EXECUTION_CUTOFF")
 return min(maximum,remaining)
def source_check(c):
 w=c['cwd'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True,timeout=remaining_timeout()).strip()==c['head']
 diff=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=w,timeout=remaining_timeout());assert hashlib.sha256(diff).hexdigest()==c['diff_sha256']
 assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=w,timeout=remaining_timeout()),'UNTRACKED_SOURCE'
def gpu_memory():
 q=subprocess.run(['nvidia-smi','--query-gpu=memory.used,memory.free','--format=csv,noheader,nounits','-i','0'],capture_output=True,text=True,timeout=remaining_timeout(3),check=True)
 return list(map(int,q.stdout.strip().split(',')))
def cleanup(proc):
 if proc is None:return
 cleanup_end=min(end,time.monotonic()+10)
 for sig in (signal.SIGTERM,signal.SIGKILL):
  try:os.killpg(proc.pid,sig)
  except ProcessLookupError:pass
  try:proc.wait(timeout=max(.01,min(3,cleanup_end-time.monotonic())))
  except subprocess.TimeoutExpired:pass
 # Check own group, including descendants whose leader already exited.
 survivors=[]
 for item in psutil.process_iter(['pid','status']):
  if time.monotonic()>=cleanup_end:raise TimeoutError('CLEANUP_DEADLINE')
  try:
   if os.getpgid(item.pid)==proc.pid and item.status()!=psutil.STATUS_ZOMBIE:survivors.append(item.pid)
  except (ProcessLookupError,psutil.NoSuchProcess):pass
 assert not survivors,('OWNED_GROUP_SURVIVORS',survivors)
save()
try:
 for entry in m['files']:assert hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path']
 status['environment']=verify_environment(root/'ENVIRONMENT.json',timeout=remaining_timeout())
 for case in m['cases']:
  if time.monotonic()+20>=cutoff:status['status']='PARTIAL_BUDGET';break
  source_check(case);row=dict(id=case['id'],status='STARTING',command=case['command'],start=time.monotonic(),peak_rss=0,peak_gpu_mib=0);status['cases'].append(row);save()
  proc=None;failure=None;child_end=min(cutoff,time.monotonic()+case['seconds']);env=os.environ.copy();env.update(case['env']);log=out/(case['id']+'.log')
  try:
   if case.get('gpu'):
    used,free=gpu_memory();assert used<=2048 and free>=1024,('GPU_HEADROOM',used,free)
   if time.monotonic()>=child_end:raise TimeoutError('PRELAUNCH_DEADLINE')
   with log.open('w') as sink:
    if time.monotonic()>=child_end:raise TimeoutError('PRELAUNCH_DEADLINE')
    proc=subprocess.Popen(case['command'],cwd=case['cwd'],env=env,stdout=sink,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=proc.pid;save()
    while True:
     observed=time.monotonic();returncode=proc.poll()
     if returncode is not None:
      row['exit_code']=returncode
      if returncode!=0:raise RuntimeError(('CHILD_EXIT',returncode))
      if observed>=child_end:raise TimeoutError('COMPLETION_OBSERVED_AFTER_DEADLINE')
      if log.stat().st_size>32*1024**2:raise RuntimeError('LOG_LIMIT')
      break
     if observed>=child_end:raise TimeoutError('CHILD_OR_PHASE_DEADLINE')
     try:
      parent=psutil.Process(proc.pid);members=[parent,*parent.children(recursive=True)];rss=sum(x.memory_info().rss for x in members if x.is_running())
     except psutil.NoSuchProcess:
      time.sleep(.05);continue
     row['peak_rss']=max(row['peak_rss'],rss)
     if rss>8*1024**3:raise RuntimeError('RSS_LIMIT')
     if log.stat().st_size>32*1024**2:raise RuntimeError('LOG_LIMIT')
     if case.get('gpu'):
      used,_=gpu_memory();row['peak_gpu_mib']=max(row['peak_gpu_mib'],used)
      if used>3072:raise RuntimeError('WHOLE_DEVICE_LIMIT')
     if time.monotonic()>=child_end:raise TimeoutError('CHILD_OR_PHASE_DEADLINE')
     time.sleep(.25)
    row['exit_code']=proc.returncode
    assert proc.returncode==0,('CHILD_EXIT',proc.returncode)
   if case.get('result'):
    result=json.loads(Path(case['result']).read_text());row['result_status']=result['status'];assert result['status'] in case.get('allowed',['PASS']),result
   row['status']='PASS'
  except BaseException as exc:
   failure=repr(exc);row.update(status='FAIL',failure=failure)
  finally:
   try:cleanup(proc);row['cleanup']='PASS'
   except BaseException as exc:row.update(status='FAIL',cleanup=repr(exc));failure=repr(exc)
   row['end']=time.monotonic();save()
  if failure:status['status']='STOPPED';break
  source_check(case)
 if status['status']=='RUNNING':status['status']='COMPLETE'
except BaseException as exc:status.update(status='STOPPED',failure=repr(exc))
finally:
 status['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 with (root/'LEDGER.jsonl').open('a') as ledger:ledger.write(json.dumps(status)+'\n')
print(status['status'],len(status['cases']));raise SystemExit(0 if status['status']=='COMPLETE' else 1)
