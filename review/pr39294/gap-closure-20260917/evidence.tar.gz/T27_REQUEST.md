# New distinct decision confirmation registry
T26V2 COMPLETE2 clean. M2normalPASS: historicalactualfree[142], pending143, actualwaitE2onconsumerwhileoutstanding; both142/143reused, reader/old/newpayload/accountingpassed. NegativeEXPECTED OUTSTANDING_READER_SOURCE_SELECTED_FOR_REUSE: historicalfree[142,143] withindependentE2pending; protectivewaitbeforereuse, noactualcorruptionclaimed. Bothcases E2alreadycompletedafteralloc, soNOclaimwritesoverlappedE2 orhostsync-free allocation. This observerclosesdecision/dependencycoverage only.

Review T27.json exact10remainingchildren, unchanged approvedv2probe/common/context/guards. CnormalM2rep1,S2rep0/1,T3rep0/1; CnegativeS2/T3; AnormalM2/S2/T3.45s/child600total. CombinedT26V2+T27newregistry12cells =9normal/3negative; distinctnewobserverseparatefromoriginalnever-admittedblocking-observer registryandsame-event12. Defaultcontextunchanged. No retries; PARTIALinmatrixcannotbecountedPASS. BroadexpansionnowconditionedonactualT26V2normal/control success.

Please staticallyreview resultsadmission+exactregistry andwrite concise /tmp/PR39294_T27_REVIEW.md. No experiments. This doesnotyetadoptC2 orauthorizegeneralreadiness.
