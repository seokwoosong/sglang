# T15 / T16 / T17 static executable review

Decision: **APPROVED, conditional, separately for T15, T16 and T17.** No executable correction is required for the submitted rebinding. This authorizes only the finite registries below, after their prerequisite gates. It does not adopt C2 or authorize another candidate, retries, serving, async confirmation, source changes, or remote actions.

## Exact reviewed bindings

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
| --- | --- |
| T15_T17_REQUEST.md | `1721709ed33501376945d51ffa5f9ade0eec74040ad779c738614dc7f942b6e6` |
| T15.json | `8a429d36823d9765cb38035fba53d217ece98ae66bc4745aed089449fc81e35b` |
| T16.json | `79e73400f3f9d1d128ccdfab3d3aeb3e41809b18f96a4c9ab9a6b36e36aa6cc5` |
| T17.json | `01202c0fbd5d2d274ef66938cb5f2c2f4809d4f6864af0f06d9313c95f51dde0` |
| summarize_c2_cost.py | `fa2729f32ca84abe017b718b1842d0cc4ca7f31ca8c3dd536c158fc1cc54625a` |

All files listed in these three manifests matched their declared hashes. The current isolated C2 worktree has HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, binary diff SHA256 `4451ee8cc9ddb025f13a8ea954370c7d20ebac6310c454cd438379ff9433e5e0`, and only the two expected modified source/test files. C remains this exact dirty C2 candidate, not C1.

I checked the T14 COMPLETE record, both PASS/exit-zero/cleanup-PASS rows, and module/environment provenance in the logs: Python 296 passed / 1669 subtests / 10 skipped; cached Rust 26 passed / 139 subtests / 1 deselected. These support the CPU prerequisite only; exclusions remain exclusions.

## Independent approvals and conditions

**T15 — APPROVED:** four diagnostic children, B,C then C,B; 60 seconds per child, 300 seconds total. The case registry matches T11 after only source/hash/harness/output rebinding. CPU workers and configuration are unchanged; common.py changes only the two C candidate-hash references. Check the saved paired configuration, initial state, environment and CPU context before interpreting profiles: diagnostic.py does not itself enforce cross-arm equality. Profiled durations and inclusive call times remain diagnostic, not performance estimates or additive attribution. Do not select a different candidate from these observations under this approval.

**T16 — APPROVED:** one fresh 36-child, 12-block B/A/C2 measurement, 90 seconds per child, 2400 seconds total. The registry and every command match T04V2 after the explicit rebinding. Five scenarios, two warmups and five measured fresh fixtures per scenario yield 360 warmups and 900 measurements. Canonical initial-state comparisons and comparisons with earlier arms in each block are retained. No instrumented T15 samples enter this analysis.

The analyzer differs from summarize_cost_v3.py only in the ticket, registry and output paths. It binds runner commands/results/source/environment and requires COMPLETE, all 36 valid cases, all 12 blocks and no exclusions before emitting confidence intervals and a primary pass. Seed 39294, 10,000 paired-block bootstrap draws, and the original criteria remain fixed: T3-ready C/A upper ratio < 1, C/B upper ratio < 1.10, and C/B upper absolute delta < 5 microseconds. Material control deterioration retains the existing joint median ratio > 1.10 AND median delta > 5 microseconds rule. Inspect the control list explicitly; primary_margin_met alone does not clear that gate.

C1's valid performance miss remains reported independently. No pooling, threshold relaxation, selective omission or unchanged rerun is authorized. An incomplete run is INCONCLUSIVE even if observed samples look favorable. Adaptive candidate development remains unadjusted for selection; these intervals describe these fixtures and environment, not general allocator equivalence or serving performance.

**T17 — CONDITIONALLY APPROVED:** exactly the ten T06v2 cases rebound to A/C2, 60 seconds per child, 900 seconds total. Launch only after T14's accepted correctness prerequisite, T16 complete-valid primary PASS, and no unresolved material control issue. The probe and registry are byte-identical to T06v2; common.py changes only C2 provenance. This covers synchronized tri ready/reclaim in eager/lazy modes and lazy-only gate close/reopen. Closed-gate copy/page deltas must be zero; retained payload, mappings, ownership/accounting and allocation checks remain mandatory. Reclaim requires observed retained SWA and Mamba relocation; missing movement stays PARTIAL. A runner PASS with result_status PARTIAL is not coverage PASS. Unselected branches in the copied probe are not authorized. These cells provide no asynchronous ordering, race, timing or serving claim.

## Sequential and resource gates

Before any launch, T18 and all other work must exit with cleanup PASS and receive a stop disposition if needed. An unresolved invariant, payload, provenance or cleanup failure blocks dependent work. A diagnostic PARTIAL is not an async success. Do not overlap tickets or CPU measurement with GPU work. The generic runner does not enforce predecessor-result admission; the executor must record and enforce these conditions outside it.

Retain exact source/environment/file guards, no-build backend settings, process-group cleanup and failure precedence. Limits remain 8 GiB child-group RSS, 32 MiB child log, and for T17 the existing GPU headroom checks and 3 GiB whole-device guard. The three ticket caps total 3600 seconds, clipped by remaining global time. T16's 36 x 90-second child maxima exceed its 2400-second ticket cap; this intentionally permits truncation, not extension. No guarantee of completion or automatic continuation follows from approval.

Absolute workload cutoff remains **2026-09-16 22:07:44 UTC**, with final cleanup/report cutoff **22:17:44 UTC**. Preserve all raw failures, PARTIAL/NOT_RUN labels and historical limitations. A performance miss or unresolved control finding keeps T17 blocked pending a new concrete disposition.

Review was static: text, JSON, hashes and read-only Git inspection only. No submitted module was imported and no tests, workloads, GPU queries or source edits were performed.
