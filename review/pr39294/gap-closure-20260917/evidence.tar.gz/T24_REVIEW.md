# T24 focused static review

**APPROVED:** exactly the three submitted A/late_cat diagnostic children, once each, sequentially; 60 seconds per child / 240 seconds total. No executable correction is required. Existing v2 resource, provenance, context, cleanup and stop gates remain in force.

Reviewed SHA256:

- T24_REQUEST.md: `f3653095ecaffc1cc4bab958d50ab3fac54cff5634c08ef26344e0e1ed375f70`
- T24.json: `0037213892589bbb1ad46d3e36f221ecdb2a89135424cfd3fa7c5acaad10b324`
- async-scheduling-variants-harness/probe.py: `df95e97d4a1a8e3bc3cdc7ef0a1b53ef59331ed6778e88620d84626f8820555f`

All manifest file hashes matched. Commands select only chunk64, query and chunk64_query on clean A at `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, with distinct output paths and the unchanged v2 runner/context wrapper.

**Prior-result disposition:** T17D COMPLETE has ten functional PASS results, exit zero and cleanup PASS. Raw reclaim results show actual retained SWA/Mamba movement; both lazy gate cases record zero closed-gate copies. Accept this bounded synchronized regression checkpoint, without extending it to async or merge readiness. T22D has four genuine PARTIAL results: E2 pending before submission but completed after sentinel waits of approximately 353–359 ms. T23D has one PARTIAL: 82 markers, seven initially complete, then line 1976 and all later queried markers incomplete while E2 remained pending before/after the scan. These are clean diagnostic outcomes, not allocator failures. T23's time-scanned instrumentation cannot uniquely identify the responsible kernel or driver behavior. All three tickets report COMPLETE and cleanup PASS; they do not block this diagnostic continuation.

The diff retains T22's independent consumer payload, exact reader values, final synchronization and overlap oracle. It changes only second-delay decomposition and/or E1 waiting: 64 × 15,625,000 = 1,000,000,000 requested GPU cycles; first delay remains 2,000,000,000. Query variants yield the host for 100 microseconds between incomplete-event observations and check a five-second deadline. Payload/runtime exceptions remain FAIL; missing overlap remains PARTIAL.

Interpretation conditions:

- Equal requested sleep cycles do not imply equal elapsed delay: 64 launches introduce scheduling opportunities and overhead. Query polling also changes host/runtime interaction. Report those interventions explicitly; no allocation/driver causal proof or statistical timing claim from one case each.
- The five-second query timeout is checked when E1 is still incomplete. A completion observed after host descheduling can exit the loop after five seconds; the outer 60-second child guard remains authoritative. Do not describe the polling loop as an exact wall-clock completion cutoff.
- PASS requires both readers initially pending and E2 still outstanding before late submission and after consumer completion. It remains allocator-free scheduling evidence, not original-helper admission. Future normal/negative helper confirmation requires its own exact review.

Launch through continued_entry_v2.py after checking no other workload is active. Keep the 2560 MiB prelaunch threshold, sampled 3072 MiB whole-device stop threshold, other unchanged resource limits, and owned-process cleanup. No automatic retries, larger delays, source edits or additional variants. Preserve all historical PARTIAL results and C2 performance limitations.

Static inspection only; no imports, experiments, GPU queries or source modifications were performed.
