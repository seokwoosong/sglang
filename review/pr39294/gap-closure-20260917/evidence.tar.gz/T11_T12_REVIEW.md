# T11 / T12 focused static disposition

**T11: APPROVED for the exact bounded B/C CPU diagnostic ticket.**

**T12: CHANGES_REQUESTED before execution.** Add an explicit CUDA-trace validity gate; the submitted worker can otherwise finish with PASS/PARTIAL despite lacking the GPU/runtime evidence this ticket requires. No workload expansion is needed.

This review used static request/source/diff/hash inspection and existing result JSON. No submitted modules were imported, workloads executed, GPU queried, packages installed, or source files changed.

## Reviewed identities

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T11_T12_REQUEST.md | `72ed60201f39dbac37597a70ef2d8806325256be78ad80e7b41c092c594b090f` |
| T11.json | `2c0dc3b17e9cd6f362c353e4369abb175c4ba47ff09f2c52daff60743e195e88` |
| T12.json | `209b518a4bcdc04d4325ea359f2ed8b96eb05fe048f5555de351bf2688f39581` |
| async-profile-harness/probe.py | `a79a25c977da8606463d513a03a3b3a71d1c98c9874fbe29074f2ed01f1165d6` |
| t12_entry.py | `3d55de8c3ba01e2b7ab00611a1b605b87dae681cae5d1d34842400866f1810a1` |
| COST_ANALYSIS_V3.json | `de2f6cd0bf208b2c449e6e58543abd66d17181a498fa009658eda72dbb6e8bbb` |

All listed T11/T12 manifest file hashes matched. T11 uses the unchanged approved diagnostic worker `5d36793a456c8ce5ff90da5e541450f14bc3329dd13be6a13026b674e08a8ef6`. Both use the unchanged finite runner `14d60a8f9e30a09891cf2d0b08e1e8346ecc4f8879c28c9bee901267a474efe1`.

## Existing-result disposition

T04V2 STATUS is COMPLETE, bound to the approved manifest, with 36 PASS/result-PASS/cleanup-PASS rows and no ticket failure. The saved v3 analysis reports twelve valid blocks, no exclusions and `primary_margin_met=false`. T3-ready C/A improves (median ratio 0.881409; ratio CI upper 0.943073), but the C/B absolute-delta CI upper is **6.1715 microseconds**, exceeding the predeclared 5-microsecond criterion. The relative C/B upper bound, 1.089402, passes its separate 1.10 limit; that does not override the absolute criterion.

Treat this as a performance-acceptance miss, not a newly demonstrated allocator correctness failure. Do not retune thresholds or repeat the unchanged cost experiment to seek a pass. No control crosses the prescribed joint material-deterioration rule. Preserve the T3-pressure observation as well: median C/A ratio 1.016811 and +9.3775 microseconds, even though it does not trigger that rule. C1 remains unadopted and T06 remains held. This is a focused disposition of the supplied runner/analysis evidence, not a new independent recomputation of all cost statistics.

T07 STATUS is COMPLETE with three PARTIAL worker results and cleanup PASS. All three have both events outstanding after commit, E2 outstanding before and immediately after nonurgent drain, and E2 complete after the snapshot. Recorded drain durations are about 0.207–0.264 ms; snapshots about 356.9–357.4 ms. This supports tracing the consumer queue/snapshot interval but does not prove which operation or dependency caused serialization. Pinned-A did not satisfy admission: T08/T09 and their T10 continuations remain blocked. A profiled T12 PASS would not substitute for that missing unprofiled admission prerequisite.

## T11 execution approval

Authorize one exact B,C / C,B sequence: four CPU children, 60 seconds each, 300 seconds total, three ready scenarios with two warmups and three profiled samples each (24 warmups, 36 diagnostic observations). B correctly binds clean HEAD `a3bf25dc620f31fc672aeced1465d6fe7c81d28f`; C binds A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123` plus reviewed diff `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3`. Commands, workdirs and PYTHONPATH agree. The manifest's old cost.py is a hash-only dependency; no cost command is authorized.

Compare the two arms' saved JSON initial state/configuration, environment and CPU context within each pair before attributing call-count differences. Both sides are decoded JSON, avoiding the former live-tuple/list comparison error. Profile self/inclusive durations are mechanistic diagnostics, not a new performance estimate, and inclusive times are not additive. No new candidate or patch is approved.

T11 is technically independent of the unavailable async admission. It may proceed sequentially after existing cleanup while T12's correction awaits review; if retaining the requested T12-then-T11 order, wait for revised T12 approval first. An actual new functional/provenance/resource failure still requires disposition before dependent work.

## T12 required correction and accepted design boundaries

The single-fixture capture interval and labels are reasonable: profiling begins before the observed producer launch, after existing warmups; the original helper calls receive two identifying `record_function` labels; successful paths reach final payload synchronization before stop/export. Fixed sleeps, pinned observation and reader/reuse semantics are unchanged. The proposed 120-second child / 180-second ticket, RSS/log/device guards and post-export 32 MiB trace acceptance limit are bounded. The size check is post-export, not a hard disk-write cap; this distinction should remain explicit.

**Required:** distinguish a usable CUDA trace from a successful fixture. The worker currently only calls `profiler.start/stop/export_chrome_trace` and checks file size (lines 134–137); its PASS/PARTIAL remains the fixture's overlap result. Requesting CPU+CUDA activities does not guarantee CUDA tracing. The installed PyTorch source at `torch/autograd/profiler.py:315–319` explicitly selects `KINETO_GPU_FALLBACK` when CUDA activity is unsupported while CPU profiling is enabled. The request says unsupported CUDA profiling must be a failure/blocker, but the submitted executable does not enforce that requirement.

Add a bounded validity check that rejects unsupported CUDA tracing and/or an exported CPU-only trace. Require actual device kernel activity and the runtime/stream/correlation evidence needed to inspect the consumer copy/dependency, rather than accepting CPU operator names as GPU evidence. Record validation counts/reason and the trace identity in the result. Missing required activity must produce a distinct trace failure/unavailable disposition that the runner does not accept as ordinary diagnostic PASS/PARTIAL. Inspect the exported trace only after its size check, within the existing process/RSS deadline. Do not install profiling support or alter the environment to recover coverage. Preserve any earlier fixture failure when recording trace/export failures.

Label the result as CPU/CUDA-profiler-instrumented diagnosis: removal of Python line tracing does not make this an uninstrumented confirmation or a performance measurement. Re-submit only the corrected probe/manifest binding for focused review. No additional child, delay or budget is warranted.

## Unchanged limits

All execution remains sequential after completed/disposed predecessors and owned-process cleanup, under unchanged source/environment checks, 8 GiB RSS, 32 MiB per-child log and GPU 3 GiB whole-device/headroom guard where applicable. Preserve failures and partials; no automatic retries, budget transfers, serving, adoption, push or merge.

Absolute execution cutoff: **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST). Final cleanup/reporting: **22:17:44 UTC** (07:17:44 KST). No deadline reset.
