# T18 explicit-consumer diagnosis — static review

**APPROVED — conditional execution of the exact two A/M2 normal diagnostic children, once.** No mandatory correction is identified. This does not authorize C1/C2 confirmation, negative-control execution, or release any old admission ticket.

Review used static request/manifest/source-diff/hash inspection and existing T13 JSON results. No submitted modules were imported, workloads run, GPU queried or source files changed.

## Identity

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T18_REQUEST.md | `c015cf26f42dcc8f1701ac8b91b34f4ea7c833bcbf7df7f18999cb78d1657c52` |
| T18.json | `8c27976a01bcbc7c1857025554f88cf0358414a021ae533fd0254bad5ec86f4a` |
| t18_entry.py | `5834edd457237a6c27e1ad24dec3ce481a180cf2e8fb66fce250bbd35245020e` |
| async-explicit-distinct-harness/probe.py | `1a506615b90583908139cf688e5cbd524d37b4788da3419ee109173fa740da80` |
| async-explicit-same-harness/probe.py | `e2c2013ae7678a886a72d47c6f9ef2e170d96e827628524b9a8ae392bdca6ac9` |

All manifest file hashes matched. Both commands bind clean A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, the A workdir/PYTHONPATH, pinned variant, M2, repeat 0 and separate result paths. Neither command supplies `--negative`. Shared runner/common/environment/context hashes remain unchanged.

## Evidence and rationale

T13's runner is COMPLETE with all four cleanup results PASS. Default and default-query workers are PARTIAL: the sentinel remains pending after E1, its wait takes about 356.95/357.03 ms, and E2 has completed afterward. Explicit and explicit-query workers are PASS: the sentinel is already complete after E1 while E2 remains outstanding; sentinel waits are 4.198/4.358 microseconds and E2 remains outstanding afterward.

This supports testing explicit-consumer behavior with the original helper fixture. It demonstrates stream-choice sensitivity in the allocator-free scheduling diagnostic, not a specific driver/WSL cause, a production synchronization defect, or a performance estimate. It supplies no missing CUPTI evidence.

## Stream ordering and oracle assessment

Relative to the previously reviewed distinct/same probes, changes are confined to creating an explicit consumer stream, synchronizing completed setup before entering it, keeping its context active through warmups and the observed path, and restoring the previous context in finally.

The additional device-wide synchronization precedes helper warmups and the target interval. It finishes tensors/mappings created on the setup stream before their first use on the new consumer. Nested producer contexts restore that consumer; helper moves/remaps, pending drains, new allocation/write operations and pinned D2H copies therefore use the same consumer. The D2H completion event is recorded on that stream after its copy, and the urgent E2 dependency is checked against its actual stream identity. Objects remain live through successful-path synchronization. Finally restores context before fixture reset; exceptional execution remains a failed child under the outer process-group cleanup guard.

The original helper/copy/remap/drain functions, disclosed prebuilt-index substitution, warmups and fixed 2-billion/1-billion-cycle producer delays are retained. No Python line tracer or CUDA profiler is introduced. The pre-existing final synchronization/readbacks remain outside the critical overlap observation; no new device-wide synchronization is inserted into that observation interval.

Distinct normal PASS still requires both events outstanding after commits, E2 outstanding through the nonurgent snapshot, protected pending/free membership, an urgent dependency, actual source-two reuse and intact reader/retained/new payload plus accounting. Same normal retains shared-E2 protection, both-source reclamation and actual reuse, payload and accounting checks. Missing overlap/reuse remains PARTIAL; unexpected invariant failures remain FAIL. Normal execution does not perform the same-event negative repair. Negative branches remain outside this ticket's authorization.

## Execution conditions and limits

Authorize exactly `distinct-A-normal`, then `same-A-normal`: **90 seconds per child, 240 seconds total**, once, through hashed `t18_entry.py`. Preserve parent flags, child backend/device/stream context, source/environment checks, 8 GiB RSS, 32 MiB per-child log, 3 GiB whole-device/headroom guard and bounded owned-process-group cleanup.

Wait for T14 and any preceding workload to complete or receive disposition and pass cleanup; no overlap. T14 correctness is not presumed passed by this review. A new functional/provenance/resource failure requires disposition before dependent work. A diagnostic PARTIAL is preserved as missing coverage, not permission to retry or increase delays.

Judge distinct and same results separately. A pattern's A normal PASS can support a later exact candidate/control proposal; it does not establish candidate sensitivity or universal async safety. Any prospective C2 normal/negative registry requires a separate source binding and concrete executable review after the relevant results/correctness gates. Old T08/T09/T10 remain NOT_RUN and unreleased; do not substitute T18 for their exact historical prerequisites. T06/C1 adoption holds also remain unchanged.

Absolute execution cutoff: **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST). Final cleanup/reporting: **22:17:44 UTC** (07:17:44 KST). No deadline reset, budget transfer, additional layouts/owners, source adoption, serving, push or merge is authorized.
