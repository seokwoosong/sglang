# T23 focused static executable review

Decision: **APPROVED, conditional diagnostic execution only.** One A/M2 distinct-event normal child, 90-second child limit and 180-second ticket cap, exactly as submitted. No executable correction is required for this bounded instrumented observation. No C2 admission, negative control, confirmation registry, source modification or repeat is authorized.

## Exact bindings

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
| --- | --- |
| T23_REQUEST.md | `7744f28eadfeac70c5d2ee407af70498cec5950c8d752c436b0d95c7035b3f1a` |
| T23.json | `aaef8ca5f457659f5417ba955e943ef501423436d31fbd24fbe4f1fb929940da` |
| t23_entry.py | `4c7fc1b96672464a5328ee65f39aacde2a906867b6b9c3683ba043770da5c3ec` |
| async-prefix-events-harness/probe.py | `c33fe4348b746cce69557408698bc66b224fe3aec1b1f0c760baed0bfb342d91` |

All manifest file hashes matched. The only selected command binds clean A at `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, M2, repeat 0, pinned observation and no negative flag. Common provenance, runner, environment, CUDA-context checks and fixed producer sleeps are unchanged.

## Static findings

The diff against the T18 explicit-consumer distinct probe adds only the marker setup/trace and post-E1 queries. The actual `_commit_move_batch` and concrete Python `move_kv_cache` code objects are watched; their implementations are not cloned or substituted. The existing narrow prebuilt-index tensor interception remains in place, so this continues to be controlled original-helper coverage rather than an untouched natural flush path.

All 128 CUDA events are created, recorded and globally completed before the observed producer interval. Each subsequently used event is recorded once more on the explicit consumer and kept alive. Hooks append CPU labels and record the next event; they do not read GPU tensor values or explicitly synchronize the GPU. The capacity guard fails instead of growing the marker array. The watched functions have finite straight-line paths for the two one-page batches. An unexpected capacity failure must remain FAIL, not trigger an enlarged rerun.

Trace installation is followed immediately by try/finally removal; the outer finally also clears tracing and restores the consumer context. The original payload, actual physical reuse, pending-ledger and accounting checks remain unchanged. A failure during instrumentation still goes through bounded child/process-group cleanup; no diagnostic success should be inferred from an incomplete artifact.

E1 is host-completed before marker queries; E2 is queried immediately before the scan and again after it. This can distinguish consumer commands already pending before nonurgent drain from later drain/snapshot effects in this instrumented run. Original urgent-drain dependency checks still precede new writes. This is a reasonable separate diagnostic after T22 regardless of which late-operation pattern T22 observes, provided no unexpected failure remains unresolved.

## Required interpretation

1. Treat marker queries as an ordered **scan over time**, not an atomic completion-prefix snapshot. The GPU progresses while queries execute. An earlier false followed by a later true can be ordinary progress; do not classify that pattern as a stream-order violation or infer one exact pending boundary from it. A false says that marker was incomplete at its own query. A true later marker certifies its earlier stream predecessors by that later observation.
2. Interpret overlap only when E2 is still outstanding both before and after the scan. Otherwise preserve the recorded observations but label the overlap localization inconclusive. Marker completion orders consumer work; it does not attribute a specific CUDA kernel or host blocking operation to a Python line. Python line events occur before executing the line and may bracket multiple device operations.
3. `sys.settrace` and event records perturb host submission, scheduling and potentially whether the helper sees an event as already completed. The callback is installed globally on the current thread and returns itself for other frames, although only the watched code objects emit markers. Do not describe its timing as nonintrusive, compare durations as performance, or infer that the uninstrumented helper has the same completion pattern.
4. The inherited raw `scope` string still says `untraced original move helper`; that description is stale for T23. Reports must explicitly identify T23 as traced/instrumented and use `diagnostic_instrumentation` and the exact probe hash to disambiguate it. Preserve the frozen artifact; this approval does not require a source edit merely to relabel that string.
5. Final PASS/PARTIAL retains the inherited functional/overlap meaning. Neither is automatic distinct-event admission. Diagnostic marker evidence may be informative even if the later pinned snapshot loses overlap, but cannot upgrade missing functional/ordering coverage. No CUPTI, driver/WSL root-cause, production-flush reachability or universal async-safety claim follows.

## Launch and stop gates

No launch while T16 cost runs. Require T16 completion/stop disposition and cleanup, then T22 completion/disposition with cleanup PASS. A normal diagnostic PARTIAL in T22 may permit this one case; an unexpected payload, invariant, CUDA, provenance or cleanup failure holds T23 pending explicit disposition. No overlap with any other CPU measurement or GPU ticket.

The wrapper checks parent CUDA context, not predecessor admission. The executor must record and enforce these gates. Retain source/environment/hash checks, native allocator/context, fixed sleeps, 8 GiB RSS, 32 MiB child log, existing GPU headroom and 3 GiB whole-device limit, failure precedence and bounded process-group cleanup. Ticket/global clipping and cleanup reservation remain authoritative; no budget reset, larger sleeps, automatic retry or extra marker variant.

Workload cutoff remains **2026-09-16 22:07:44 UTC**; final cleanup/report cutoff **22:17:44 UTC**. Existing same-event evidence and distinct PARTIAL results remain separate and unchanged.

Review was static text, source and hash inspection only. No submitted imports, workloads, tests, GPU queries or source edits were performed.
