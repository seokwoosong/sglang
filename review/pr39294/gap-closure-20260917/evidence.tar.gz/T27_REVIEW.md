# T27 admission/results and registry review

**APPROVED:** T26V2 satisfies the narrowly scoped admission gate. Authorize exactly T27's ten remaining children, sequentially, 45 seconds per child / 600 seconds total. No correction is required.

Exact SHA256:

- T27_REQUEST.md: `1a419f45230080b7c78ec21c2a539db47e8d4690fa594e469c0af84365c236bc`
- T27.json: `0497e7f0eb920534935da7f56c5bb258cfb180077a08092f45a14c71d0ab558b`
- Unchanged v2 probe: `00d790105424c3874bf05b3e86ea571a605aff8e80d4ae0c78811a26b3175379`

All manifest file hashes matched. Case commands, output paths, GPU flags, environments and A/C2 source bindings match the declared registry. Normal arms allow only PASS/PARTIAL; negative arms only EXPECTED_FAULT_DETECTED/PARTIAL.

**Admission evidence:** T26V2 STATUS is COMPLETE, with both exit-zero and cleanup-PASS records. Commands, raw result statuses, frozen C2 provenance and environment bind to the approved manifest. Normal records historical free-list [142], pending [143], E2 outstanding through drain/snapshot submission, and original wait_event(E2) on the recorded consumer while E2 was outstanding. Both physical sources were actually reused and final checks passed. Negative records historical free-list [142,143] while independently observed E2 remained outstanding and the exact `OUTSTANDING_READER_SOURCE_SELECTED_FOR_REUSE` signature. Its explicit protective wait is part of the approved negative path; its empty `waits` list must not be represented as an observed original urgent wait.

Both cases report E2 pending before allocation but complete after allocation and before stamping returns. Accept historical selection, the normal pending urgent dependency, negative sensitivity and subsequent payload-preserving reuse only. No overlapping-write or host-synchronization-free-allocation claim follows.

Evidence hashes:

- T26V2 STATUS: `8bbaf506e3a9ed79f9faa6cc9c176f4a51d58d5da7fffe478310a83b379ed321`
- Normal result: `190a28d8ecf6eb5987885a4a12e9f4ce1c1d4d0ab936b94233ff316e72a7b86f`
- Negative result: `642e7049417b41f02dd59adc94d0dc159a18bc5805525862b60ecee121e37d34`

**Exact expansion:** C2 normal M2 repeat 1, S2 repeats 0/1, T3 repeats 0/1; C2 negative S2/T3 repeat 0; A normal M2/S2/T3 repeat 0. These eight normal plus two negative cells, together with T26V2, form a new twelve-cell decision-observer registry: nine normal and three negative. They do not replace old blocking-observer PARTIALs or duplicate the separate same-event matrix. FULL-owner/page1/lazy helper scope persists even in S2/T3 layouts; this is not validation of SWA/Mamba-owner pending movement.

Use the bound context wrapper, unchanged frozen context/probes/source, fresh output paths and no concurrent workload. Keep all v2 resource/deadline/provenance/cleanup guards. Ten child maxima total 450 seconds within the explicitly submitted 600-second ticket; startup/cleanup remain charged. No automatic retry or extra cells. Unexpected failures stop dependent work; PARTIAL/NOT_RUN must remain separate from coverage PASS. Aggregate acceptance requires actual per-case results and cleanup, not merely a COMPLETE runner label.

This approval does not adopt C2 or certify general readiness, natural production-flush reachability, snapshot completion before E2, graphs/distributed behavior or universal async safety. Static text/JSON/hash inspection only; no imports, workloads, GPU queries or source edits were performed.
