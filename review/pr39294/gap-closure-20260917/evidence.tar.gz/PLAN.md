# PR39294: close the ready-path cost and asynchronous validation gaps

## Scope and baseline

User requested a plan to carry the remaining experiments through to a useful answer. This is a NEW plan; previous experiment budgets and executable approvals are exhausted and are not reused. This turn prepares and reviews the plan only. A subsequent execution must obtain exact candidate/harness review before dependent runs. No push, PR replacement, merge, package changes, model downloads, or changes to the user's original worktree.

Reference evidence: `/home/sukwoo24/sglang-eval-results/pr39294-followup-20260916/{OUTCOME.md,CPU_SUMMARY.json,DIAGNOSTIC_SUMMARY.json,ASYNC_STATUS.json,FINAL_VERIFICATION.json}`.

- B: landed #36729 upstream `a3bf25dc620f31fc672aeced1465d6fe7c81d28f`.
- A: current follow-up implementation `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`.
- Canonical review branch HEAD `e8f51a123bb69bf03b4076eede5557536d686e3d` has the same production changes, with documentation afterwards. Verify production-tree identity rather than assuming whole-tree equality.
- C: new isolated candidate worktree from A; freeze its commit/tree/diff/import identity before testing. Never modify B/A or the canonical review branch during exploration.
- Same pinned Python environment, kernel 0.4.7, torch 2.13.0, FlashInfer 0.6.14. Verify the previous environment digest, CPU affinity/thread settings and GPU state. No opportunistic upgrade/rebase.
- Current facts: T3-ready paired median +20.7%, +14.773us in 10 B/A pairs; 9/10 increases. Async 12 normal +3 controls PARTIAL, events already complete, 0 fully covered pairs and 0 intended-control detections. These are immutable historical results.

## Questions to answer

1. Can C avoid reclaim-planning work for already-feasible T3 requests while preserving all relevant allocation/reclaim invariants?
2. Does C remove the measured ready-path overhead relative to B and improve over A under a fresh balanced experiment?
3. Exactly where does the asynchronous fixture lose its overlap, and can an independently checked test exercise pending-reader protection, legitimate urgent stream waits, and actual source-page reuse?
4. Does a deliberately incorrect event association produce the intended independent oracle violation? A normal test alone is insufficient.

## Execution order and finite budget

Sequential phases, no workload overlap. Preparation/static review is separate from measured runtime. Every phase has a shared monotonic deadline; initialization, imports, preflight, warmup, client/worker execution and cleanup consume that phase budget. Unused allowance is not transferable. Reserve the final 15s for cleanup; no new child if its minimum startup allowance would exhaust the reserve. Exact executable submission must include registry, command, source/file/guard hashes and child deadlines.

| Phase | Ceiling | Max processes / scope |
|---|---:|---|
| 1. Candidate correctness | 1,200s | Up to 2 candidate revisions; each at most one focused Python suite and one supported Rust suite (4 suite processes total) |
| 2. Candidate call-path diagnosis | 300s | A/C, 2 pairs, 4 children, 60s each; 3 ready scenarios, 2 warmups +3 profiled operations each |
| 3. Fresh cost comparison | 2,400s | B/A/C, 12 independent blocks, 36 children, max90s each, clipped by shared deadline |
| 4. Async diagnosis | 900s | 3 predefined variants × B/A =6 children, max90s each; no calibration by repeated delay increases |
| 5. Reviewed async confirmation | 900s | At most24 children, max45s each, clipped by shared deadline; see exact registry below |
| 6. Candidate CUDA regressions | 900s | One reviewed registry, at most12 children, max60s each |
| 7. Focused code checks/report verification | 600s | Changed-file checks and aggregation; no additional workload cases |

Total experiment/check ceiling: 7,200s (120min), excluding human/static review and artifact preparation. Child maxima can exceed a phase ceiling; shared deadlines take precedence. No reset or unrecorded retry. Up to TWO reviewed CPU candidate revisions and ONE async harness correction derived from diagnosis. If these fail to establish the goals, preserve the failing case and report a precise unresolved blocker and proposed next amendment; do not claim universal safety or silently expand the experiment.

Unexpected FAIL stops dependent work. Diagnose and submit a concrete disposition/fix to designated reviewer before continuation. Evidence/report-writing can continue independently. PARTIAL is not a functional PASS and must not satisfy the concurrency acceptance gate.

## 1. Implement a narrow T3 ready fast path, then correctness gates

Inspect current `UnifiedMambaSWATokenToKVPoolAllocator.evict_to_free_tokens`, `available_size`, ID-capacity checks, deferred groups and gate-dependent capacity caches before changing code.

Candidate hypothesis: after the existing deferred-FULL-free boundary and page rounding, a PURE immediate-capacity check plus explicit token-ID feasibility can return for a currently feasible request BEFORE querying three reclaim counts and computing the optimistic byte bound. Do not move mutating `ensure_capacity` ahead of impossible-demand protection, remove deferred-free handling, or credit pending pages / merely recoverable bytes as immediate capacity. Preserve #36729 allocator dispatch/planner ownership. No new scheduler planner or per-victim compaction.

Write tests for externally meaningful outcomes, not exact helper-call sequences alone:
- Ready demand succeeds without eviction or unnecessary movement, with live KV/state preserved.
- Insufficient FULL logical IDs, SWA ID/physical limits and unequal page grids do not falsely pass even with spare bytes.
- Impossible byte/ID demand preserves eligible cached entries; locked entries stay intact.
- Deferred ordinary, page-representative and FULL-only frees are drained at the correct boundary without breaking free-group scope.
- Actual internal SWA/state reclaim and cascading reclaim stop at the first sufficient retained prefix set.
- Existing tri-pool END/FLOAT recovery, temporal-state-first fixture (95/96 cached-token retention), state-quota accounting and exact extend demand remain correct.
- Dynamic gate close/reopen and gate changes during preparation remain respected; availability memos stay coherent.
- Session forwarding and explicit quota-driven eviction retain their contracts.

Read contribution workflow, write-sglang-test, repository instructions and test/README.md before editing tests. Select existing suites from `test_unified_joint_allocation_eviction`, `test_unified_tri_joint_reclaim`, `test_unified_dynamic_gate_capacity`, `test_unified_float_move_gate`, `test_unified_pending_event_batches` and relevant allocator/accounting tests. Exact test selection must be frozen in the executable review. Run supported Python/Rust paths with actual extension provenance; known unsupported session cases are explicitly NOT_RUN, never silently called Rust parity. No Rust rebuild/environment mutation without a separate concrete amendment.

Only a correctness-passing, statically reviewed C enters cost measurements. If candidate1 is invalid, preserve it and its failure; candidate2 must address the identified cause and receive review. Do not select a candidate by timing noise.

## 2–3. Diagnose C and measure fresh B/A/C costs

Diagnostic runs keep the original helper+allocation semantics and cProfile call graph. Confirm whether the immediate-ready branch skips reclaim-size/byte-bound work, retaining necessary ID/availability/deferred checks. Diagnostic timings do not enter speed tables; nested inclusive times are not added as a causal decomposition.

Use the existing cost fixture geometry and registry unchanged: M2-ready, S2-ready, T3-ready demand1; S2-pressure, T3-pressure demand4; page1/lazy/CPU/Python. Fresh fixture per operation; time only original `evict_from_tree_cache` + `alloc`. Each scenario:2 warmups+5 measured operations per process. At full completion:36 children,900 measured operations,360 warmups.

Fixed block orders: BAC, BCA, ABC, ACB, CBA, CAB, repeated once in that order. No adaptive rerun. Each block is an independent fresh-process triple; within-process samples are not independent replicas. CPU affinity, torch thread/interop settings and relevant env identical across arms and recorded. Initial geometry/owner/accounting state must match. Preserve B expected behavior only where declared before execution; these five cost scenarios require all arms to succeed.

Primary report: per-block C/A and C/B median ratios and absolute deltas, pooled medians/p95 only descriptive. Full12 blocks permit supplementary block-bootstrap10,000 draws (seed39294), percentile95% intervals for median log-ratio and absolute delta. Incomplete blocks excluded from paired estimates but preserved.

Predeclared bounded ready-path target: C improves over A (C/A ratio interval upper bound <1) AND C/B upper bounds are <1.10 for ratio and <+5us for absolute delta. This is a chosen practical margin for this fixture, not a universal no-overhead/merge criterion. If point estimates meet margins but uncertainty does not, mark INCONCLUSIVE rather than increasing repetitions after viewing data. Check and report all five scenarios; any newly introduced functional failure blocks adoption. Pressure-path timing deterioration beyond both 10% and5us triggers investigation even if ready passes.

Qwen FULL+GDN does not exercise the modified T3 path; repeating its serving benchmark cannot validate this optimization. Do not spend this plan's budget on an unrelated throughput control. Full tri-pool serving remains an explicit separate requirement if a checkpoint becomes available.

## 4. Find why async overlap disappears

Freeze source, exact env including CUDA_LAUNCH_BLOCKING/default-stream/allocator settings, selected pool buffers, stream IDs, event ownership and page-unit conversions. Keep original move/drain functions; instrument wrappers call originals exactly once and preserve returned values.

Predeclared variants, M2/FULL/page1/lazy, each B and A once:
1. Original production index creation and move-helper path, instrumented at operation boundaries.
2. Previous prebuilt-index helper fixture unchanged except observational instrumentation.
3. A separate warmed/preallocated diagnostic variant, whose exact allocations/warmup steps are statically specified before execution; no replacement of production copy/remap/pending bookkeeping. This distinguishes first-use effects from steady behavior, not a production reachability claim.

Capture host timestamps and nonblocking event queries around indexing, async assert, copy, mapping updates, event query and pending registration. Use a bounded CPU/CUDA profiler if supported in the frozen environment; no tracing-tool install. Use stream-local timing events where useful. No `.item()`, `.tolist()`, CUDA synchronize, or allocating diagnostic payload in the target observation interval. Required snapshots occur after ordering observations and are labeled as potentially synchronizing. Preserve the original reader and payload checks.

Use the prior fixed finite sleep cycles (2e9 then1e9), not larger delays. Confirm E1/E2 are outstanding before the target operation, and log the first observed transition. Device completion between observations alone does not prove which operation synchronized; distinguish measured host blocking, profiler evidence and scheduling inference. Check whether fixture queries themselves end overlap.

At completion, produce a specific causal diagnosis or a bounded location with remaining uncertainty. Do not repeat the previous15-case matrix if prerequisites remain absent.

## 5. Build and verify a sensitive async test

Based on phase4, submit ONE concrete fixture correction, exact code/hashes, reachability statement and cleanup protocol for designated-session review. Prefer documented warmup/allocation removal or observation placement that retains the actual helper semantics. No indefinite GPU spin, host-release event deadlock, hidden synchronization removal from production, or larger sleeps. If a custom bounded synchronization primitive is necessary, it requires a separately reviewed amendment and is not authorized by this plan.

Confirmation registry: M2/S2/T3 × NORMAL C (2 repetitions each), INTENDED NEGATIVE C (1 each), with distinct-event and same-event variants =18 children; plus A normal distinct-event once per layout =3 children, and A normal same-event once per layout =3 children;24 total. Use a separate stable source pin for a test-only harness correction; C must contain only the reviewed production delta from A. B is omitted here because its known same-event bookkeeping defect is not this protection oracle's intended failure. Historical B results remain separate.

Before full registry, run the first M2 distinct-event C normal and its paired negative control ONCE as admission (they count toward24). Require the timing prerequisites and intended detector signature in the negative. If either is PARTIAL, stop the remaining confirmation registry as NOT_RUN; do not multiply inconclusive tests. Record the predeclared remaining order in the executable manifest.

Distinct-event oracle:
- Both events outstanding after move registration; E1 completion observed while E2 remains outstanding.
- After nonurgent drain, source1 reusable and not pending; source2 absent from free-list and still pending.
- Urgent drain either observes actual E2 completion or records a wait on the consuming stream before reuse/writes; host noncompletion alone is not failure.
- Allocate into the ACTUAL source2 physical page, then verify old reader payload, all retained virtual-owner/generation mappings, new-owner payload and byte accounting. Failure to reuse source2 is PARTIAL.
- Negative: associate batch2 with E1 instead of E2; detect source2 in the actual free-list while its independently scheduled reader E2 is outstanding. This is the only accepted intended signature. Wait E2 explicitly before any new writes, avoiding exploitation of the unsafe state.

Same-event oracle:
- At least2 move batches registered under ONE outstanding reader event; all source pages tracked until legitimate drain.
- Event completion/urgent wait allows all tracked pages to become reusable with no lost source or pending leak; observe actual reuse of both batches and payload preservation.
- The intended control must selectively drop/overwrite one batch's pending bookkeeping using a fixture-local intervention and detect missing protection/reclamation via independently enumerated moved physical sources, not merely assert injected metadata differs. The exact signature, intervention point, safe final cleanup and whether the fault causes a leak rather than premature reuse MUST be resolved before executable approval. Until then this is a design requirement, not executable authorization.

Report per-layout/per-event-pattern normal coverage AND control sensitivity. FULL-owner helper coverage does not establish Mamba/FLOAT-owner, concurrent writer, graphs, PD/DCP or distributed behavior. Native production-path reachability and prebuilt-index sensitivity remain distinct columns.

## 6. Recheck candidate on CUDA and decide adoption

Only if C changes production code and passes correctness/cost gates, replay relevant existing CUDA allocation/retention regressions against A/C. Freeze at most6 cases ×2 arms: T3 eager/lazy ready, T3 eager/lazy reclaim preserving live prefix and state, and T3 gated/reopened FLOAT movement. Exact fixture geometry/checks specified before execution; no model substitution. Nontrivial owner/generation payloads, physical relocation where required, logical mappings and byte accounting are mandatory. No vacuous movement PASS.

Do not adopt C if it breaks correctness, shifts unacceptable cost to pressure paths, or its benefit is inconclusive under the stated criterion. Keep it isolated with a precise result. Async PARTIAL is an open validation gap and cannot become PASS because CPU/serving succeeded. If async identifies a production defect, stop: new fix and targeted tests require a separate reviewed amendment rather than bundling it silently into C.

## Resources, review and deliverables

- CPU: aggregate RSS8GiB, log32MiB/child, outer process-group timeout/cleanup. CUDA tiny fixtures: sampled absolute whole-device3GiB, start used<=2GiB/free>=1GiB, RSS8GiB, log32MiB. Telemetry failure stops launch; do not kill unrelated processes. Profiler buffers count toward limits. Existing reviewed guard hashes must be rechecked; exact harness must prove parent cleanup is finite as well as child termination.
- Reviewer: Codex session `01a09f85-77de-79d1-a50d-cb7a530616c1`, static plan review first, then concrete source/harness review before each new executable revision. No concurrent writers to that session. Its approval is local technical review, not GitHub maintainer/merge approval.
- Artifacts: immutable old evidence; new PLAN/REVIEW; B/A/C source/env manifests; rejected candidate diffs; full regression results; raw independent cost blocks; operation/event trace; normal/negative matrix; final source/cleanup audit; digest manifest.
- Final answer must distinguish: cost reproduced vs removed, cause observed vs inferred, async timing reached vs absent, oracle sensitive vs unestablished, candidate ready vs rejected/open. "All scheduled runs ended" is not "both problems resolved."
- Current phase only writes and reviews this plan. No experiments or source modifications have been performed under it yet.
