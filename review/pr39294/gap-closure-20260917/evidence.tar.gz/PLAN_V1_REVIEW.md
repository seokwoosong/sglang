# PR39294 gap-closure plan review

**Decision: APPROVED — PLAN ONLY, subject to the required refinements below.**

Reviewed `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916/PLAN.md`, SHA256 `cd4add61a1f4a178e6239a27abe3685bff261839ed184983b5c0ee7352b1b01c`. Referenced the prior follow-up outcome, diagnostic summary, async status and final verification, and inspected the relevant pinned A allocator methods. No workloads, submitted-module imports, GPU queries, production edits, package installation or remote actions were performed. Only this review artifact was written.

This approves the proposed direction and finite planning envelope. **It authorizes no implementation or experiment in this turn.** A concrete candidate diff and each new executable/fixture/guard/registry require the promised later review. In particular, neither the same-event control nor a new synchronization primitive is execution-approved. Prior experiment budgets are not reopened. The accepted source checkpoint remains unchanged, and local adoption requires a later result/source disposition.

## Feasibility and scope

The two remaining questions are justified by the recorded evidence: ten fresh B/A cost pairs show the T3-ready increase, while all fifteen async children were PARTIAL with no sensitive control detection. Completed scheduling is not coverage closure. The prior Qwen results cannot validate the T3 optimization or pending-event protection.

The fast-path hypothesis is feasible and appropriately narrow. At pinned A, `evict_to_free_tokens()` drains deferred FULL frees and rounds demand, then queries three reclaim sizes and an optimistic byte bound before `ensure_capacity()`. The latter already has an immediate-success branch guarded by token-ID feasibility and joint `available_size()`. Moving an equivalent **pure sufficient** ready check ahead of reclaim planning can avoid work without changing the fallback policy. The diagnostic call counts support this hypothesis; they do not yet quantify which individual call causes the uninstrumented increase.

The frozen A/B worktrees, isolated C, no dependency changes, correctness-first selection and unchanged five cost fixtures are suitable. No full serving rerun or model download is necessary to answer this narrow host-cost question. Full T3 serving and the other stated coverage gaps remain open.

## Required refinements before concrete approval

1. **Specify the fast-path contract and proof obligations.** Match the existing immediate-success condition for the rounded demand, including actual FULL logical-ID and SWA capacity limits; use joint immediate capacity, not a minimum of independent reports, nominal conservation caps or recoverable/pending bytes. Preserve the existing cache-null/chunk-cache and nonpositive-demand behavior, deferred-free boundary, decorator/rank-consensus contract, and fallback for every false/unknown answer. Keep source tests for ready and just-not-ready cases with and without pending/deferred frees, independent ID limits and dynamic gates. A memo hit must have the same validity assumptions as the existing physical-capacity path. Do not make broader admission/reporting changes to obtain a faster number.

2. **Freeze candidate selection before timing.** The two-revision allowance is for a reviewed correctness repair, not two opportunities to select the faster noisy result. Nominate one correctness-passing, source-reviewed C before phases 2–3 and retain that pin through phases 5–6. Any later production delta invalidates its earlier measurements and requires a new explicit amendment; the present budget does not silently fund another cost comparison. Required Python/Rust tests that time out or cannot run remain incomplete gates. If the cached Rust extension cannot exercise C with verified import/extension provenance, report the gap rather than borrowing an old PASS or rebuilding without approval.

3. **Make the performance decision fully executable.** State explicitly that **T3-ready** is the primary target. For each complete block, define ratios from the per-process five-sample medians and define the corresponding absolute deltas. Resample whole B/A/C blocks with their arm association intact; express any log-ratio interval back on the ratio scale before applying the stated margins. Require all twelve complete, valid blocks for the proposed interval-based success declaration. Incomplete data remain descriptive/INCONCLUSIVE and cannot satisfy the cost gate. Preserve the supplementary, small-sample nature of the bootstrap: satisfying the chosen fixture margins is not proof of zero overhead, general equivalence or serving speedup.

   Define the pressure investigation threshold against **A**, the implementation being optimized, using paired process-median ratio and absolute increase; continue reporting C/B as context. Specify the same reporting for M2/S2 ready controls. An unresolved material deterioration must hold adoption even when the primary target succeeds. Do not choose a more favorable comparator or statistic after seeing results.

4. **Give same-event confirmation its own admission pair.** The first M2 distinct-event C normal/control pair does not validate the new same-event intervention or its leak/reclamation oracle. Before expanding the same-event matrix, run its first M2 C normal/control pair once as a second admission gate, counted within the existing 24-child registry. Predeclare whether failure of either admission stops the whole remaining matrix or only that event-pattern subset; no additional attempts are permitted. A normal or control PARTIAL cannot admit that pattern. Require both admission gates before any claim that both patterns are covered.

   The future same-event submission must enumerate moved physical sources independently, define exactly when each source must be protected or reclaimed, and distinguish premature reuse from a lost-ledger leak. A deliberately missing entry is not sufficient evidence by itself. Freeze the intended observable signature, original-reader/new-owner payload checks, actual reuse of both batches, and a safe cleanup dependency even on the injected-fault path. Unrelated accounting/setup failures must not become expected-control detections.

5. **Separate diagnostic observation from causation and safety evidence.** The phase-4 variants must name their exact warmups, allocations, observation points and profiler configuration before execution, within six children total. A profiler or wrapper may change timing; an event becoming complete after an operation only localizes a transition. Do not infer host synchronization solely from that ordering. Profile output and potentially synchronizing snapshots must be labelled separately. Confirmation must show its own prerequisites and sensitivity without relying on a profiled diagnostic window. Preserve the original physical reader addresses, exact ID-space conversions, stream-ordered urgent reuse and the existing prohibition on increasing sleeps or removing production synchronization.

6. **Make failure dependencies explicit without abandoning either objective.** A correctness-invalid C blocks all C workloads. A performance-inconclusive C stays isolated and cannot be adopted; it does not establish an async defect or invalidate independent A-based diagnosis. Phase 4 can still answer where the prior A/B fixture loses overlap once any earlier failure has a concrete disposition. If no valid frozen C exists, phase 5's C registry must be NOT_RUN unless a separately reviewed amendment substitutes another source; do not silently relabel A as C. An async admission PARTIAL stops its specified confirmation expansion, but must not be reported as a failed CUDA allocation test. A reachable production defect stops dependent work for a separate fix review.

These refinements may be incorporated in a plan addendum and the concrete submissions. They do not require enlarging the workload or running a preliminary experiment now.

## Budget and gate assessment

The sum is correct: **1200 + 300 + 2400 + 900 + 900 + 900 + 600 = 7200 seconds**, a new 120-minute experiment/check envelope. Each phase owns its deadline and final 15-second reserve; preparation/review exclusion must not be used to run uncharged warmups, imports, profiler calibration or trial candidates.

- Correctness: at most two reviewed revisions, one Python and one supported Rust suite each, four suite processes total. Freeze per-suite limits and exact required tests before execution.
- Diagnosis: four children, 60s each; 60 operations including warmups. Instrumented timings stay outside cost estimates.
- Cost: 36 children at up to 90s each, 900 measurements and 360 warmups only if complete. The 3240s nominal child maximum exceeds 2400s; no completion guarantee or retrospective sample reduction.
- Async diagnosis: six children at up to 90s each; fixed 2e9/1e9-cycle delays, no retry search.
- Confirmation: 18 C children plus six A normal controls equals 24. The 1080s nominal child maximum exceeds 900s; admission children are included, not added or rerun.
- CUDA regression: at most six frozen cases × A/C = twelve children, 60s each, 900s total. Identify the two gate/FLOAT cases explicitly in the executable sheet. Required movement and owner/payload conditions cannot be vacuous.
- Checks/aggregation: 600s without new workload cases. Budget exhaustion leaves required checks/report verification incomplete; it cannot be called adoption-ready.

Keep the stated CPU and tiny-CUDA RSS/log/device limits, profiler buffers within those limits, telemetry fail-closed behavior, and bounded parent/child/process-group cleanup. Distinguish preparation, profiled, unprofiled and cleanup time. Preserve recorded FAIL ahead of timeout classification, all rejected candidates and all incomplete blocks/rows.

## Final decision criteria

A successful local candidate requires a frozen reviewed diff, complete required correctness checks, the predeclared cost result, satisfactory relevant CUDA regressions and required code checks. The precise adoption decision remains a separate review; this plan does not approve moving the canonical branch.

Async conclusions require per-layout/per-pattern timing coverage **and** intended-control sensitivity. Missing sensitivity remains UNESTABLISHED even if normal payloads pass. Prebuilt-index/helper evidence remains separate from native production-path reachability; same-event, distinct-event, concurrent-writer, other-owner and distributed claims must not be conflated.

The final report must retain both independent verdicts: whether the narrow measured overhead was reduced within the chosen margins, and which asynchronous protection/reuse conditions were actually exercised. Either may remain OPEN without changing or concealing the historical evidence.
