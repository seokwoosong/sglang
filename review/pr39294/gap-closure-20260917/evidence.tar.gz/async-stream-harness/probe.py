"""Finite stream scheduling diagnosis; no allocator mutation or admission claim."""
import argparse,json,os,time,traceback
from common import *
from env_check import verify_environment
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--variant',choices=['default','default_query','explicit','explicit_query'],required=True);p.add_argument('--out',required=True);args=p.parse_args()
row=dict(status='RUNNING',variant=args.variant,source=provenance(args.version),environment=verify_environment(Path(__file__).resolve().parent.parent/'ENVIRONMENT.json'),scope='allocator-free CUDA stream scheduling diagnosis; no admission')
try:
 context=json.loads((Path(__file__).resolve().parent.parent/'CUDA_CONTEXT.json').read_text());flags={k:os.environ.get(k) for k in context['flags']};require(flags==context['flags'],'CUDA_CONTEXT_DRIFT');row['cuda_flags']=flags
 require(torch.cuda.memory.get_allocator_backend()==context['allocator_backend'],'CUDA_ALLOCATOR_BACKEND')
 producer=torch.cuda.Stream();consumer=torch.cuda.Stream() if args.variant.startswith('explicit') else torch.cuda.default_stream()
 events=[torch.cuda.Event(),torch.cuda.Event()];sentinel=torch.cuda.Event()
 source=torch.arange(128,dtype=torch.int64,device='cuda');indices=[torch.tensor([3],device='cuda'),torch.tensor([17],device='cuda')];reads=[torch.empty(1,dtype=torch.int64,device='cuda') for _ in range(2)]
 with torch.cuda.stream(producer):
  for i in range(2):torch.cuda._sleep(1);torch.index_select(source,0,indices[i],out=reads[i]);events[i].record(producer)
 with torch.cuda.stream(consumer):torch.cuda._sleep(1);sentinel.record(consumer)
 torch.cuda.synchronize()
 row['cuda_runtime']=dict(producer_stream=producer.cuda_stream,consumer_stream=consumer.cuda_stream,default_stream=torch.cuda.default_stream().cuda_stream,allocator_backend=torch.cuda.memory.get_allocator_backend(),torch_cuda=torch.version.cuda)
 with torch.cuda.stream(producer):
  torch.cuda._sleep(2_000_000_000);torch.index_select(source,0,indices[0],out=reads[0]);events[0].record(producer)
  torch.cuda._sleep(1_000_000_000);torch.index_select(source,0,indices[1],out=reads[1]);events[1].record(producer)
 with torch.cuda.stream(consumer):torch.cuda._sleep(1);sentinel.record(consumer)
 row['before_first_wait']=dict(readers_complete=[e.query() for e in events],sentinel_complete=sentinel.query())
 if args.variant.endswith('_query'):
  begin=time.perf_counter_ns();row['consumer_query_complete']=consumer.query();row['consumer_query_host_ns']=time.perf_counter_ns()-begin
 begin=time.perf_counter_ns();events[0].synchronize();row['first_wait_host_ns']=time.perf_counter_ns()-begin
 row['after_first_wait']=dict(sentinel_complete=sentinel.query(),second_reader_outstanding=not events[1].query())
 begin=time.perf_counter_ns();sentinel.synchronize();row['sentinel_wait_host_ns']=time.perf_counter_ns()-begin
 row['second_reader_outstanding_after_sentinel_wait']=not events[1].query()
 events[1].synchronize();sentinel.synchronize()
 require(reads[0].item()==3 and reads[1].item()==17,'READER_PAYLOAD')
 covered=not any(row['before_first_wait']['readers_complete']) and row['after_first_wait']['sentinel_complete'] and row['after_first_wait']['second_reader_outstanding'] and row['second_reader_outstanding_after_sentinel_wait']
 row['status']='PASS' if covered else 'PARTIAL';row['concurrent_sentinel_observed']=covered
except Failure as e:row.update(status='FAIL',failure=e.kind,detail=e.detail,traceback=traceback.format_exc())
except BaseException as e:row.update(status='FAIL',failure=type(e).__name__,detail=repr(e),traceback=traceback.format_exc())
finally:
 Path(args.out).write_text(json.dumps(row,indent=2)+'\n');print(row['status'],row.get('failure'))
raise SystemExit(0 if row['status'] in ('PASS','PARTIAL') else 1)
