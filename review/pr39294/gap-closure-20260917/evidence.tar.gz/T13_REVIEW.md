# T12 disposition and T13 static review

**T12 stop: DISPOSED as unavailable CUDA profiling evidence following CUPTI initialization failure. Preserve FAIL and the CPU-only trace.**

**T13: APPROVED, conditional execution of the exact four diagnostic children, once.** This disposition releases only the proposed alternative diagnosis; it does not release async admission, candidate adoption or other held work.

Review used static request/source/manifest/hash inspection and existing T12/T11 records. No submitted modules were imported, workloads executed, GPU queried, packages installed or source files modified.

## Exact identities

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T13_REQUEST.md | `756fcbae1bc1cced3ee91d605e09b18cd046cbc3160dcdf1664be4e68ecf696a` |
| T13.json | `26bce2927e0ad2cf525f02d166bcc100be8ee0ff148eb8b983b075b89081a96e` |
| t13_entry.py | `022e51f1f7ec2f0f23373d0cc8d9e6147c71c77b24c6181592f6003081130328` |
| async-stream-harness/probe.py | `0a7c4cd187a3a4e8202c47c494b77a7c270ef3605e34754eecc54b75c77bee75` |
| T12 STATUS.json | `307d65ac2c92679fd0a3149051f997ea6181112759cd2bf101629c3ff43cc83e` |
| T12 pinned-A-normal.json | `d19a5ac86026d6e6953fe815ce02265cf94964f8f9fda5aa6b74ffd7f717e5da` |
| T12 pinned-A-normal.log | `9c1f53c93989ce7df1224b8616562716ffecb799a11c0f59de85e72afce57301` |

Every file hash in T13.json matched, including the unchanged runner, common provenance helpers, environment checker and CUDA context. Commands, result paths, workdirs and PYTHONPATH consistently bind clean A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`.

## T12 technical disposition

The exact approved T12 v2 manifest produced STOPPED with worker exit 1 and cleanup PASS. The log explicitly reports `CUPTI_ERROR_UNKNOWN (999)` and missing CUDA profiler activities. The result records a 392,011-byte trace with zero device kernels, CUDA runtime events, correlated kernels/copies and dependency runtime events; the trace hash is `d903c2202f54e44545d315356edcfaa6714ec8ce84447ff00d8eb67ae4e784c5`. The trace validity gate correctly produced `CUDA_TRACE_VALIDATION_FAILED`.

The remaining fixture overlap result was PARTIAL; the recorded failure is trace validation, not a reported reader payload, mapping or accounting failure. Do not relabel the run PASS or treat its CPU-only trace as CUDA dependency evidence. The log establishes profiling initialization failure but not its root cause; WSL identification alone does not attribute the failure to WSL or the driver. No installation, privilege change, environment workaround or T12 retry is authorized.

T11's runner is COMPLETE with four exit-0/PASS/cleanup-PASS children. No unresolved execution failure is visible in that record. This review does not infer a quantitative residual-cost explanation from the diagnostic summary or accept C1 for adoption.

## T13 oracle and scope

The probe imports shared provenance helpers but does not instantiate or mutate an SGLang unified allocator. It still uses PyTorch tensor allocation during setup; “allocator-free” here means the SGLang allocator is absent from the observed scheduling test.

Approve the exact ordered variants `default`, `default_query`, `explicit`, `explicit_query`. They keep the same producer work and distinguish the consumer stream plus one additional `consumer.query()` call. Tensor/read/event/sleep warmups complete before the observed interval. No device-wide synchronization is introduced inside that interval. All tensor objects remain live until final synchronization/readback, and only the producer accesses reader outputs during the interval; the sentinel is independent work.

The oracle is conservative and directly observable: both reader events must initially be outstanding; after waiting E1, the sentinel must be complete while E2 remains outstanding; E2 must still be outstanding after the sentinel wait. Final E2/sentinel completion and exact reader values 3 and 17 are required. Thus a PASS means this fixture observed the sentinel completing while the second reader event remained outstanding. Missing timing prerequisites are PARTIAL, not failure or evidence of unsafe reuse.

The host waits are bounded by finite queued work plus the outer process guard. Successful and PARTIAL paths both complete final event synchronization and payload validation; exceptions exit nonzero and retain the runner's bounded process-group cleanup. No CUPTI or profiler support is required.

Interpretation must remain narrow: sentinel delay or completion relative to E2 does not by itself distinguish implicit stream dependencies, submission behavior, GPU resource scheduling or host observation effects. All variants use event queries; the query variants add a stream query, so they are not an observation-free control. One trial per variant supplies diagnostic evidence, not a causal driver/WSL attribution, performance estimate, or allocator correctness/admission result.

## Conditional authorization and unchanged holds

Exactly four children, **60 seconds each, 300 seconds total**, once, through hashed `t13_entry.py`. Retain fixed 2-billion/1-billion-cycle delays and all source/environment/context checks, 8 GiB RSS, 32 MiB per-child log, 3 GiB whole-device/headroom guards and bounded owned-process-group cleanup. No workload overlap, additional attempts, delay increase or budget transfer.

Launch only after existing work has completed or received disposition and cleanup has passed. The diagnosed, cleaned-up CUPTI failure does not hold this specific alternative. Any new functional/provenance/resource failure still stops dependent work and requires disposition.

T07's missing pinned admission remains missing. T08/T09/T10 are not released; T06 and C1 adoption remain held by their prior conditions. A T13 PASS cannot satisfy those gates. No source change, serving, push or merge is authorized.

Absolute execution cutoff remains **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST); final cleanup/reporting deadline **22:17:44 UTC** (07:17:44 KST). No deadline reset.
