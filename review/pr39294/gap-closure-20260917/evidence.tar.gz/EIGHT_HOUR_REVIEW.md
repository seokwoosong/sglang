# PR39294 eight-hour amendment review

**Decision: APPROVED — amended planning/iteration envelope and technical review gates.**

Focused static review of `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916/EIGHT_HOUR_AMENDMENT.md`, SHA256 `5d4408ffb44fd9a6c3bb5970cca7b29c0de4265b7f24062927a651da6f2c6375`. The amendment incorporates all six refinements from `/tmp/PR39294_GAP_CLOSURE_PLAN_REVIEW.md`. No broad corpus review, workloads, submitted imports, GPU queries, source edits or installation were performed.

The user's authorization now permits isolated local source/test preparation. The old plan-only, 120-minute total, two-candidate and one-async-correction ceilings are superseded. **This artifact does not approve an unspecified candidate, harness or experiment.** Each concrete execution ticket still requires the designated technical review. Earlier exhausted budgets are not revived, and remote/package/model-download restrictions remain.

## Fixed deadline

- Global start: **2026-09-16 14:17:44 UTC**.
- Workload cutoff: **2026-09-16 22:07:44 UTC**.
- Hard completion deadline: **2026-09-16 22:17:44 UTC**, equivalent to **2026-09-17 07:17:44 KST**.

The interval is exactly eight hours. All preparation, review, queued review time, experiments and cleanup consume it. The last ten minutes are reserved for cleanup, evidence preservation and reporting. Treat the workload cutoff as the end of execution, not merely the last permissible launch time: clip active parent/child deadlines to it, leave room for bounded termination, and start no new workload during the reserve. Complete final cleanup/reporting by the hard deadline. A ticket approval cannot extend either timestamp.

Use an absolute-deadline-to-monotonic mapping and record remaining time when each ticket starts. A restarted process or corrected harness must not receive a new global eight-hour allowance. Per-attempt defaults remain ceilings unless a concrete ticket explicitly proposes and receives a different finite allowance within the remaining global time. No workload overlap; finish early when both objectives and their final review are complete.

## Required ticket gates

1. **Evidence and scope:** identify the predecessor's exact result/failure, a falsifiable explanation, the proposed source or fixture delta, and the expected observable consequence. Preserve raw failures and all superseded candidates. A changed expectation requires independent justification and must be frozen before the new run; it cannot retroactively turn an observed defect into PASS.
2. **Identity and feasibility:** pin source/base/tree/diff, environment, actual import/backend provenance, harness/guard hashes and an explicit finite registry. Supply child limits, shared deadline, remaining global allowance, resource caps, failure precedence and bounded cleanup. Verify predecessor cleanup before sequential release. Source preparation authorization is not execution authorization.
3. **Correctness before measurement:** invalid C blocks its workloads. Freeze each reviewed, correctness-passing candidate through its measurement and required CUDA confirmation. A production change requires fresh evidence for the affected behavior; predecessor results remain historical, not acceptance evidence for a different source. Preserve the immediate-capacity/deferred-free/ID/rank-consensus/fallback contracts from the prior review.
4. **Performance:** use fresh complete associated B/A/C triples for the final twelve-block set. Retain the existing T3-ready targets: C/A ratio interval upper bound below 1, and C/B upper bounds below 1.10 and +5us. Incomplete validation is descriptive/INCONCLUSIVE. Pressure and other controls are assessed against A as specified; material unresolved deterioration holds adoption. No unchanged rerun solely to obtain a favorable interval.
5. **Async:** distinct-event and same-event patterns each require their own normal/control admission. PARTIAL stops that pattern's expansion; only an independently admitted pattern may continue. A new attempt needs a reviewed causal diagnostic or fixture correction. Exact same-event intervention, independently observed fault signature and safe cleanup remain prerequisites to executable approval. No automatic larger sleeps, hidden production synchronization changes or unbounded synchronization primitive.
6. **Progress and final disposition:** maintain an append-only ticket ledger with review identity, requested/allowed scope, actual start/end, source/harness identity, status and stop/cleanup evidence. A new production defect holds dependent work for a separate fix/test ticket. A final result/source review is still required before local adoption; no branch movement or remote approval is implied here.

## Statistical and coverage limits

Fresh validation data prevent reusing the same observations, but repeated candidate development and repeated nominal 95% intervals still introduce adaptive selection. Report the number and rationale of all attempts. Do not portray the eventual successful interval as a selection-adjusted 95% guarantee or general equivalence result. The approved target remains a fixture-bounded practical criterion. A stronger confirmatory statistical claim would require a separately frozen analysis/selection design.

Normal payload success is not async sensitivity. Each layout/event-pattern conclusion needs its declared timing/reuse prerequisites and intended negative-control detection. Keep helper/prebuilt-index evidence separate from native production reachability, and preserve the other-owner, writer, graph and distributed gaps. A failed control must not be hidden by expanding only successful layouts.

The amendment appropriately allows continued evidence-driven work while time remains, without automatic retries or favorable-result searches. If a required environment, checkpoint or other external prerequisite prevents progress, record the exact blocker. Time exhaustion ends with an honest partial/open disposition rather than relaxed gates or inferred success.

**Next step:** submit the concrete candidate and bounded execution tickets. No experiments are approved by this amendment alone; no additional permission is needed merely to prepare the user-authorized isolated local changes.
