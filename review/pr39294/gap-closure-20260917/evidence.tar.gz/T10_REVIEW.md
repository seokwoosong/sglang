# T10D / T10S prospective static review

**T10D: APPROVED conditionally. T10S: APPROVED independently and conditionally.** No mandatory correction is identified. Neither pattern is presently admitted by this review; each exact ticket may run once only after its own admission gate succeeds.

Review was limited to static request/manifest/entry-wrapper inspection, file hashing and registry arithmetic. No submitted modules were imported, workloads run, GPU queried or source files edited.

## Exact identities

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T10_REQUEST.md | `cd64387d6eb8962af0892e729a30cc06fdcf6f75d2cc1f32cbdee9bfa12ea5f7` |
| T10D.json | `db1205a20794bec619d40ef7e655c36aea895aaa7e5f0bc42cce0e2e6babfca1` |
| T10S.json | `e3c56248f1f86507203c1561f0936dd0b08f15bd876e4c5691c8b7337960fe56` |
| t10d_entry.py | `909330bdcb4d328cff0d411ba81bad961b2498f8215244da734bc9b3e52684fd` |
| t10s_entry.py | `76547e2e3fd5836a6fd6814877c01c8811cb527412d37ac9562df41acd9fc904` |

All manifest file hashes matched. Distinct-event probe remains the approved `fa72b06d23f031cf5822338b0f1bb604760325297825ad2b71c450eca7716e86`; same-event probe remains `67b74eeb430673b5fef4924568d833b03d6a5b38ae2777b1e913cf058e1de54f`. Runner, common fixtures, environment checker and CUDA context are unchanged.

Commands consistently bind version, layout, repetition, pinned variant, negative flag, result path and source worktree. A uses clean HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`; C uses that HEAD plus diff `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3`. Workdir/PYTHONPATH bindings agree. Normal children permit only PASS/PARTIAL; negative children permit only PARTIAL/EXPECTED_FAULT_DETECTED. The wrappers select the proper manifest and retain parent CUDA-context checks.

## Independent gates

- **T10D:** exact T08 COMPLETE, normal worker PASS, negative worker EXPECTED_FAULT_DETECTED, both cleanup PASS, and valid manifest/source/environment/result bindings.
- **T10S:** the equivalent conditions for exact T09.

The executor must retain and verify the authoritative admission artifacts before launch; these entry wrappers do not implement admission-result checks. A runner PASS that accepts a PARTIAL child is insufficient. Missing or PARTIAL admission blocks only that pattern's confirmation; the independently admitted pattern may proceed if no unresolved functional/provenance/resource failure holds it. An unexpected failure requires disposition and cannot be bypassed as mere missing coverage.

Prior T07 admission prerequisites, C1 correctness and frozen source/environment requirements remain in force. Wait for T04V2 and any intervening workload to finish or receive disposition and complete cleanup. No overlap is authorized. A performance miss is not source-adoption approval and does not erase applicable failure-disposition gates.

## Registry and budget

Each ticket contains ten children in the stated order: C normal M2 repeat 1; C normal S2 and T3 repeats 0/1; C negative S2 and T3 repeat 0; A normal M2/S2/T3 repeat 0. Combined with T08/T09's two admission children each, the confirmation registry has exactly **24 unique pattern/version/layout/repetition/polarity cells: 12 C normal, 6 C negative, 6 A normal**. Earlier diagnostic attempts remain separate evidence and must not be added again as confirmation successes.

Each T10 ticket has a **210-second shared ceiling**, with **45 seconds per child**. Ten child maxima sum to 450 seconds, so the shared ceiling may truncate the registry; completing all ten is not guaranteed. The runner's 15-second cleanup reserve and launch-headroom check further bound usable time. The inherited probe comment mentioning a 90-second guard does not override these 45-second manifest limits.

Summed confirmation ticket ceilings are **240 + 240 + 210 + 210 = 900 seconds**. No unused-budget transfer, extra repetition, rerun or extension is authorized. Keep the original order and preserve PARTIAL/NOT_RUN/failure outcomes rather than selecting successful cells. Later PARTIAL is missing coverage; it does not authorize extra attempts or invalidate an independently established result automatically.

## Scope and safeguards

Approval covers the unchanged FULL-owner, page-1, lazy helper fixtures in M2/S2/T3 with real CUDA copy/remap, old-reader payload, actual physical reuse, retained/new-owner payload and accounting checks. It retains the disclosed warmups, prebuilt indices and pinned snapshot protocol. Negative success still requires the independent observed signature and all other checks; injected metadata alone is insufficient. The same-event probe's narrowly bounded post-completion repair remains confined to its negative control.

These are not Mamba/FLOAT-owner movement tests, full production-flush reachability, writer/graph/distributed validation, or a universal async-safety claim. Report results per cell and per independently admitted pattern. No source adoption or merge-readiness conclusion follows from prospective approval.

Keep the unchanged 8 GiB RSS, 32 MiB per-child log, 3 GiB whole-device/headroom guards, sequential owned-process-group cleanup and source checks. Absolute execution cutoff remains **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST); final cleanup/reporting deadline remains **22:17:44 UTC** (07:17:44 KST). No budget reset, serving, push or merge is authorized.
