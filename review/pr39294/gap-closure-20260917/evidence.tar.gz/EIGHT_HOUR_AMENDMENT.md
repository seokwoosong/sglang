# User-authorized eight-hour execution amendment

User now authorizes execution and provides eight hours from now, asking for continued evidence-driven correction/retesting while time remains. Start recorded 2026-09-16 14:17:44 UTC; hard deadline 2026-09-16 22:17:44 UTC (2026-09-17 07:17:44 KST). This replaces V1's plan-only turn and 120-minute total/two-candidate/one-correction ceilings. All preparation, review, execution and cleanup count toward the global eight hours. Reserve final10min for report/cleanup. Success may finish earlier; no idle waiting to consume budget.

V1 is preserved as PLAN_V1.md with PLAN_V1_REVIEW.md. All six reviewer-required refinements apply:
- Fast path exactly matches existing rounded-demand immediate success after deferred-free boundary, preserving null/chunk/nonpositive behavior, rank consensus, immediate joint capacity and independent ID limits; false/unknown takes unchanged fallback.
- Each production candidate is selected by correctness/source review before timing, frozen through its own measurement and CUDA confirmation. Never choose the fastest noisy candidate. Later changed production invalidates its predecessor's acceptance evidence.
- Primary T3-ready statistic: per-process median of5 measurements; per-block C/A and C/B ratios/deltas. Resample complete associated triples. All12blocks required for the predeclared interval-based criterion. Incomplete data remain descriptive. Pressure/control deterioration is investigated against A using paired median ratio>1.10 AND delta>5us; C/B remains reported. Any material unresolved deterioration holds adoption.
- Same-event and distinct-event patterns each need their own M2 normal/control admission. A pattern's PARTIAL stops that pattern expansion, not the independently admitted pattern. Same-event control must detect independently evidenced lost reclamation/protection, not merely changed metadata.
- Exact warmup/observation/profiler code is reviewed first. Observation transition is not proof of synchronization. Confirmation unprofiled. No silent larger sleeps or production synchronization removal.
- Correctness-invalid C blocks C workloads; performance-inconclusive C does not block independently reviewed A diagnosis. No silent A-as-C substitution. New production defects require separately reviewed fix+tests.

## Repeat policy within eight hours

The previous phase envelopes remain per-attempt defaults. Additional attempts may be authorized by designated-session review of a concrete ticket specifying: prior evidence, falsifiable cause, exact diff/fixture correction, fresh source/harness hashes, changed expectation, registry/counts, child and shared deadlines clipped to global deadline. They are not automatic retries and do not reset the global clock. No unexplained unchanged rerun or search for a favorable p-value.

For performance, exploratory diagnostic/tuning data are retained and labeled. Freeze final candidate and a fresh full12block validation set before starting final validation. If final validation misses its target, report that result; another candidate requires a mechanistic change and a new reviewed ticket, with all previous results retained. Success is fixture-bounded practical improvement, not zero-overhead proof.

For async, once an admission is PARTIAL, instrument/localize the cause before another fixture attempt. New warmups, preallocation or synchronization primitives require exact review and finite cleanup. A corrected fixture must reproduce its prerequisite and intended control reliably across the fixed confirmation repeats. Extend layouts/pages only to close a concrete source-risk gap, with a reviewed registry. All failed admissions count in total effort and remain in the final report.

Budget management: append each ticket's start/end/status to an execution ledger. Review/setup time charged globally. No new phase after global deadline minus10min; all child/parent deadlines clipped accordingly. If both objectives are resolved with required regressions and final review, finish early. If time remains and an unresolved issue admits a concrete next diagnostic/fix, continue. If an external requirement prevents progress, report exactly what is missing; do not invent success.

No remote push, PR mutation, merge, package installation/model downloads or unrelated worktree edits. Local isolated implementation/test edits are now authorized by user; concrete execution still receives designated-session technical review before running.
