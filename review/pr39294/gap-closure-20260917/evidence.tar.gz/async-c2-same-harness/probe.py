"""Same-event FULL-owner helper sensitivity, prebuilt indices; not natural flush reachability."""
import argparse,json,traceback,sys,time,os
from unittest.mock import patch
from common import *
from env_check import verify_environment
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--layout',choices=['M2','S2','T3'],required=True);p.add_argument('--repeat',type=int,required=True);p.add_argument('--negative',action='store_true');p.add_argument('--variant',choices=['blocking','warm_blocking','pinned'],required=True);p.add_argument('--out',required=True);args=p.parse_args()
consumer_context=None
row=dict(variant=args.variant,status='RUNNING',source=provenance(args.version),environment=verify_environment(Path(__file__).resolve().parent.parent/'ENVIRONMENT.json'),layout=args.layout,repeat=args.repeat,negative=args.negative,scope='same-event two-batch original helper; independent completed-source reclamation oracle; prebuilt indices; pinned observation; not production flush reachability',observations=[]);f=None
try:
 execution_context=json.loads((Path(__file__).resolve().parent.parent/'CUDA_CONTEXT.json').read_text())
 actual_flags={k:os.environ.get(k) for k in execution_context['flags']}
 require(actual_flags==execution_context['flags'],'CUDA_CONTEXT_DRIFT',actual_flags)
 row['cuda_flags']=actual_flags
 require(not args.negative or args.version in ('A','C'),'NEGATIVE_ARM')
 f=Fixture(args.layout,1,True,device='cuda');a=f.a;fa=a.full_attn_allocator
 if f.layout!='S2':states=a.mamba_allocator.alloc(8);require(states is not None,'STATE_SETUP')
 slots=a.alloc(64);require(slots is not None,'KV_SETUP')
 a.free(slots[10:11]);a.free(slots[20:21]);saved=f.stamp(1+args.repeat);f.check()
 require(fa.page_size==fa.pool_page_size==1,'PHYSICAL_KERNEL_PAGE_UNITS')
 holes=fa._free_phys_pages.tolist();require(len(holes)==2,'HOLE_SETUP',holes)
 live=torch.where(fa.physical_to_virtual>=fa.min_page_index)[0].tolist();sources=sorted(live)[-2:]
 require(len(sources)==2 and len(set(sources+holes))==4,'MOVE_GEOMETRY')
 cached={(x,):torch.tensor([x],dtype=torch.int64,device='cuda') for x in sources+holes}
 vids=[fa.physical_to_virtual[cached[(x,)]].clone() for x in sources]
 kernel_indices=[fa.translate_kv_loc_for_kernel(v) for v in vids]
 # Reader sees old FULL key rows through the original kernel index space.
 fullbuf=f.b.token_to_kv_pool.get_key_buffer(0);expected=[fullbuf[ix].clone() for ix in kernel_indices];reads=[torch.empty_like(x) for x in expected]
 for x in sources:fa._kvcache.move_kv_cache(cached[(x,)],cached[(x,)])
 empty=fa._free_phys_pages[:0].clone();events=[torch.cuda.Event(),torch.cuda.Event()];producer=torch.cuda.Stream();consumer=torch.cuda.Stream();waits=[]
 row.update(geometry=f.geometry(),initial=f.snapshot(),sources=sources,destinations=holes,source_virtual_ids=[x.tolist() for x in vids],source_kernel_indices=[x.tolist() for x in kernel_indices])
 # Setup tensors were created on the default stream; finish setup before
 # using the explicit consumer for helper warmups and the observed interval.
 torch.cuda.synchronize()
 consumer_context=torch.cuda.stream(consumer);consumer_context.__enter__()
 # Fixed four original-helper warmup calls, with exact mapping restored.
 if True:
  for warm_sources,warm_destinations in [(sources,holes),(holes,sources)]:
   fa._free_phys_pages=empty;warm_released=[]
   for warm_src,warm_dst in zip(warm_sources,warm_destinations):
    fa._commit_move_batch([warm_src],[warm_dst],None,warm_released)
   fa._free_phys_pages=torch.cat([empty,*warm_released])
  f.check_saved(saved);f.check()
 torch.cuda.synchronize()
 allocator_backend=torch.cuda.memory.get_allocator_backend()
 require(allocator_backend==execution_context['allocator_backend'],'CUDA_ALLOCATOR_BACKEND',allocator_backend)
 row['cuda_runtime']=dict(allocator_backend=allocator_backend,torch_cuda=torch.version.cuda,device=torch.cuda.current_device(),producer_stream=producer.cuda_stream,consumer_stream=consumer.cuda_stream,default_stream=torch.cuda.default_stream().cuda_stream,producer_device=str(producer.device),consumer_device=str(consumer.device))
 original_tensor=torch.tensor;original_wait=torch.cuda.Stream.wait_event
 def tensor(data,*pos,**kw):
  if isinstance(data,list) and tuple(data) in cached and kw.get('dtype')==torch.int64 and str(kw.get('device')) in ('cuda','cuda:0'):
   require(not pos,'INDEX_WRAPPER_ARGUMENTS');return cached[tuple(data)]
  return original_tensor(data,*pos,**kw)
 def wait(stream,event):
  if event in events:waits.append(dict(event=events.index(event),stream=stream.cuda_stream,outstanding=not event.query()))
  return original_wait(stream,event)
 if True:
  with torch.cuda.stream(producer):
   torch.cuda._sleep(1)
   torch.index_select(fullbuf,0,kernel_indices[0],out=reads[0]);events[0].record(producer)
   torch.cuda._sleep(1)
   torch.index_select(fullbuf,0,kernel_indices[1],out=reads[1]);events[1].record(producer)
  torch.cuda.synchronize()
 pinned=None;copy_done=None
 if args.variant in ('warm_blocking','pinned'):
  pinned=torch.empty(2,dtype=torch.int64,pin_memory=True);require(pinned.is_pinned(),'PINNED_HOST_BUFFER')
  copy_done=torch.cuda.Event()
  for warm_parts in ([cached[(sources[0],)]],[cached[(sources[0],)],cached[(sources[1],)]]):
   warm_free=torch.cat([empty,*warm_parts]);pinned[:warm_free.numel()].copy_(warm_free,non_blocking=True);copy_done.record(consumer);copy_done.synchronize()
  del warm_free;torch.cuda.synchronize()
 def free_snapshot(values):
  if args.variant!='pinned':return values.tolist()
  n=values.numel();require(n<=2,'SNAPSHOT_CAPACITY')
  if not n:return []
  pinned[:n].copy_(values,non_blocking=True);copy_done.record(consumer);copy_done.synchronize()
  return pinned[:n].tolist()
 with torch.cuda.stream(producer):
  torch.cuda._sleep(2_000_000_000)
  torch.index_select(fullbuf,0,kernel_indices[0],out=reads[0]);events[0].record(producer)
  torch.cuda._sleep(1_000_000_000)
  torch.index_select(fullbuf,0,kernel_indices[1],out=reads[1]);events[1].record(producer)
 if args.negative:
  class OverwritePreviousBatch(dict):
   def get(self,key,default=None):
    return default if key is events[1] else super().get(key,default)
  fa._pending_reuse=OverwritePreviousBatch(fa._pending_reuse)
 released=[];fa._free_phys_pages=empty
 row['before_commit_events_complete']=[ev.query() for ev in events]
 with patch.object(torch,'tensor',tensor):
  fa._commit_move_batch([sources[0]],[holes[0]],events[1],released)
  fa._commit_move_batch([sources[1]],[holes[1]],events[1],released)
 outstanding=[not ev.query() for ev in events];row['outstanding_after_commit']=outstanding
 # Deliberately host-complete event one only, preserving the second interval if it exists.
 events[0].synchronize();second_before=not events[1].query()
 drain_started=time.perf_counter_ns();fa._drain_pending_reuse(urgent=False);drain_ended=time.perf_counter_ns()
 row['second_outstanding_after_drain']=not events[1].query()
 pending=set(fa._pending_reuse_pages_cpu);snapshot_started=time.perf_counter_ns();free_after=free_snapshot(fa._free_phys_pages);snapshot_ended=time.perf_counter_ns();second_after=not events[1].query()
 row['observation_host_ns']=dict(drain=drain_ended-drain_started,snapshot=snapshot_ended-snapshot_started)
 row['snapshot_mode']=args.variant
 row.update(second_outstanding_before_nonurgent=second_before,second_outstanding_after_nonurgent=second_after,pending_after_nonurgent=sorted(pending),free_after_nonurgent=free_after)
 prerequisite=all(outstanding) and second_before and second_after
 # Merge the original helper's already-fired release output, as its caller does.
 if released:
  fa._free_phys_pages=torch.cat([fa._free_phys_pages,*released]);released.clear()
 # Both batches depend on the second reader's ONE event.
 if prerequisite:
  require(not set(sources)&set(free_after),'SAME_EVENT_PREMATURE_REUSE')
  require(set(sources)<=pending,'SAME_EVENT_PENDING_PROTECTION_LOSS')
 with patch.object(torch.cuda.Stream,'wait_event',wait):fa._drain_pending_reuse(urgent=True)
 dependency=events[1].query() or any(w['event']==1 and w['stream']==consumer.cuda_stream for w in waits)
 require(dependency,'URGENT_REUSE_DEPENDENCY_MISSING');row['urgent_dependency_observed']=dependency
 # Copy event follows the urgent wait; this host snapshot proves the protected
 # event completed before evaluating actual reclamation of both moved sources.
 after_urgent=free_snapshot(fa._free_phys_pages)
 event_complete=events[1].query();missing_sources=set(sources)-set(after_urgent)
 row.update(free_after_urgent=after_urgent,event_complete_after_urgent_snapshot=event_complete,missing_completed_sources=sorted(missing_sources),pending_after_urgent=sorted(fa._pending_reuse_pages_cpu))
 detected=prerequisite and event_complete and missing_sources=={sources[0]} and sources[1] in after_urgent
 if args.negative:
  row['negative_signature']='COMPLETED_READER_SOURCE_NOT_RECLAIMED' if detected else None
  row['negative_detection_prerequisite']=prerequisite
  # Safe test-local repair only after independent signature capture and reader
  # completion; never overwrite an in-flight reader to demonstrate a fault.
  consumer.wait_event(events[1]);events[1].synchronize()
  if missing_sources:
   require(missing_sources=={sources[0]} and sources[1] in after_urgent,'UNEXPECTED_RECLAMATION_LOSS')
   require(not fa._pending_reuse,'UNEXPECTED_PENDING_EVENT')
   fa._pending_reuse_pages_cpu.discard(sources[0])
   fa._free_phys_pages=torch.cat([fa._free_phys_pages,cached[(sources[0],)]])
   row['negative_cleanup_repaired_source']=sources[0]
 else:
  require(not missing_sources,'COMPLETED_SOURCE_RECLAMATION_LOSS')
 # Events/reads are now ordered before new writes on this consumer stream.
 if released:fa._free_phys_pages=torch.cat([fa._free_phys_pages,*released])
 fresh=a.alloc(2);require(fresh is not None,'REALLOC_FAILED')
 new={'full':fresh}
 if f.layout!='M2':new['swa']=fresh
 f.check_new_allocation(new,2,saved,{})
 new_physical=fa.virtual_to_physical[fresh].tolist();reused=set(new_physical).intersection(sources);row['new_full_physical_pages']=new_physical;row['reused_source_pages']=sorted(reused)
 f.check_saved(saved);fresh_saved=f.stamp(5+args.repeat,only=new);torch.cuda.synchronize()
 for got,want in zip(reads,expected):require(torch.equal(got,want),'ORIGINAL_READER_PAYLOAD')
 f.check_saved(saved);f.check_saved(fresh_saved);fa._drain_pending_reuse(urgent=False);f.check()
 require(not fa._pending_reuse and not fa._pending_reuse_pages_cpu,'PENDING_LEAK')
 row['waits']=waits
 if args.negative:
  require(set(sources)<=reused,'POST_REPAIR_SOURCE_REUSE_MISSING')
  row['status']='EXPECTED_FAULT_DETECTED' if detected else 'PARTIAL';row['missing']=[] if detected else ['negative-control sensitivity prerequisite or intended detection absent']
 else:
  missing=[]
  if not prerequisite:missing.append('two outstanding events and first-only completion interval')
  if not set(sources)<=reused:missing.append('actual physical reuse of BOTH same-event batch sources')
  row.update(status='PARTIAL' if missing else 'PASS',missing=missing)
except Failure as e:row.update(status='FAIL',failure=e.kind,detail=e.detail,traceback=traceback.format_exc())
except BaseException as e:row.update(status='FAIL',failure=type(e).__name__,detail=repr(e),traceback=traceback.format_exc())
finally:
 # Fixed finite GPU sleeps only; outer90s guard kills this process group if cleanup stalls.
 sys.settrace(None)
 if consumer_context is not None:consumer_context.__exit__(None,None,None)
 if f is not None:f.close()
 Path(args.out).write_text(json.dumps(row,indent=2)+'\n');print(row['status'],row.get('failure'))
raise SystemExit(0 if row['status'] in ('PASS','PARTIAL','EXPECTED_FAULT_DETECTED') else 1)
