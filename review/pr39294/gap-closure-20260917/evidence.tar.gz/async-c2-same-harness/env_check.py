"""Read-only environment identity, no torch/AOT import or JIT warming."""
import hashlib,importlib.metadata as md,importlib.util,json,subprocess,sys
from pathlib import Path

def capture(timeout=10):
 freeze=subprocess.check_output([sys.executable,'-m','pip','freeze'],timeout=timeout)
 modules={}
 for distribution,module in [('sglang-kernel','sgl_kernel'),('torch','torch'),('flashinfer-python','flashinfer')]:
  origin=Path(importlib.util.find_spec(module).origin).resolve()
  modules[distribution]=dict(version=md.version(distribution),module_origin=str(origin),module_file_sha256=hashlib.sha256(origin.read_bytes()).hexdigest())
 return dict(python=str(Path(sys.executable).resolve()),python_version=sys.version,freeze_sha256=hashlib.sha256(freeze).hexdigest(),installed_modules=modules)

def verify_environment(path,timeout=10):
 actual=capture(timeout);expected=json.loads(Path(path).read_text())
 assert actual==expected,('ENVIRONMENT_MISMATCH',actual,expected)
 assert actual['installed_modules']['sglang-kernel']['version']=='0.4.7'
 return actual
