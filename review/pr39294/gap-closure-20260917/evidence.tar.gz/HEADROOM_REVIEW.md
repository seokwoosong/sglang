# Prelaunch headroom disposition and v2 continuation

Decision: **APPROVED, with the existing sequential stop gates.** Accept the exact initial admission ceiling change and T17D / T22D / optional T23D bindings below. No further resource increase, automatic retry or unrelated-process termination is authorized.

## Stop disposition

The preserved T17C STATUS record shows `GPU_HEADROOM` rejection at 2206 MiB used / 29981 MiB free, before Popen. The first case row has no PID or exit/result status, peak RSS zero, and cleanup PASS. Therefore **zero workload children launched**. Preserve its raw FAIL/STOPPED labels, while reporting the case as NOT_RUN due to resource admission. This is not an allocator, payload or CUDA test failure; cleanup PASS here means no owned child needed cleanup, not that the GPU was globally idle.

STATUS SHA256: `e1dc2e858dd96fc653f5c7e43e4f131ea853c3656104f240308a0999ebf89d6c`.

## Exact reviewed bindings

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
| --- | --- |
| HEADROOM_REQUEST.md | `ad50f1605ea8312cfb13837c4575d176c5f3dc5391b11dfd6b09e336ceaf00e3` |
| continuation_runner_v2.py | `a201209336fd30da1a39bd75f16cf8603f218d84c8737254f3ea6a5de2bb5696` |
| continued_entry_v2.py | `2d15375710e04b5174a3690cceabd94531a5208bcdc1fcfa2ff83f38fa76572c` |
| T17D.json | `73d0305baad77d61b12c61925f009f6f929ddb4b10f8f32f7623aab69a21cfa4` |
| T22D.json | `f3002abe8365fe42dc2d8d930c70a08cc83c0821bbe30814f796b27c2286cc16` |
| T23D.json | `336cea27fe79f0dbf8c3e88306d8450389e7814203db1aa9fe0d270cca232dc6` |

All manifest file hashes matched. Complete case registries match the C versions after output-directory rebinding only. Probes, source pins, oracles, allowed result labels, commands apart from output paths, ordering and child/ticket limits are unchanged. The wrapper changes only its runner target. CUDA_CONTEXT.json is now hash-bound in all three manifests, resolving the prior T17C external-binding condition. Invoke the context-checking v2 entry with only these approved manifests.

## Resource assessment

The runner diff changes only the initial used-memory ceiling from 2048 to 2560 MiB. Minimum free memory remains 1024 MiB; the runtime whole-device rejection threshold remains used > 3072 MiB. RSS, log, telemetry timeout, source/environment/hash checks, per-child/ticket deadlines and bounded process-group cleanup are unchanged.

At the recorded 2206 MiB baseline, approximately 800 MiB additional use would total 3006 MiB, leaving only 66 MiB below the runtime threshold. That estimate is not a reservation or guarantee. At the newly permitted 2560 MiB maximum baseline the same increment would exceed the threshold. Admission therefore permits one bounded attempt under monitoring; it does not establish that all admitted baselines can complete. Free physical VRAM is distinct from remaining headroom under the experiment's whole-device threshold.

The runtime guard is sampled telemetry, not a hardware allocation cap: a transient overshoot can occur between polls, and recorded peak is an observed peak. Do not claim memory was continuously below 3072 MiB. Preserve the existing stop on an observed value greater than 3072 MiB, telemetry failure or other guard failure. If this occurs, save the resource-limited result, clean up owned processes, and seek disposition before any further attempt. No automatic reset, escalating ceiling or repeated headroom polling loop is approved.

The reported absence of visible GPU processes does not prove exclusive use under incomplete WSL attribution. Do not kill unrelated processes or subtract estimated unrelated use from whole-device telemetry.

## Approved continuation

1. T17D: ten synchronized A/C2 CUDA regression children, 60 seconds each / 900 seconds total. Existing T14/T16 source and performance prerequisites remain in force. Inspect results and cleanup before proceeding; PARTIAL is incomplete coverage, not regression PASS.
2. T22D: four A late-operation diagnostic children, 60 seconds each / 300 seconds total, after T17D disposition and cleanup.
3. T23D only if still needed: one A/M2 instrumented helper diagnostic, 90 seconds / 180 seconds total, after T22D disposition and cleanup. Preserve the prior time-scanned marker and instrumentation caveats.

Keep tickets sequential, use fresh output directories, and preserve all earlier evidence. Unresolved correctness, provenance or cleanup failures hold dependent work. The wrappers do not enforce predecessor admission; the executor must record it. The user's removal of the old global deadline remains effective, while all finite ticket/child limits remain binding. No source mutation or change to readiness, push or shutdown disposition follows from this resource amendment.

Static text/JSON/hash review only. No workloads, submitted-module imports, GPU queries or source edits were performed; only this review artifact was written.
