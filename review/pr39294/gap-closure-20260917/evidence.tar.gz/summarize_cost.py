"""Read-only, predeclared cost analysis for frozen 12-block B/A/C validation."""
import json,math,random,statistics
from pathlib import Path
R=Path(__file__).resolve().parent;D=R/'t04-c1-cost'
def q(xs,p):
 s=sorted(xs);x=(len(s)-1)*p;i=int(x);return s[i]+(s[min(i+1,len(s)-1)]-s[i])*(x-i)
status=json.loads((D/'STATUS.json').read_text());blocks=[]
for i in range(12):
 paths={v:D/f'{i}-{v}.json' for v in 'BAC'}
 if all(p.exists() for p in paths.values()):
  rows={v:json.loads(p.read_text()) for v,p in paths.items()}
  if all(x['status']=='PASS' for x in rows.values()):blocks.append((i,rows))
result={'complete_blocks':[i for i,_ in blocks],'status':status['status'],'scenarios':{},'statistical_note':'Adaptive candidate development is not selection-adjusted; intervals are supplementary fixture-bounded descriptions, not general equivalence guarantees.'}
for j,name in enumerate(['M2-ready','S2-ready','T3-ready','S2-pressure','T3-pressure']):
 if not blocks:break
 med={v:[statistics.median(s['host_ns']/1000 for s in b[v]['scenarios'][j]['samples']) for _,b in blocks] for v in 'BAC'}
 entry={'medians_us':med,'comparisons':{}}
 for baseline in 'AB':
  ratios=[c/b for c,b in zip(med['C'],med[baseline])];deltas=[c-b for c,b in zip(med['C'],med[baseline])]
  values={'ratios':ratios,'deltas_us':deltas,'median_ratio':statistics.median(ratios),'median_delta_us':statistics.median(deltas)}
  if len(blocks)==12:
   rng=random.Random(39294);lr=[math.log(x) for x in ratios];rb=[];db=[]
   for _ in range(10000):
    ix=[rng.randrange(12) for _ in range(12)];rb.append(statistics.median(lr[k] for k in ix));db.append(statistics.median(deltas[k] for k in ix))
   values['ratio_ci95']=[math.exp(q(rb,.025)),math.exp(q(rb,.975))];values['delta_us_ci95']=[q(db,.025),q(db,.975)]
  entry['comparisons']['C/'+baseline]=values
 entry['material_deterioration_vs_A']=entry['comparisons']['C/A']['median_ratio']>1.10 and entry['comparisons']['C/A']['median_delta_us']>5
 result['scenarios'][name]=entry
if len(blocks)==12 and status['status']=='COMPLETE':
 primary=result['scenarios']['T3-ready']['comparisons']
 result['primary_margin_met']=primary['C/A']['ratio_ci95'][1]<1 and primary['C/B']['ratio_ci95'][1]<1.10 and primary['C/B']['delta_us_ci95'][1]<5
else:result['primary_margin_met']=None
result['control_investigation_required']=[n for n,x in result['scenarios'].items() if n!='T3-ready' and x['material_deterioration_vs_A']]
(R/'COST_ANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
