# Read-only documentation notes for unresolved scheduling diagnosis
NVIDIA advanced host programming guide: https://docs.nvidia.com/cuda/cuda-programming-guide/03-advanced/advanced-host-programming.html
CUDA13.0 archived guide: https://docs.nvidia.com/cuda/archive/13.0.0/cuda-c-programming-guide/index.html

The current guide describes implicit synchronization and hardware-resource-dependent overlap, and notes that connection sharing can create false dependencies across independent streams. This is a hypothesis source only, not an explanation established by our measurements. No CUDA environment variable has been changed. Any context variant would require a separate concrete review and explicit context/result binding; it could not silently replace validation of the default context. CUPTI failure is still not attributed to a specific cause.

T22 separates late submission from selected operations. T23, if approved, observes actual original-helper consumer completion prefixes. Use their results before proposing a context diagnostic. GPU trace evidence remains unavailable.
