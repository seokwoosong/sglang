# C2 / T14 focused static review

**APPROVED — exact C2 candidate is suitable for the proposed bounded CPU correctness ticket.** No mandatory source or test correction is identified. This is authorization to validate the isolated candidate, not correctness-result acceptance, timing authorization or adoption.

Review used static patch/source/test/entry-wrapper inspection, read-only Git identity/diff checks and file hashing. No submitted imports, tests, workloads, GPU queries or source edits were performed.

## Exact identity

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T14_REQUEST.md | `0550baae5aba57ccb19f95475d6054ac7c5a88bef574c95c419decbbfc6a172d` |
| T14.json | `bed11015ecaa8de856eba76f68410c92f2cf1c6148979c7bce88fd795e1c4245` |
| C2.patch / actual C2 binary diff | `4451ee8cc9ddb025f13a8ea954370c7d20ebac6310c454cd438379ff9433e5e0` |
| C2 unified_hybrid_swa.py | `4cfe9162c7da86b31584770693619495d985dd4b44239f732597e5bb0f156e8d` |
| C2 test_unified_tri_joint_reclaim.py | `f625a27d5e11bd0d3fef7186b671dc71203188e50ed79e6e78c18f23eb38ed3e` |

All manifest file hashes matched. The isolated worktree `/home/sukwoo24/sglang-eval-worktrees/pr39294-gap-c2` is at A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, with exactly the two modified files above. Its actual binary diff matches C2.patch and both ticket source bindings. C1 remains a separate frozen candidate and its failed performance evidence is not replaced.

## Production-change assessment

Relative to C1, production changes are only the `free_group is not None` guard around `flush_deferred_full_frees()` and moving the local `EvictParams` import below the immediate-ready return.

The concrete tri helper passes the ordinary, representative and FULL-only queues to `_flush_deferred_free_group`. That helper returns immediately when `allocator.free_group is None`, before `any(pending_groups)` or mutation. Skipping its dispatch in precisely that state preserves current semantics. When the group is active, including an empty ordinary list, C2 still invokes the helper and therefore still sees representative/FULL-only pending queues. This must remain an identity check against None, not a truthiness check of the ordinary list.

The inspected source has no tri subclass/helper override that gives no-group dispatch another contract. This proof applies to the concrete implementation and its existing deferred-free interface; it does not promise invocation counts to hypothetical overrides. The change does not remove the public helper or change other callers.

`EvictParams` is needed only by the retained slow path, and the import remains before every use. Null/chunk-cache and nonpositive-demand behavior, page rounding, rank-consensus decoration, recovery branches and slow-path bounds are unchanged. The immediate-ready conjunction still requires both `_token_id_capacity` and physical `available_size`; the FULL free-ID and independent SWA live-ID bounds remain intact. The allocation/ensure path retains its own ID check. The measured cost of those checks does not justify removing them, and C2 does not do so.

## Test assessment

The added group dimension produces eight ready-path subcases: group inactive/active-empty × page size 1/4 × eager/lazy. Active groups are explicitly checked to remain open; actual allocation, retained cache bindings, existing KV/conv payload and allocator accounting are checked. Page-4 uses the supported FULL+SWA cache with request-owned Mamba states. These are semantic state assertions, not tests of a particular helper call count.

Existing `test_grouped_frees_and_streaming_wrapper` covers nonempty ordinary, representative and FULL-only queues being exposed without cache eviction while preserving the group scope. In particular, FULL-only/representative coverage is necessary alongside the new active-empty case; retain it. The new fixture's default temporal shape is empty, so this extension is not new temporal-payload coverage. Direct closed gate fields in the ready-only CPU fixture are white-box conditions, not a claim that the public eager move-gate API is supported.

## Exact correctness authorization

Approve the two unchanged T01 suite commands rebound to C2: **17 Python unit files**, then **three Rust unit files with `-k 'not session'`**, one process per backend. Each child is capped at **300 seconds**; ticket ceiling **1200 seconds**. The commands match the prior approved T01 commands exactly. Session exclusion remains Rust-specific; it is not permission to drop additional failures or tests.

The unchanged correctness entry validates the imported hybrid source path and environment, and requires the pinned Rust extension SHA256 `1709a59dc2fb15a0f27e6bbce0dcb0d4906e39c0ec5e42a50bac19b886b6d42d`. CUDA is hidden, CPU engine enabled and Rust build mode `never`; no rebuild, dependency change or GPU workload is authorized.

Wait for T13 and any other active workload to finish or receive disposition and pass owned-process cleanup. The T12 profiling stop has already been disposed in `/tmp/PR39294_T13_REVIEW.md`; a new T13 functional/provenance/resource failure still requires disposition. Preserve source/environment/hash checks, 8 GiB RSS, 32 MiB per-child logs, bounded process-group cleanup and no automatic retry.

Absolute execution cutoff remains **2026-09-16 22:07:44 UTC** (September 17 07:07:44 KST), final cleanup/reporting **22:17:44 UTC** (07:17:44 KST). No reset or budget transfer.

C2 performance remains unknown. If correctness passes, submit the exact rebound diagnostic and fresh validation artifacts separately, retaining the same acceptance criteria and all C1 evidence. This review authorizes no timing run, further optimization, source adoption, serving, push or merge, and does not release the blocked async admission tickets.
