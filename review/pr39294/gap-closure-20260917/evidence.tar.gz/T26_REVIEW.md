# T26 focused static review

**CHANGES_REQUESTED — observer design accepted in the stated narrow scope; exact execution held for the two corrections below.** No experiment was run.

Reviewed hashes:

- T26_REQUEST.md: `81d9568e52c39cdab62b4d318bcd853c9d38d14eaf7f20b389623b0f2ea905e0`
- ASYNC_OBSERVER_DESIGN.md: `62a9b0046e3ff58ccb1375cc99d6f2eda58f0d8dfaa572434a3977552c628374`
- T26.json: `1e196aac3a1a286f84a555958d9e16b0e5d399d513f6dfb296bbec0c753e54a8`
- async-immutable-decision-harness/probe.py: `04b58787681f4ea096f9899ef6baa09728176b8991bd3725b8c8452cc2691781`

All manifest file hashes matched. The selected commands bind frozen C2, default CUDA context, M2/page1/lazy, normal then incorrect-second-event negative. The unchanged v2 runner supplies 90 seconds per child / 240 seconds total and existing resource/cleanup guards.

**T25 disposition:** COMPLETE with three PARTIAL results, exit zero and cleanup PASS. The altered-context diagnostics did not meet overlap prerequisites. Preserve these and all earlier PARTIALs; they are not functional failures and cannot be retrospectively upgraded by T26.

**Oracle assessment:** The design is valid for historical *selection*, not simultaneous GPU availability. Original nonurgent drain enqueues its actual free-list construction; the clone is then enqueued on the same explicit consumer before urgent drain/allocation. The clone owns separate storage and survives until synchronized readback. Thus later operations cannot rewrite the observed historical list, even if its construction/clone finishes after E2. The independently scheduled E2 queries bracket the host decision and clone submission.

The negative changes only the second batch's associated event to E1. Detection depends on source 2 appearing in that actual historical GPU list while the separately observed E2 was outstanding, rather than merely comparing injected event metadata. Its real consumer wait precedes allocation/writes, so sensitivity need not deliberately corrupt a reader. Final reader, retained/new payload, mapping/accounting and actual source reuse checks remain required. `stamp(only=new)` contains no explicit fixture host-value read before submitting writes; allocator/backend operations may still synchronize, as the requested boundary observations correctly acknowledge.

**Required corrections:**

1. **probe.py line 106:** remove the immediate `OUTSTANDING_URGENT_WAIT_MISSING` assertion conditioned only on the earlier `prerequisite`. E2 can legitimately finish between the post-clone query and the original urgent drain's event query; the allocator then needs no wait. Currently that valid timing miss becomes FAIL. Keep the preceding `URGENT_REUSE_DEPENDENCY_MISSING` safety check, and use the final missing-outstanding-wait classification to return PARTIAL when E2 completed safely without an observed outstanding wait. An absent dependency while E2 remains pending must still FAIL; protection/payload/mapping failures must not be softened. For consistency, the final wait test should explicitly match event 1 **and the consumer stream**, as the current safety checks do.
2. **T26.json `allowed`:** normal must allow only `["PASS", "PARTIAL"]`; negative only `["EXPECTED_FAULT_DETECTED", "PARTIAL"]`. Both currently accept all three statuses. Keep normal PASS plus negative EXPECTED_FAULT_DETECTED mandatory for any admission; runner completion or negative PARTIAL is insufficient. Refresh the probe/manifest hashes and submit the focused correction.

Any eventual approval covers a new observer protocol and separately labeled evidence only. It cannot prove that the clone completed or an unsafe overwrite executed before E2, that all allocation writes overlapped E2, or that natural production flush, other owners, graphs or distributed paths are safe. Existing same-event evidence remains separate. A new distinct confirmation registry still needs its own exact review after normal/control result acceptance.

Preserve sequential execution, fixed sleeps, default context, unchanged C2 and all v2 guards. No additional cases, retries, environment changes or source changes are authorized by this disposition. Static text/JSON/hash inspection only; only this review artifact was written.
