# T19S / T20S / T21 focused static review

Decision: **T19S APPROVED; T20S CONDITIONALLY APPROVED; T21 APPROVED as one diagnostic only.** No executable correction is required for these exact submissions. All launches remain sequential and subject to cleanup, unresolved-failure and absolute-deadline gates below. This is not C2 adoption or an authorization to expand the async registry.

## Exact artifacts

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
| --- | --- |
| T19S_T20S_REQUEST.md | `4b5a35eaf8788f6f554815a57652a60ec8771ae16eb7fc6297f70dd88d644079` |
| T21_REQUEST.md | `aabfa72b896f7dfd5f979c7b1255c0aa9144de632b1b9c709efea4427ff81c8b` |
| T19S.json | `47a34fb8a49fef648de35191e12043864677110d814b5afa03f70602ef72358f` |
| T20S.json | `8e54de641d536151c465c7aa7be038439d2c6fa879536c43dab5b1d3f10fa3b4` |
| T21.json | `6f00a1a719705a8816b61c572fdd3e560fb6a60720755d9ddf229d112bd9228f` |
| async-c2-same-harness/probe.py | `e2c2013ae7678a886a72d47c6f9ef2e170d96e827628524b9a8ae392bdca6ac9` |
| async-device-witness-harness/probe.py | `cec6f14eb8355cf58657a062ccd84403f6e3712dd5efb0b8bae605c629c56faf` |

Every file in the three manifests matches its declared hash, including wrappers, runner, environment and CUDA context. Current C2 diff still matches `4451ee8cc9ddb025f13a8ea954370c7d20ebac6310c454cd438379ff9433e5e0`. The same-event harness differs from the T18 explicit-consumer harness only in common.py's C2 provenance hash. T20S's entire ten-case registry matches T10S after explicit source/hash/harness/output rebinding.

## T18 disposition

The COMPLETE record binds the commands, result paths, A source and environment; both children have exit zero and cleanup PASS. The same-event result genuinely records both events outstanding after commit, E2 outstanding after nonurgent observation, an original wait_event on the explicit consumer with E2 outstanding, both physical sources 142/143 reclaimed and actually reused, and final checks passing. This supports the narrow same-event admission step.

Distinct remains PARTIAL: E2 was outstanding after drain but completed during the approximately 357 ms snapshot; there was no recorded urgent wait. Its runner PASS is successful execution of an allowed PARTIAL, not async coverage. Neither allocator failure nor a copy-engine/WSL root cause follows from this observation.

Evidence SHA256: T18 STATUS `1e86aa63a6ca9a1004f78a61baf0025f20657f44f44d8baa65a5d78b6f65199a`; same result `119479925e91630f7287e11d05052677f25b38d6b8f667159fd2b681dceacd97`; distinct result `e1dcf5322b1ee8ebe85364f59fc8b86c81a80b1a8922d307e435e481e100b440`.

## Same-event admission and confirmation

**T19S:** exactly two C2/M2 children, normal then negative, 90 seconds per child / 240 seconds total, using the correctness-passed frozen C2. T14's accepted CPU result supports the source prerequisite; no performance conclusion is required for this independent async investigation.

The negative injection suppresses retrieval of the preceding E2 batch. Detection is independent of the injected dictionary operation: after reader completion it requires actual free-list loss of precisely source 1 while source 2 was reclaimed. The earlier outstanding interval, pending protection, reader payload, retained/new payload and accounting checks remain in place. Repair follows explicit E2 completion, requires precisely the known missing source and an empty pending-event dictionary, and restores only that physical page. Both sources must then be actually reused. This is safe bounded sensitivity testing, not a racing overwrite or production corruption demonstration. A repaired prerequisite miss remains PARTIAL.

**T20S:** exactly ten additional children, 45 seconds each / 210 seconds total. Release only after authoritative T19S COMPLETE with both cleanup PASS, normal result PASS and negative result EXPECTED_FAULT_DETECTED, with matching manifest/commands/results/source/environment. PARTIAL in either admission arm holds T20S; no automatic retry. The two admission plus ten confirmation cells consume only the twelve same-event cells. Do not release old T08/T09/T10 or any distinct-event confirmation under this approval.

For every reported wait, distinguish an actual outstanding-event wait from the alternative where E2 already completed. The probe accepts either as a safe dependency; only the recorded outstanding wait supports that narrower coverage claim. Keep normal PASS, expected negative detection, PARTIAL and NOT_RUN counts separate.

## T21 immutable witness

**APPROVED:** one A/M2 normal child, 90 seconds / 180-second ticket. No negative or C2 command is authorized.

The witness reads the actual GPU free-list rather than reconstructing it from CPU pending metadata. Setup synchronizes before observation. The dedicated two-element int64 output and one-/two-element index tensors are warmed before the producer interval. Capture bounds the length to 0–2; zero length records only an event, and lengths one/two gather into disjoint owned witness storage. The source free-list operation and gather share the explicit consumer stream. Synchronizing witness_done completes that capture before the independent E2 query. PASS requires this historical snapshot to have completed while E2 was still outstanding.

The witness is retained and never overwritten after capture. Subsequent urgent drain may replace the allocator free-list but cannot change the saved witness. Host readback follows explicit E2 completion; comparison against the earlier pending snapshot is therefore temporally meaningful. Source 1 must have become reusable and source 2 must still have been protected at capture. Required actual source-2 reuse and reader/retained/new payload/accounting checks remain intact. Failure to preserve overlap yields PARTIAL, not an inferred pass.

The urgent dependency assertion occurs before the added host E2 synchronization. However, that explicit host completion makes subsequent writes safe independently, so T21 cannot by itself establish stream-only safe reuse without host synchronization. Treat it as diagnosis of the nonurgent historical free-list observation and recorded wait behavior. The dormant negative branch explicitly orders/completes E2 before writes; its execution and sensitivity admission require a later exact review. No larger delay, unchanged retry or native-flush reachability claim is approved.

## Execution conditions and limits

Finish T15 and any other active ticket, verify owned-process cleanup PASS, and disposition any failure before launching these tickets. No overlap with CPU cost measurement or GPU work. Unexpected invariant, payload, source/environment or cleanup failures stop dependent expansion. T21 does not depend on T19S obtaining admission, but cannot bypass an unresolved correctness failure. Its result does not automatically authorize distinct confirmation.

The entry wrappers check parent CUDA context, not predecessor results. The executor must explicitly bind and record the admission gates above; invoking a wrapper alone does not satisfy them. Retain unchanged runner source/hash/environment checks, native allocator/context checks, no-build settings, 8 GiB RSS, 32 MiB child log, GPU headroom and 3 GiB whole-device guard, and bounded process-group cleanup. Child maxima do not extend ticket caps: T20S's 10 x 45 seconds are clipped to 210 seconds. The three ticket caps total 630 seconds within remaining global time; no budget transfer or reset.

Workload cutoff remains **2026-09-16 22:07:44 UTC**; final cleanup/report cutoff **22:17:44 UTC**. Preserve C1's performance miss and all historical coverage limits. Scope is FULL-owner, page-size-1, lazy original-helper behavior with prebuilt indices and controlled streams; not FLOAT/Mamba-owner movement, natural production flush, graphs, distributed execution or universal async safety.

Static text/JSON/hash/read-only-source inspection only. No submitted module import, workload, GPU query, test or source modification was performed. This combined artifact is the disposition requested by the latest message.
