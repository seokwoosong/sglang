import argparse,json,traceback
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
from common import *
from env_check import verify_environment
from sglang.srt.session.streaming_session import StreamingSession
class Event:
 def __init__(self,label):self.fired=False;self.label=label
 def query(self):return self.fired
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--case',required=True);p.add_argument('--out',required=True);args=p.parse_args()
case=next(x for x in json.loads(Path(__file__).with_name('p1-registry.json').read_text()) if x['id']==args.case)
row=dict(case=case,source=provenance(args.version),environment=verify_environment(Path(__file__).resolve().parent.parent/'ENVIRONMENT.json'),status='RUNNING');f=None
try:
 f=Fixture(case['layout'],ps=case['ps'],lazy=case['lazy'],device='cuda',ratio=(4,2) if case['family']=='gate' else (1,1));a,c=f.a,f.c;ps=f.ps;family=case['family'];row['geometry']=f.geometry();row['backend']=type(c.tree_core).__name__
 retired={m.sub_pool_name:set() for m in f.members};allowed={m.sub_pool_name:set() for m in f.members};measuring={'on':False};count={m.sub_pool_name:dict(flush=0,copy=0,physical_pages=0,bytes=0) for m in f.members};evictions=[]
 def begin(extra=None):
  row['initial']=dict(allocator=f.snapshot(),cache=[dict(key=i,ids=ids.tolist(),state=int(f.states[i]) if f.state_cache else None) for i,(_,ids) in enumerate(f.records)],groups={name:None if getattr(a,name,None) is None else [v.tolist() for v in getattr(a,name)] for name in ('free_group','free_page_reps_group','full_free_group')},extra=extra)
  measuring['on']=True
 def allow_tokens(ids,owners):
  for name in owners:allowed[name].update(ids.tolist())
 def check_old(saved):f.check_saved(saved,retired);f.check()
 def narrow_failure(witness):
  # Independent protected payload/mapping/accounting checks must already pass.
  row['witness']=witness
  if args.version=='B' and witness in case['expected_B']:row['status']='EXPECTED_BASELINE_FAILURE'
  else:raise Failure(witness,row.get('outcome'))
 with ExitStack() as stack:
  for m in f.members:
   orig=m.free
   def free(ids,*pos,_fn=orig,_m=m,**kw):
    if measuring['on'] and ids is not None:
     v=(torch.unique(ids//_m.page_size)[:,None]*_m.page_size+torch.arange(_m.page_size,device=ids.device)).flatten();ended=set(v.tolist())
     require(ended<=allowed[_m.sub_pool_name],'UNAUTHORIZED_FREE',dict(pool=_m.sub_pool_name,ids=sorted(ended-allowed[_m.sub_pool_name])))
     retired[_m.sub_pool_name].update(ended)
    return _fn(ids,*pos,**kw)
   stack.enter_context(patch.object(m,'free',free))
   orig=m._flush
   def flush(*pos,_fn=orig,_m=m,**kw):
    if measuring['on']:count[_m.sub_pool_name]['flush']+=1
    return _fn(*pos,**kw)
   stack.enter_context(patch.object(m,'_flush',flush))
   orig=m._kvcache.move_kv_cache
   def move(*pos,_fn=orig,_m=m,**kw):
    if measuring['on']:
     require(bool(pos),'COPY_ARGUMENTS');pages=pos[0].numel()//_m.pool_page_size;v=count[_m.sub_pool_name];v['copy']+=1;v['physical_pages']+=pages;v['bytes']+=pages*_m.entry_bytes_per_page
    return _fn(*pos,**kw)
   stack.enter_context(patch.object(m._kvcache,'move_kv_cache',move))
  for method in ('evict','evict_for_alloc'):
   orig=getattr(c,method)
   def evict(*pos,_fn=orig,_method=method,**kw):
    result=_fn(*pos,**kw)
    if measuring['on']:evictions.append(dict(method=_method,full_tokens=result.num_tokens_evicted,swa_tokens=result.swa_num_tokens_evicted,state_slots=result.mamba_num_evicted))
    return result
   stack.enter_context(patch.object(c,method,evict))
  if family in ('joint_control','reclaim','impossible','locked','count_control','deferred','deep_reclaim'):
   n=(78 if family=='deferred' else 80) if f.layout=='M2' else (94 if family=='deferred' else 96)
   slots=f.populate(n);saved=f.stamp();f.check();locks=[]
   allow_tokens(slots,['full']+(['swa'] if f.layout!='M2' else []))
   if f.state_cache:allow_tokens(f.states[:3],['mamba'])
   if family=='locked':
    for key,_ in f.records:
     node=c.match_prefix(MatchPrefixParams(key=key)).last_device_node;locks.append((node,c.inc_lock_ref(node)))
    # Locked cache ownership may not be retired by the eviction walk.
    for name in allowed:allowed[name].clear()
   if family=='deferred':
    tmp=a.alloc(2*ps);require(tmp is not None,'FIXTURE_TEMP');a.free_group_begin();a.free(tmp);allow_tokens(tmp,['full']+(['swa'] if f.layout!='M2' else []))
   demand=(10000*ps if family=='impossible' else (int(a.available_size())//ps+1)*ps if family=='locked' else (1 if family=='joint_control' else 90 if family=='deep_reclaim' else 4)*ps)
   begin(dict(locked_records=list(range(len(locks))),demand=demand,cache_touch_order='insertion order; locked setup touches in record order'))
   if family=='count_control':
    result=c.evict(EvictParams(num_tokens=2*ps));require(result.num_tokens_evicted>=2*ps,'COUNT_CONTRACT');out=None
   else:row['evict_return']=evict_from_tree_cache(StreamingSession(c) if family=='locked' else c,demand)
   row['bindings_after_eviction']=f.cached_bindings(retired);check_old(saved)
   if family!='count_control':
    out=a.alloc(demand);row['allocation_success']=out is not None;check_old(saved)
    if out is not None:
     # New generation after old owners were checked; read it back before any further operation.
     new_by_pool={name:out for name in ['full']+(['swa'] if f.layout!='M2' else [])};f.check_new_allocation(new_by_pool,demand,saved,retired);fresh=f.stamp(9,only=new_by_pool);f.check_saved(fresh);check_old(saved)
   kept=sum(len(x['virtual_ids']) for x in row['bindings_after_eviction']);row['outcome']=dict(demand=demand,retained_tokens=kept,initial_tokens=n*ps,allocation_success=out is not None)
   if family in ('impossible','locked'):require(out is None,'UNEXPECTED_ALLOCATION')
   if f.layout=='M2' and family in ('impossible','deferred'):
    row['contract']='M2 existing shortfall/deferred behavior observed; no universal cache-preservation assertion and no claimed fix benefit'
   else:
    if family not in ('count_control','impossible','locked'):require(out is not None,'ALLOCATION_FAILED')
    target=(n*ps if family in ('impossible','locked','deferred','joint_control') else 95*ps if family=='reclaim' and f.layout!='M2' else 9*ps if family=='deep_reclaim' else None)
    if target is not None and kept!=target:
     require(0<=kept<target,'INVALID_RETENTION_DIRECTION',row['outcome'])
     narrow_failure('CACHE_EVICTED_BEYOND_TARGET')
   if family=='deferred':
    a.free_group_end()
    if out is not None:
     f.check_saved(fresh);check_old(saved)
    else:check_old(saved)
   for node,lock in locks:c.dec_lock_ref(node,lock.to_dec_params())
  elif family=='gate':
   slots=a.alloc(4);require(slots is not None,'GATE_KV_SETUP')
   states=a.mamba_allocator.alloc(8);require(states is not None,'GATE_STATE_SETUP')
   extra=a.full_attn_allocator.alloc(a.full_attn_allocator.available_size()-2);require(extra is not None,'FULL_BAND_SETUP')
   saved=f.stamp();f.check();state={'open':False};a.set_disagg_move_gate(lambda:state['open']);begin(dict(demand=6,gate=False))
   require(a.available_size()<6,'GATE_PRESSURE_PREREQUISITE')
   closed=f.snapshot();closed_copy_before={name:dict(value) for name,value in count.items()};require(not a.ensure_capacity(6,6),'CLOSED_GATE_UNEXPECTED_CAPACITY')
   require(all(count[name]['copy']==prior['copy'] and count[name]['physical_pages']==prior['physical_pages'] for name,prior in closed_copy_before.items()),'CLOSED_GATE_COPY')
   row['closed_copy_delta']={name:count[name]['copy']-prior['copy'] for name,prior in closed_copy_before.items()}
   require(f.snapshot()==closed,'CLOSED_GATE_MUTATION');check_old(saved)
   before=a.swa_attn_allocator.virtual_to_physical.clone();state['open']=True
   require(a.ensure_capacity(6,6),'REOPENED_RECOVERY_FAILED');check_old(saved)
   after=a.swa_attn_allocator.virtual_to_physical;mask=(before>=a.swa_attn_allocator.min_page_index)&(after>=a.swa_attn_allocator.min_page_index)&(before!=after)
   row['retained_swa_moved']=int(mask.sum().item());require(row['retained_swa_moved']>0,'FLOAT_MOVEMENT_PREREQUISITE')
   out=a.alloc(6);require(out is not None,'REOPENED_ALLOCATION_FAILED');check_old(saved)
   new={'full':out,'swa':out};f.check_new_allocation(new,6,saved,retired);fresh=f.stamp(9,only=new);f.check_saved(fresh);check_old(saved)
   row['scope']='synchronized actual FLOAT gate close/reopen and retained KV/state payload; no asynchronous timing'
  elif family.startswith('pending_'):
   slots=a.alloc(80*ps);require(slots is not None,'FIXTURE_KV')
   if f.layout!='S2':require(a.mamba_allocator.alloc(8) is not None,'FIXTURE_STATE')
   saved=f.stamp();fa=a.full_attn_allocator;first,second=Event('E1'),Event('E2');events=[first,first if family=='pending_same' else second];expected={};observations=[]
   def ledger():
    rows=[];union=set()
    for e,(cpu,device) in fa._pending_reuse.items():
     require(cpu==device.tolist() and len(cpu)==len(set(cpu)),'PENDING_LIST_TENSOR')
     rows.append(dict(event=e.label,sources=sorted(cpu)));require(not union&set(cpu),'PENDING_DUPLICATE');union.update(cpu)
    require(not set(fa._free_phys_pages.tolist())&fa._pending_reuse_pages_cpu,'PENDING_FREE_ALIAS')
    check_old(saved);return {e:set(v[0]) for e,v in fa._pending_reuse.items()},union,rows
   begin(dict(events=['E1','E1' if family=='pending_same' else 'E2'],modeled_events=True))
   for j,e in enumerate(events):
    drop=slots[(10+j*10)*ps:(11+j*10)*ps];allow_tokens(drop,['full']+(['swa'] if f.layout!='M2' else []));fa.set_latest_forward_done_event(e);fa.set_inflight_forward(e,None);a.free(drop)
    before=fa.virtual_to_physical.clone();moved=fa._flush(urgent=False);after=fa.virtual_to_physical;mask=(before>=fa.min_page_index)&(after>=fa.min_page_index)&(before!=after);sources=set(before[mask].tolist());require(moved>0 and len(sources)==1,'MOVE_PREREQUISITE');expected.setdefault(e,set()).update(sources)
    actual,union,items=ledger();expected_union=set().union(*expected.values());require(fa._pending_reuse_pages_cpu==expected_union,'PENDING_CPU_SET');observations.append(dict(batch=j,ledger=items,expected={x.label:sorted(v) for x,v in expected.items()}));row['pending_observations']=observations
    if actual!=expected:
     require(family=='pending_same' and j==1 and len(expected_union)==2 and actual=={first:sources} and union==sources,'UNEXPECTED_LEDGER_SIGNATURE')
     row['remaining_drain']='NOT_RUN after known ledger loss';narrow_failure('SAME_EVENT_OVERWRITES_FIRST_SOURCE');break
    fa._drain_pending_reuse(urgent=False);actual_after,union_after,_=ledger();require(actual_after==expected and union_after==expected_union==fa._pending_reuse_pages_cpu,'NO_EVENT_DRAIN')
   if row['status']=='RUNNING':
    for e in [second,first]:
     e.fired=True;expected.pop(e,None);fa._drain_pending_reuse(urgent=False);actual,union,items=ledger();require(actual==expected and union==fa._pending_reuse_pages_cpu,'INTERMEDIATE_DRAIN');observations.append(dict(drain=e.label,ledger=items))
    require(not fa._pending_reuse_pages_cpu,'PENDING_DRAIN');row['scope']='FULL-owner modeled event ledger/drain only; physical reuse and Mamba-owner/fired-between are NOT_RUN'
  elif family=='state_reuse':
   slots=a.alloc(48*ps);states=a.mamba_allocator.alloc(8);require(slots is not None and states is not None,'FIXTURE_STATE');saved=f.stamp();freed=states[1:4].clone();allow_tokens(freed,['mamba']);begin()
   a.mamba_allocator.free(freed);f.check_saved(saved,retired);new=a.mamba_allocator.alloc(3);require(new is not None,'STATE_REALLOC');check_old(saved);f.check_new_allocation({'mamba':new},3,saved,retired);new_saved=f.stamp(17,only={'mamba':new});f.check_saved(new_saved);check_old(saved);row['reuse_observed']=bool(set(new.tolist())&set(freed.tolist()));row['new_state_ids']=new.tolist()
   if not row['reuse_observed']:row['status']='PARTIAL';row['missing']='immediate state ID reuse; no FIFO-order assertion'
  elif family=='exact_extend':
   from sglang.srt.mem_cache.allocation import alloc_paged_token_slots_extend
   class Kernel:
    def __getitem__(self,grid):
     def launch(prefix,seq,last,free,out,batch_size,page_size):
      nxt=off=0
      for i in range(len(prefix)):
       for pos in range(int(prefix[i]),int(seq[i])):
        if pos%page_size==0:page=int(free[nxt]);nxt+=1
        elif pos==int(prefix[i]):page=int(last[i])//page_size
        out[off]=page*page_size+pos%page_size;off+=1
     return launch
   slots=f.populate(94);prefix_slots=a.alloc(ps);require(prefix_slots is not None,'FIXTURE_PREFIX');saved=f.stamp();prefix=torch.tensor([1]);seq=torch.tensor([3]);last=prefix_slots[:1];begin(dict(exact_new_pages=0,coarse_probe_tokens=6,scope='slack control, not historical 400-vs396 pressure'))
   with patch('sglang.srt.mem_cache.allocator.unified_sub_pool.alloc_extend_kernel',Kernel()):out=alloc_paged_token_slots_extend(c,prefix,prefix,seq,seq,last,2)
   require(torch.equal(out,prefix_slots[1:3]),'EXACT_EXTEND_IDS');check_old(saved);row['bindings_after_eviction']=f.cached_bindings(retired);require(sum(len(x['virtual_ids']) for x in row['bindings_after_eviction'])==94*ps,'SLACK_CONTROL_EVICTED')
  else:raise Failure('UNKNOWN_CASE',family)
 if row['status']=='RUNNING':row['status']='PASS'
except Failure as e:row.update(status='FAIL',failure=e.kind,detail=e.detail,traceback=traceback.format_exc())
except BaseException as e:row.update(status='FAIL',failure=type(e).__name__,detail=repr(e),traceback=traceback.format_exc())
finally:
 if 'count' in globals():row['counters']=dict(per_owner=count,evictions=evictions,preparation_calls='NOT_MEASURED')
 if args.version in ('A','C') and case['family']=='reclaim' and row['status']=='PASS':
  before={x['name']:x['v2p'] for x in row['initial']['allocator']};changed={}
  for m in f.members:
   now=m.virtual_to_physical.tolist();old=before[m.sub_pool_name]
   changed[m.sub_pool_name]=[v for v in range(m.min_page_index,len(old)) if old[v]>=m.min_page_index and now[v]>=m.min_page_index and old[v]!=now[v] and v not in retired[m.sub_pool_name]]
  row['retained_movement_virtual_pages']=changed
  missing=[name for name in ['swa','mamba'] if count[name]['physical_pages']==0 or not changed[name]]
  row['scope']='synchronized CUDA cache reclaim; required actual retained SWA/Mamba relocation; no event timing'
  if missing:row.update(status='PARTIAL',missing=['actual '+name+' relocation' for name in missing])
 if f is not None:f.close()
 Path(args.out).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(dict(case=case['id'],version=args.version,status=row['status'],failure=row.get('failure'),witness=row.get('witness'))))
raise SystemExit(0 if row['status'] in ('PASS','PARTIAL','EXPECTED_BASELINE_FAILURE') else 1)
