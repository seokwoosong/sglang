import hashlib,json,os,sys
from pathlib import Path
from env_check import verify_environment
import sglang.srt.mem_cache.allocator.unified_hybrid_swa as hybrid
assert Path(hybrid.__file__).resolve().is_relative_to(Path.cwd()/'python')
p={'hybrid':hybrid.__file__,'environment':verify_environment(Path(__file__).resolve().parent/'ENVIRONMENT.json')}
if os.environ['SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND']=='rust':
 from sglang.srt.mem_cache.rust_tree_core.extension import bindings
 p['rust']=dict(path=bindings.__file__,sha256=hashlib.sha256(Path(bindings.__file__).read_bytes()).hexdigest())
 assert p['rust']['sha256']=='1709a59dc2fb15a0f27e6bbce0dcb0d4906e39c0ec5e42a50bac19b886b6d42d'
print('PROVENANCE '+json.dumps(p),flush=True)
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
