"""Version-neutral real factories and observation-only payload/accounting checks."""
from array import array
from types import SimpleNamespace as NS
import hashlib,json,subprocess
from pathlib import Path
import torch
from sglang.srt.runtime_context import reset_context,publish
from sglang.srt.server_args import ServerArgs
from sglang.srt.mem_cache.unified_memory_pool import init_unified_mamba_pools,init_unified_swa_pools,init_unified_mamba_swa_pools
from sglang.srt.mem_cache.unified_radix_cache import UnifiedRadixCache
from sglang.srt.mem_cache.memory_pool import ReqToTokenPool
from sglang.srt.mem_cache.cache_init_params import CacheInitParams
from sglang.srt.mem_cache.unified_cache.components import ComponentType
from sglang.srt.mem_cache.base_prefix_cache import InsertParams,MatchPrefixParams,EvictParams
from sglang.srt.mem_cache.radix_cache import RadixKey
from sglang.srt.mem_cache.common import evict_from_tree_cache

PINS={'B':'a3bf25dc620f31fc672aeced1465d6fe7c81d28f','A':'15ccf48036bf5de0ec0aa886dedaa74bbdea8123'}
class Failure(Exception):
 def __init__(self,kind,detail):self.kind=kind;self.detail=detail;super().__init__(kind+':'+repr(detail))
def require(ok,kind,detail=None):
 if not ok:raise Failure(kind,detail)
def provenance(version):
 import sglang.srt.mem_cache.allocator.unified_sub_pool as sub
 import sglang.srt.mem_cache.unified_memory_pool as pool
 head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();root=Path.cwd().resolve()
 require(head==PINS[version],'SOURCE_HEAD',head)
 require(not subprocess.check_output(['git','status','--porcelain']),'DIRTY_SOURCE')
 for m in [sub,pool]:require(Path(m.__file__).resolve().is_relative_to(root/'python'),'SOURCE_IMPORT',m.__file__)
 return dict(version=version,head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),cwd=str(root),allocator_module=sub.__file__,torch=torch.__version__)

class Fixture:
 def __init__(self,layout,ps=1,lazy=True,ratio=(1,1),device='cpu',sessions=False):
  reset_context();publish(ServerArgs(model_path='Qwen/Qwen3-0.6B',device=device),role='tokenizer')
  self.layout,self.ps,self.device,self.ratio=layout,ps,device,ratio
  self.state_cache=layout!='S2' and ps==1
  f,s=ratio
  cp=NS(shape=NS(conv=[(3,8)],temporal=(1,4,8)),dtype=NS(conv=torch.bfloat16,temporal=torch.float32),layers=[0])
  base=dict(device=device,kv_cache_dtype=torch.float16,head_num=1,head_dim=8,page_size=ps,start_layer=0,end_layer=f+s,full_attention_layer_ids=list(range(f)),enable_memory_saver=False,need_sort=False,lazy_compaction=lazy)
  state=dict(mamba_layer_ids=[0],mamba2_cache_params=cp,max_mamba_cache_size=8,model_context_len=256*ps,extra_max_context_len=1,max_num_reqs=4,enable_mamba_extra_buffer=False,disable_overlap_schedule=True)
  if layout=='M2':
   base['end_layer']=f+1;cp.layers=[f];state['mamba_layer_ids']=[f]
   # ratio controls FULL layers vs state layers (not SWA). Nonempty state arrays.
   state['mamba_layer_ids']=list(range(f,f+s));cp.layers=state['mamba_layer_ids'];base['end_layer']=f+s
   self.b=init_unified_mamba_pools(**base,**state,is_draft_worker=False,use_mla_backend=False,max_total_num_tokens=100*ps,speculative_num_draft_tokens=None)
  else:
   base.update(v_head_dim=8,swa_head_num=1,swa_head_dim=8,swa_v_head_dim=8,swa_attention_layer_ids=list(range(f,f+s)),full_max_total_num_tokens=100*ps,swa_max_total_num_tokens=100*ps)
   self.b=(init_unified_swa_pools(**base) if layout=='S2' else init_unified_mamba_swa_pools(**base,**state,sliding_window_size=32))
  self.a=self.b.token_to_kv_pool_allocator
  self.members=[self.a.full_attn_allocator]
  if layout!='M2':self.members.append(self.a.swa_attn_allocator)
  if layout!='S2':self.members.append(self.a.mamba_allocator)
  req=(ReqToTokenPool(size=4,max_context_len=256*ps,device=device,enable_memory_saver=False) if layout=='S2' else self.b.req_to_token_pool)
  components=(ComponentType.FULL,)+( (ComponentType.SWA,) if layout!='M2' else ())+( (ComponentType.MAMBA,) if self.state_cache else ())
  self.c=UnifiedRadixCache(CacheInitParams(disable=False,req_to_token_pool=req,token_to_kv_pool_allocator=self.a,page_size=ps,sliding_window_size=128*ps,tree_components=components,enable_session_radix_cache=sessions))
  self.records=[];self.states=None;self.initial_swa_kernel_indices=[]
 def geometry(self):
  return dict(layout=self.layout,ps=self.ps,ratio=self.ratio,state_cache_component=self.state_cache,arena_bytes=self.a.unified_buffer.total_bytes,members=[dict(name=m.sub_pool_name,page_size=m.page_size,entry_bytes=m.entry_bytes_per_page,num_pages=m.num_pages,num_virtual_ids=m.num_virtual_ids,min_page_index=m.min_page_index,direction=m.grow_direction) for m in self.members])
 def live_tokens(self,m):
  v=torch.where(m.virtual_to_physical>=m.min_page_index)[0];v=v[(v>=m.min_page_index)&(v<m.num_virtual_ids)]
  return (v[:,None]*m.page_size+torch.arange(m.page_size,device=self.device)[None,:]).flatten()
 def views(self):
  f,s=self.ratio;kv=self.b.token_to_kv_pool
  for l in range(f+(s if self.layout!='M2' else 0)):
   m=self.a.full_attn_allocator if l<f else self.a.swa_attn_allocator
   for kind in ('key','value'):
    yield m,getattr(kv,'get_'+kind+'_buffer')(l),'kv'+str(l)+kind
  if self.layout!='S2':
   mc=self.b.req_to_token_pool.mamba_pool.mamba_cache
   for j,v in enumerate([*mc.conv,mc.temporal]):
    require(v.numel()>0,'EMPTY_STATE_VIEW',j)
    yield self.a.mamba_allocator,v.transpose(0,1),'state'+str(j)
 def stamp(self,generation=1,only=None):
  # Integers<=2000 are exactly represented in fp16; state <=100 in bf16.
  saved=[]
  for j,(m,buf,name) in enumerate(self.views()):
   ids=self.live_tokens(m) if only is None else only.get(m.sub_pool_name,torch.empty(0,dtype=torch.int64,device=self.device));ix=m.translate_kv_loc_for_kernel(ids)
   values=torch.empty_like(buf[ix]);flat=values.reshape(len(ids),-1) if len(ids) else None
   if len(ids):
    require(flat.shape[1]>=5,'MARKER_SHAPE',name)
    flat.fill_(j+1);flat[:,0]=(ids%127+1).to(buf.dtype);flat[:,1]=(ids//127+1).to(buf.dtype);flat[:,2]=generation%127+1;flat[:,3]=j+1;flat[:,4]=generation//127+1
   buf[ix]=values
   saved.append((m,buf,ids.clone(),values.clone(),name))
  return saved
 def check_saved(self,saved,retired=None):
  retired=retired or {}
  for m,buf,ids,values,name in saved:
   ended=torch.tensor(sorted(retired.get(m.sub_pool_name,set())),device=self.device,dtype=torch.int64)
   keep=~torch.isin(ids,ended);ids=ids[keep];values=values[keep]
   require(bool(torch.all(m.virtual_to_physical[ids//m.page_size]>=m.min_page_index)),'LOST_PROTECTED_MAPPING',name)
   require(torch.equal(buf[m.translate_kv_loc_for_kernel(ids)],values),'PAYLOAD',name)
 def check_new_allocation(self,new_by_pool,expected_size,saved,retired):
  for m in self.members:
   if m.sub_pool_name not in new_by_pool:continue
   ids=new_by_pool[m.sub_pool_name]
   require(ids.dtype==torch.int64 and ids.numel()==expected_size,'ALLOCATION_SIZE',m.sub_pool_name)
   require(len(torch.unique(ids))==expected_size,'DUPLICATE_ALLOCATION',m.sub_pool_name)
   require(bool(torch.all((ids>=m.min_page_index*m.page_size)&(ids<m.num_virtual_ids*m.page_size))),'ALLOCATION_ID_RANGE',m.sub_pool_name)
   held=set().union(*(set(old_ids.tolist()) for old_m,_,old_ids,_,_ in saved if old_m is m))-retired.get(m.sub_pool_name,set())
   require(not set(ids.tolist())&held,'NEW_ALIASES_PROTECTED_OWNER',m.sub_pool_name)
   require(bool(torch.all(m.virtual_to_physical[ids//m.page_size]>=m.min_page_index)),'NEW_ALLOCATION_UNMAPPED',m.sub_pool_name)
  self.check()
 def cached_bindings(self,retired):
  # Deliberate post-walk touches in a fixed key order, before new allocation.
  rows=[]
  for i,(key,prior) in enumerate(self.records):
   match=self.c.match_prefix(MatchPrefixParams(key=key));actual=match.device_indices
   require(torch.equal(actual,prior[:len(actual)]),'CACHE_BINDING_CHANGED',i)
   require(not set(actual.tolist())&retired.get('full',set()),'CACHE_REFERENCES_FREED',i)
   state=None;swa=None
   if len(actual)==len(prior):
    node=match.last_device_node
    if self.state_cache:
     value=self.c.tree_core.get_component_device_value(node,ComponentType.MAMBA)
     require(value is not None and torch.equal(value,self.states[i:i+1]),'CACHE_STATE_BINDING_CHANGED',i)
     state=value.tolist();require(not set(state)&retired.get('mamba',set()),'CACHE_STATE_LOSS',i)
    if self.layout!='M2':
     value=self.c.tree_core.get_component_device_value(node,ComponentType.SWA)
     require(value is not None and value.numel()==prior.numel() and torch.equal(value,self.initial_swa_kernel_indices[i]),'CACHE_SWA_BINDING_CHANGED',i)
     swa=value.tolist();require(not set(prior.tolist())&retired.get('swa',set()),'CACHE_SWA_LOSS',i)
     m=self.a.swa_attn_allocator
     require(bool(torch.all(m.virtual_to_physical[prior//m.page_size]>=m.min_page_index)),'CACHE_SWA_MAPPING_LOSS',i)
   rows.append(dict(key=i,virtual_ids=actual.tolist(),state_virtual_ids=state,swa_stored_kernel_indices=swa))
  return rows
 def check(self,allow_gate_memo=False):
  spans=[]
  for m in self.members:
   ids=self.live_tokens(m)[::m.page_size]//m.page_size;p=m.virtual_to_physical[ids]
   require(len(torch.unique(p))==len(p),'DUPLICATE_LIVE',m.sub_pool_name)
   require(torch.equal(m.physical_to_virtual[p],ids),'INVERSE_MAP',m.sub_pool_name)
   require(not set(p.tolist())&set(m._pending_reuse_pages_cpu),'LIVE_PENDING_ALIAS',m.sub_pool_name)
   for x in p.tolist():spans.append((x*m.entry_bytes_per_page,(x+1)*m.entry_bytes_per_page,m.sub_pool_name))
  spans.sort()
  require(all(x[1]<=y[0] for x,y in zip(spans,spans[1:])),'BYTE_OVERLAP')
  require(all(0<=lo<hi<=self.a.unified_buffer.total_bytes for lo,hi,_ in spans),'BYTE_RANGE')
  errors=self.a.verify_byte_accounting()
  require(not [e for e in errors if not (allow_gate_memo and 'stale schedulable_available_size memo:' in e)],'ACCOUNTING',errors)
  return errors
 def populate(self,n=96):
  if self.layout!='S2':
   self.states=self.a.mamba_allocator.alloc(8);require(self.states is not None,'FIXTURE_STATE')
  slots=self.a.alloc(n*self.ps);require(slots is not None,'FIXTURE_KV',(self.layout,n,self.ps))
  ranges=([(0,self.ps),(self.ps,2*self.ps),(2*self.ps,n*self.ps)] if self.layout!='S2' else [(i*self.ps,(i+1)*self.ps) for i in range(n)])
  for i,(lo,hi) in enumerate(ranges):
   key=RadixKey(array('q',range(i*10000,i*10000+hi-lo)))
   kwargs=dict(key=key,value=slots[lo:hi])
   if self.state_cache:kwargs['mamba_value']=self.states[i:i+1]
   self.c.insert(InsertParams(**kwargs));self.records.append((key,slots[lo:hi].clone()))
  # Setup-only fixed-order touches. SWA component stores kernel-facing indices.
  if self.layout!='M2':
   for key,prior in self.records:
    match=self.c.match_prefix(MatchPrefixParams(key=key));value=self.c.tree_core.get_component_device_value(match.last_device_node,ComponentType.SWA)
    expected=self.a.swa_attn_allocator.translate_kv_loc_for_kernel(prior)
    require(value is not None and torch.equal(value,expected),'INITIAL_SWA_TRANSLATION')
    self.initial_swa_kernel_indices.append(value.clone())
  return slots
 def retained(self):
  return sum(len(self.c.match_prefix(MatchPrefixParams(key=k)).device_indices) for k,_ in self.records)
 def snapshot(self):
  return [dict(name=m.sub_pool_name,v2p=m.virtual_to_physical.tolist(),p2v=m.physical_to_virtual.tolist(),pending=sorted(m._pending_reuse_pages_cpu),free=m._free_phys_pages.tolist(),available=m.available_size()) for m in self.members]
 def close(self):reset_context()
