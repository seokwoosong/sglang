# T22 focused static executable review

Decision: **APPROVED, conditional diagnostic execution only.** Exactly four A children, once each, in the submitted order. No executable correction is required for this bounded comparison. Do not launch until T16 has finished, its result/stop disposition has been recorded, and cleanup has passed. No overlap with CPU cost measurement or another GPU ticket.

## Exact bindings

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
| --- | --- |
| T22_REQUEST.md | `28a61f1d23bce7ab128bda0b8de4ba3504f44cab3d55d07f9a3b6ef3af0d34a1` |
| T22.json | `ffc6c4ff520adf43ee8be847876067af8dfac4a7741ed7153219293d040a14b7` |
| t22_entry.py | `3ec6f2b4dd985d6c08e7add55d6f4ec6cf5843285ec49f0a8157af29d36bc592` |
| async-late-operation-harness/probe.py | `1d21ba7988f8e98528a3bc05c184bf0502cca144003b1e61d0fa07398cf8c38a` |

All manifest file hashes matched, including unchanged runner, common.py, environment verifier and CUDA context. All four commands bind clean A at `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`, with empty diff and the intended result paths. The retained C1 branch in common.py is not selected or authorized.

## Evidence disposition

T21's authoritative record is COMPLETE with exit zero, result PARTIAL and cleanup PASS. Its one-element device witness contains source 142; source 143 remained pending at the earlier CPU observation. E2 was outstanding before and after nonurgent drain, but no longer outstanding after the 356,918,340 ns witness completion interval. There was no recorded urgent wait. The later safe reuse and payload checks do not restore the missing overlap prerequisite. Distinct admission remains held. T21 is not a functional failure and does not establish a D2H-only explanation.

T21 STATUS SHA256: `bd89b0baefebb86c160d00d251834e30448460541d1240567b590a3c29eefe30`; result SHA256: `6a3a3fe151fd2412633593c11e5ed856f19e4f255a4477acda64cf2f235227a7`.

The T19S/T20S runner records show COMPLETE, nine normal PASS and three EXPECTED_FAULT_DETECTED results, with cleanup PASS throughout. Their same-event scope remains separate from this distinct-event diagnosis. SAME_EVENT_MATRIX.json SHA256 is `11dd86eb69f0b023336ee053495e45890da3c757caaff17ca2ff392b9a69eb19`; this focused review does not expand those results into universal async safety.

## Oracle, ordering and interpretation

The selected variants are late_sleep, late_cat, late_cat_out and late_index_select. Each process uses the same explicit producer/consumer arrangement, reader indices 3/17, fixed producer delays and independent consumer input [142]. The selected consumer operation and its event are warmed and globally completed before the measured interval. No SGLang allocator fixture or move helper is instantiated; SGLang imports and provenance checks still occur through common.py. PyTorch allocation remains part of the allocating cat path.

The actual interval waits for E1, queries E2, submits the selected operation on the explicit consumer, records its sentinel, waits for that sentinel, and independently queries E2 again. PASS requires both reader events initially pending and E2 still pending both before late submission and after sentinel completion. It does not require instantaneous sentinel completion at submission. Final reader values and consumer output are read only after event completion, outside the overlap observation. Input/output lifetimes span their asynchronous uses. An absent overlap prerequisite remains PARTIAL; payload or runtime failures remain FAIL.

This is a useful test of whether late submission loses overlap even without the unified allocator's preceding drain. If all four are PARTIAL, that supports investigating a broader late-submission/scheduling effect in this fixture. If they differ, it identifies a path to investigate, not a causal proof. Allocating cat versus preallocated cat_out changes allocation and dispatch behavior together; index_select uses another operator. The warmed cat result also remains live until reassignment. No allocation-only attribution follows from a difference.

Host submission and sentinel-wait durations are diagnostic intervals, not isolated kernel timings. One fresh process per operation is not a statistical performance comparison. There is no kernel trace proving the detailed device path, and these constant-value checks are not a new copy-kernel validation suite. Do not claim a CUDA driver/WSL root cause, production-flush reachability, distinct-event admission, or allocator correctness from T22 PASS/PARTIAL. No negative control, C2 confirmation, larger delay or automatic rerun is authorized.

## Gates and finite bounds

The wrapper checks parent CUDA flags; it does not enforce the T16 prerequisite. The executor must record T16 completion/disposition and cleanup before launch. A performance-only miss can be dispositioned separately from this independent A diagnostic; an unresolved correctness, provenance, environment or cleanup failure blocks dependent work. Preserve C1/C2 performance results and thresholds unchanged.

Keep 60 seconds per child and 300 seconds total, including the existing runner's startup/cleanup reservation and global clipping. Four child maxima total 240 seconds; remaining ticket time is overhead, not an extra case or retry. Preserve the unchanged 8 GiB RSS, 32 MiB log, GPU headroom and 3 GiB whole-device guards, source/environment checks, failure precedence and owned-process-group cleanup. On an exception, the runner remains responsible for bounded termination and cleanup; no passing result may be inferred from an incomplete JSON artifact.

Absolute workload cutoff remains **2026-09-16 22:07:44 UTC**, final cleanup/report cutoff **22:17:44 UTC**. Preserve raw results and PARTIAL/NOT_RUN labels. Any further experiment needs its own concrete review.

Review performed by static text/JSON/hash inspection only. No submitted imports, tests, workloads, GPU queries or source changes were performed.
