"""Uninstrumented CPU evict+alloc host duration. Fixture reset every sample."""
import argparse,json,time,traceback,os
from env_check import verify_environment
from common import *
p=argparse.ArgumentParser();p.add_argument('--version',required=True);p.add_argument('--pair',type=int,required=True);p.add_argument('--out',required=True);p.add_argument('--compare-to',action='append',default=[]);args=p.parse_args();registry=json.loads(Path(__file__).with_name('registry.json').read_text());result=dict(source=provenance(args.version),environment=verify_environment(Path(__file__).resolve().parent.parent/'ENVIRONMENT.json'),cpu_context=dict(affinity=sorted(os.sched_getaffinity(0)),threads=torch.get_num_threads(),interop_threads=torch.get_num_interop_threads(),thread_env={k:os.environ.get(k) for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','PYTHONHASHSEED']}),pair=args.pair,status='RUNNING',scenarios=[]);f=None
try:
 for cfg in registry:
  entry=dict(config=cfg,status='RUNNING',warmup_count=2,samples=[]);result['scenarios'].append(entry)
  for i in range(7):
   setup_begin=time.perf_counter_ns()
   f=Fixture(cfg['layout'],1,True);a,c=f.a,f.c;f.populate(80 if cfg['layout']=='M2' else 96)
   # Protect request-owned Mamba states; cache-owned data invariants belong to P1.
   protected=f.stamp(1,only={'mamba':f.states[3:]} if f.layout!='S2' else {});f.check();initial=dict(geometry=f.geometry(),snapshot=f.snapshot())
   if i==0:entry['initial']=initial
   else:require(initial==entry['initial'],'RESET_FIXTURE_MISMATCH')
   setup_ns=time.perf_counter_ns()-setup_begin
   begin=time.perf_counter_ns();evict_from_tree_cache(c,cfg['demand']);ids=a.alloc(cfg['demand']);elapsed=time.perf_counter_ns()-begin
   # No wrappers, observations, logging or explicit sync in timed region.
   require(ids is not None and len(ids)==cfg['demand'] and len(torch.unique(ids))==len(ids),'ALLOCATION_FAILED_OR_IDS')
   f.check_saved(protected);f.check()
   if i>=2:entry['samples'].append(dict(host_ns=elapsed,completed_tokens=len(ids),setup_ns=setup_ns))
   close_begin=time.perf_counter_ns();f.close();f=None
   if i>=2:entry['samples'][-1]['teardown_ns']=time.perf_counter_ns()-close_begin
  entry['status']='PASS'
  Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
 for prior_path in args.compare_to:
  prior=json.loads(Path(prior_path).read_text());require(prior['status']=='PASS','PRIOR_ARM_FAILURE')
  require(prior['cpu_context']==result['cpu_context'],'CPU_CONTEXT_MISMATCH')
  require(prior['environment']==result['environment'],'ENVIRONMENT_MISMATCH')
  require([(x['config'],x['initial']) for x in prior['scenarios']]==[(x['config'],x['initial']) for x in result['scenarios']],'INITIAL_STATE_MISMATCH')
 result['status']='PASS'
except Failure as e:result.update(status='FAIL',failure=e.kind,detail=e.detail,traceback=traceback.format_exc())
except BaseException as e:result.update(status='FAIL',failure=type(e).__name__,detail=repr(e),traceback=traceback.format_exc())
finally:
 if f is not None:f.close()
 Path(args.out).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],failure=result.get('failure'))))
raise SystemExit(0 if result['status']=='PASS' else 1)
