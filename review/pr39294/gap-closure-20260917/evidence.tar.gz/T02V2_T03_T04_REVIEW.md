# T02 v2 / T03 / T04 focused static review

Decision: **T02 APPROVED conditionally; T03 APPROVED conditionally; T04 measurement execution APPROVED conditionally. T04 summary acceptance CHANGES_REQUESTED.**

This authorizes only the exact finite children below, once, after their prerequisites. It does not accept C1, establish performance or async safety, authorize source adoption, or expand the registry/budgets. Review was static: text, manifest/hash inspection and read-only candidate diff hashing. No submitted module imports, workloads, tests, GPU queries, installations or source edits were performed.

## Identity

Root: `/home/sukwoo24/sglang-eval-results/pr39294-gap-closure-plan-20260916`.

| Artifact | SHA256 |
|---|---|
| T02.json | `3d7312b2690e62ab7e338b815fbfc6f2ccca7a758bec52f79c94548fdbd4c6ab` |
| T03.json | `fbdfb16dad2a87188d4a4c7f203ab2c9bb9d694763e16854eec5c91a161c31f1` |
| T04.json | `701b608916ba457978dcdf978ee12ad5a35f52d2de3ebc8525524b23806d5ffc` |
| MEASUREMENT_REQUEST.md | `1d14888532a01474e3b506be246ad61199ec3f9cbfe97a87dfb571b7dbaeaed6` |
| CUDA_CONTEXT.json | `7ae0dbb850870d33c0a68012fcf77f533f1fb72c8289637acbb2783484b24e6e` |
| t02_entry.py | `c623c28c763557a21a7d1363e7c67cbbfdf9415f64e3cc4eb169871190ea23c4` |
| async-diagnosis-harness/probe.py | `3f1c207a9a755e3ad36424f72b3ed634b15ab1ed2c826646ed858e7d68085ca2` |
| summarize_cost.py | `0720cd4ba339874f85e25567187905ef62631893052900ce788f9a1982c0a600` |

All file hashes listed by the three manifests matched. The shared runner remains `14d60a8f9e30a09891cf2d0b08e1e8346ecc4f8879c28c9bee901267a474efe1`. C1's actual binary diff still hashes to `7c8964a50e86ab0052f0c8ae22eb03499639e1791360b95f9b4963294d7b5be3` against A HEAD `15ccf48036bf5de0ec0aa886dedaa74bbdea8123`.

## Common execution conditions

- No overlap with T01 or another workload; preceding owned process groups must be cleaned up. An unresolved failure/timeout/resource stop requires disposition before dependent execution. A diagnostic PARTIAL without a fault is not an async safety pass and does not by itself block independent CPU work.
- T03/T04 require T01 COMPLETE with both required Python and Rust children passing, unchanged C1 source and environment. The generic runner does not enforce that prerequisite itself: the executor must retain the exact T01 status/manifest/source binding before launch. T04 also requires satisfactory disposition of T03 if T03 has run.
- Preserve the 8 GiB RSS and 32 MiB per-child log guards, sequential cleanup, unchanged environment, no builds/retries, and absolute execution cutoff **2026-09-16 22:07:44 UTC**. Final cleanup/reporting remains within **22:17:44 UTC**. Ticket ceilings do not reset either deadline.

## T02 — APPROVED

Launch through the hashed `t02_entry.py`, without bypassing its parent-context check. The six unset CUDA flags are checked again in each child; actual native allocator backend, device and producer/consumer/default stream identities are recorded before scheduling the delayed readers. The commit trace list is attached before tracing and tracing is disabled in finally, preserving observations on exceptions. The cleanup comment now agrees with the 90-second child limit.

Scope: exactly six M2/page-1/lazy normal A/B children across native, prebuilt and warmed variants; 90 seconds each, 900 seconds total, existing 3 GiB whole-device guard and headroom check. No negative-control or further layout expansion is approved here. Trace event queries perturb observation timing; these results diagnose helper behavior and cannot establish natural flush reachability, uninstrumented timing, or general async safety. Missing overlap/reuse prerequisites remain PARTIAL. T02 validates frozen A/B, not C1.

## T03 — APPROVED

Exactly A,C / C,A: four children, 60 seconds each, 300 seconds total. Three ready scenarios, two warmups and three profiled samples per scenario: 24 warmup and 36 diagnostic operations. Source validation recognizes only the exact dirty C1 diff; fixture mechanics and timing boundaries remain unchanged.

Before attributing call-count differences, compare the recorded A/C scenario configuration, initial geometry/snapshot, environment and CPU context within each pair. The worker checks repeat resets within a process, but does not automatically compare the pair. A mismatch invalidates the comparison and must not be repaired by an unapproved rerun. cProfile and helper/allocation split times are diagnostic only; overlapping inclusive times are not additive cost estimates.

## T04 — measurement execution APPROVED; summary CHANGES_REQUESTED

The exact 36 cost children may run once under the conditions above. The runner does not invoke `summarize_cost.py`, so the summary defect does not require changing or repeating measurement children.

Twelve blocks use BAC, BCA, ABC, ACB, CBA, CAB twice. Each later arm compares all earlier arms in its block outside the timed interval, including initial state, CPU context and environment. Each of five scenarios has two fresh-fixture warmups plus five measurements: **360 warmups and 900 measured operations**. Only evict+alloc is timed; observations, setup and teardown remain outside. Per-child ceiling is 90 seconds; the 2400-second ticket ceiling truncates the nominal 3240-second sum of child maxima. Completion of all twelve blocks is therefore conditional, not guaranteed, and a truncated run must not trigger automatic completion runs.

Required summary correction before accepting or publishing its analysis:

1. **Bind eligible blocks to the authoritative runner record.** At lines 8–12 the summarizer currently accepts three child JSON PASS values without checking their runner rows. A child can write PASS and then be rejected for late completion, cleanup failure, or another guard failure. Require matching ticket/manifest identity and exact case/command/result bindings, runner PASS, exit code 0, result PASS and cleanup PASS for each arm. A provenance failure must not be silently salvaged. Retain excluded/unfinished rows and reasons.
2. **Use a single complete-valid-run gate for intervals and the primary criterion.** Line 21 currently emits intervals whenever twelve JSON blocks exist, even if STATUS is STOPPED. Require COMPLETE plus all 36 accepted rows and all twelve valid blocks. Otherwise report descriptive accepted blocks only, explicitly INCONCLUSIVE, with no CI or margin conclusion. Check the five scenario identities, scenario PASS, two warmups and five finite positive measurements before positional aggregation; preserve the recorded source/environment/context bindings.

The frozen bootstrap seed, 10,000 whole-block resamples, associated C/A and C/B comparisons, primary upper-bound criteria, and control deterioration thresholds are otherwise consistent with the plan. The adaptive-development/non-selection-adjusted qualification must remain. Unresolved material control deterioration still holds candidate adoption even if the primary criterion passes.

Submit only the corrected analysis artifact and refreshed hash binding for targeted static review; no production change, workload expansion or new sampling budget is needed. Until then, raw T04 data collection is authorized, but the current summarizer is not an accepted result oracle. No candidate acceptance or merge-readiness conclusion is issued by this review.
